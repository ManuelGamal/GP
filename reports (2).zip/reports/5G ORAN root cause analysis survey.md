# Telecom RCA agents guess without evidence

The new 5G/O-RAN literature supports VERDICT's central bet. In telecom, LLM agents often reach plausible root causes but almost never show the evidence for them, and they over-diagnose healthy networks. On CTBench, the strongest telecom agent solves **47.6% of RCA tasks against 56.4% for human experts**, and its **evidence F1 is only 15.8%** ([CTBench](https://arxiv.org/html/2608.12002)). On FaulT-Bench, agents report a fault on **11–24% of healthy networks** ([FaulT-Bench](https://arxiv.org/html/2608.27021)).

**No paper in the notes runs an LLM agent against a split CU/DU stack (OCUDU, srsRAN Project or OAI RAN) with injected RAN faults and ground-truth scoring.** Team Praxis therefore has a real gap to fill. The flip side is that there is no external number to compare our top-1 accuracy against.

"Multi-agent telecom RCA" is not new on its own. Ericsson's multi-agent system and QoEReasoner already exist. VERDICT's defensible novelty is a combination of four things: a Generator that never sees raw telemetry, an adversarial Falsifier, typed predicates that deterministic code re-runs, and measured abstention. The fratricide and void-refutation metrics appear nowhere else in the notes.

Feasibility is good if scope is controlled. OCUDU is the Linux Foundation successor of the srsRAN Project and keeps its architecture. It emits per-layer logs, F1AP/NGAP/E1AP/E2AP PCAPs and JSON metrics. It documents **no Prometheus export and no alarms**, so the Broker must build both. Single students have built comparable injection pipelines on srsRAN and Open5GS.

Two risks need early action:
1. A well-built non-LLM Condition 0 could match VERDICT on a clean, single-fault, mostly control-plane corpus. Classical baselines reach roughly 90% F1 on clean few-class data.
2. A Chinese patent application (CN121984837A, Shanghai Anchnet, filed March 2026) already claims alarm-triggered "LLM generates candidate root causes, queries over raw O&M data verify them" for cloud operations. Generate-then-verify is therefore prior art. It does not cover a blind Generator, adversarial refutation, typed re-executed predicates, abstention or telecom (see F10).

The redesign section turns these findings into a ranked set of changes, summarised as "VERDICT v2". It then proposes **Architecture D (Cascade)**: Condition 0 runs first, and the LLM tiers may override it only with a re-executed two-strike refutation. Cascade is designed to tie or beat Condition 0 and Architectures A, B and C on every quality metric, which the ablations must confirm, at the cost of more compute than a pure rule engine.

## Executive summary: the gap is evidence and abstention, not accuracy

The literature found by the six research streams agrees on three points:

1. **Interactive, tool-grounded telecom RCA is far from solved, and text-only telecom quizzes overstate model ability.**
   - Three small frontier models score **90–98.3% on free-text 5G fault diagnosis but below 60% on zero-shot specification recall** ([Sengupta et al.](https://arxiv.org/html/2608.21021)).
   - Interactive benchmarks put the best agents at **47.6%** (CTBench) and **55.3%** (NIKA, GPT-5) RCA accuracy ([CTBench](https://arxiv.org/html/2608.12002); [NIKA](https://arxiv.org/html/2512.16381)).
   - The difficulty lies in gathering evidence from live telemetry. That supports evaluating on an executable OCUDU testbed rather than a static Q&A set.
2. **The failure modes match VERDICT's components closely.**
   - Agents give correct answers without evidence (CTBench), which is the gap the Falsifier and provenance trail fill.
   - Agents promote benign conditions to root causes because they lack "a criterion for concluding, with evidence, that no fault exists" ([FaulT-Bench](https://arxiv.org/abs/2608.27021)), which the "unresolved" output addresses.
   - Free-form deliberation "conflates evidence acquisition with hypothesis commitment" ([SADE](https://arxiv.org/abs/2605.04530)), which the Generator/Falsifier split addresses.
   - Models mostly continue a flawed reasoning trace rather than correct it: the best Correct Flip Rate is **29.1%** ([TeleResilienceBench](https://arxiv.org/abs/2605.09929)). This is the main threat to an LLM Falsifier that reads the Generator's reasoning.
3. **The classical non-LLM literature is both a resource and a threat.**
   - A Random Forest on O-RAN KPM features reaches **macro-F1 0.90 at 0.224 ms** ([Azkaei et al.](https://arxiv.org/html/2509.03290)).
   - Profile-deviation × fault-signature diagnosis is an operator-grade, explainable method ([Szilágyi & Nováczki](https://doi.org/10.1109/tnsm.2012.031912.110155)).
   - On a small, clean injection corpus, VERDICT may not beat a well-built Condition 0 on accuracy.
   - The strongest response is to build on the deterministic front-end, not race against it. It becomes both Condition 0 and the Generator's candidate prior. VERDICT's win-claims then move to verification, abstention, compound or unseen faults, and investigation effort, and should be pre-registered.

For R2 specifically, the cloud-RCA failure families transfer to network troubleshooting with little change: anchoring, premature stopping, hallucinated evidence and stalling. Telecom adds four modes the cloud benchmarks cannot measure:
- over-diagnosis of healthy networks under misleading tickets;
- unsafe intermediate actions on shared live state;
- degradation as the topology grows;
- weak 3GPP/O-RAN specification recall.

The evidence favours **deterministic per-step checks over LLM judges** for scoring the reasoning process. One verifier study found that an LLM-as-a-judge baseline peaks at the first step and *declines* as more of the trajectory is shown ([Safety Signals](https://arxiv.org/html/2609.14422v2)). VERDICT's re-executed predicate trail is in effect a deterministic process reward, and the evaluation should exploit that.

## How this catalogue was built and how to read it

Every entry comes from the six notes files in the research folder. The verification labels follow the notes:
- **VERIFIED (full text):** the PDF or HTML was read.
- **VERIFIED (abstract):** only the arXiv abstract, landing page or DOI page was read.
- **PARTIAL:** metadata or index pages were seen, but the full text was not read.
- **SNIPPET / UNVERIFIED:** seen only in a search-engine summary or secondary coverage. Do not quote the numbers from these entries without checking them first.

Papers that appear in several notes files are merged into one entry, and disagreements between notes are stated. The following items are already in the survey and are referenced but not catalogued: TeleLogs (2507.21974), 2609.02805, AI5GTest (2506.10111), LLM-as-an-Improver (2609.19515), LLM-as-a-Verifier, the R1–R6 cloud-RCA papers, RCACopilot, RCAgent, OpenRCA, RCA-100 and AIOpsLab. Each entry has five parts: citation, verification status, Summary, Correlation with our project, and What it tells us. "Correlation" names the VERDICT component, architecture (A = single ReAct agent, B = VERDICT, C = verify-repair-reselect), metric or Track B feature it touches.

## The catalogue: six themes, one merged entry per paper

### Theme A — LLM and agentic RCA in telecom and O-RAN

#### A1. CTBench — the first telecom benchmark that scores the evidence trail
**Citation.** Xingyu Yan, Tingting Dai, Antonio De Domenico, Mohamed Sana, Nicola Piovesan, et al. (19 authors; Huawei/Noah's Ark-affiliated list that overlaps the TeleLogs team), "CTBench: Evaluating Troubleshooting Capabilities of AI Agents in Realistic Telecom Network Operations," arXiv:2608.12002, 12 Aug 2026. https://arxiv.org/abs/2608.12002

**Status.** VERIFIED (full HTML in one notes file; abstract-only in another). The notes do not disagree on any number.

**Summary.**
- **Benchmark:** 234 expert-built tasks, 126 RCA and 108 path restoration. Each task runs in a reactive sandbox that exposes a diagnostic interface over multi-vendor real equipment, and each is annotated with "golden evidence steps".
- **Metrics:** final accuracy, RCA-Loc, RCA-ID, RCA-Evidence (F1 against the golden steps), and cost (rounds, latency, tokens).
- **Results (RCA Acc / Loc / ID / Evidence-F1, %):**
  - Codex + GPT-5.5: 47.62 / 52.90 / 66.83 / 15.80
  - HermesAgent + Qwen3.7-Max: 25.40 / 37.59 / 52.38 / 12.59
  - ClaudeCode + Qwen3.7-Plus: 19.84 / 34.68 / 38.96 / 12.62
  - HermesAgent + DeepSeek-V4-Pro: 17.46 accuracy
  - HermesAgent + TelecomGPT-R1 (a telecom-specialised model): **4.76** accuracy
- **Humans:** experts reach 56.4% on RCA and 92.6% on path restoration, taking 40–60 minutes per task.
- **Evidence:** evidence F1 ranges from 5.23 to 15.80% across agents.
- **Hard categories:** interface-state and link-layer faults are "uniformly hard" at 0.00–10.71%.
- **Partial observability:** it cut one agent from 20.56% to 15.79%.
- **Cost does not buy accuracy:** ClaudeCode + Qwen3.7-Plus used 81.36 rounds and 2,751.7k tokens per task, against 10.81 rounds and 476.5k tokens for the far better Codex + GPT-5.5.

**Correlation with our project.**
- Metrics, and R2's process-evaluation agenda.
- The Falsifier/Orchestrator provenance trail, which is the property CTBench shows agents lack.
- The risk that Architecture A loops and burns cost.
- Generator/Falsifier model selection.
- Our "wrong F1 DU–CU address" fault is an interface-state fault, CTBench's hardest class.

**What it tells us.**
- Report localization (which network element or interface) separately from identification (which fault class). Loc is below ID for every agent.
- Add an evidence-grounding metric against a gold evidence set written at injection time.
- Treat telecom fine-tunes as a risk, not a shortcut, for the Generator or Falsifier: TelecomGPT-R1 collapsed to 4.76%.

#### A2. TN-AutoRCA — alarm RCA on base-station topologies; direct LLMs over-flag
**Citation.** Keyu Wu, Qianjin Yu, Manlin Mei, Ruiting Liu, Jun Wang, Kailai Zhang, Yelun Bao, "TN-AutoRCA: Benchmark Construction and Agentic Framework for Self-Improving Alarm-Based Root Cause Analysis in Telecommunication Networks," arXiv:2507.18190, 24 Jul 2025 (v2). https://arxiv.org/abs/2507.18190

**Status.** VERIFIED (full HTML). Affiliation not captured.

**Summary.**
- **Benchmark (TN-RCA530):** 530 scenarios (29 Simple, 501 Difficult) built from real base-station topology (BBU/RRU/board/port) and real alarms, with expert-validated knowledge graphs. RCA is framed as multi-label classification. A true positive needs an exact match on (cause_description, equipment_id).
- **Direct-LLM Mixed F1@1:** Qwen3-235B 0.6254, Claude-Sonnet-4 0.6181, Gemini-2.5-Pro 0.5899, Qwen3-4B 0.5144. On Difficult cases precision is about 0.40–0.44 while recall is about 0.96–0.98.
- **Auto-RCA:** five modules (Orchestrator, Evaluator, Bad-Case Analyzer, LLM Agent, Sanitizer) iteratively rewrite a *code-based* RCA solution, keeping a change only if benchmark F1 improves. This lifts Gemini-2.5-Pro from 0.5899 to **0.9179**.
- **Limitation:** models with 64K context lose information on the alarm knowledge graphs.

**Correlation with our project.** Track B alarm analysis, the Orchestrator's accept/reject rule, and Architecture C. Auto-RCA is similar in spirit to verify-repair-reselect, but it works offline on code, not per incident.

**What it tells us.**
- Direct LLMs flag too much: high recall, low precision. Precision is where a Falsifier adds value, and an aggressive Falsifier is where fratricide risk comes from.
- The large gain came from LLM-synthesised *deterministic code*. This supports VERDICT's split, where the LLM commits executable predicates and deterministic code runs them.

#### A3. Ericsson multi-agent system with fine-tuned SLMs — the closest industrial analogue to Architecture B
**Citation.** Chenhua Shi, Bhavika Jalli, Gregor Macdonald, John Zou, Wanlu Lei, Mridul Jain, Joji Philip (Ericsson), "Leveraging Multi-Agent System (MAS) and Fine-Tuned Small Language Models (SLMs) for Automated Telecom Network Troubleshooting," arXiv:2511.00651, 1 Nov 2025 (v2); 2026 IEEE ICC Workshop on Wireless Foundation Models for AI-native 6G. https://arxiv.org/abs/2511.00651

**Status.** VERIFIED (full HTML).

**Summary.**
- **Agents:** LLM orchestrator, solution planner, executor, data retriever, RCA analyzer and dashboard agent, in a ReAct loop triggered by AI/ML monitors.
- **Data sources:** RAN PM (PostgreSQL), Core PM (VictoriaMetrics), alarms and logs (OpenSearch), and a knowledge graph over PM/CM/FM/log documents.
- **Planner:** HippoRAG with DeepSeek-R1-Qwen3-8B, trained by SFT then GRPO with RAGAS rewards.
- **Use cases:** RRU input-power failure; O1 HeartbeatLost traced to NTP drift; congestion fixed by a 4 dB A5 threshold change (peak DL PRB 91% → 67%); core PDU-session degradation traced to a suspended NRF.
- **Claims:** a "six-fold" reduction in troubleshooting time and a "10%" accuracy gain over humans, with no benchmark, sample size or accuracy definition.
- **Rewards:** fine-tuning raised the reward from 5.96 to 10.51. Retrieval reward was 3.61 for RAG, 4.08 for GraphRAG and 5.19 for HippoRAG.
- **Guardrails:** human approval gates, regex format checks, a groundedness reward and SME review. There is **no automated check of the root cause against telemetry**.

**Correlation with our project.**
- Architecture B as a whole.
- Its data retriever plays the Broker's role, and its dashboard agent matches the Track B dashboard.
- Its NRF case is analogous to our "core NF stopped" fault.

**What it tells us.**
- Multi-agent telecom RCA is not novel and must be cited.
- VERDICT's novelty rests on three things Ericsson lacks: a telemetry-blind Generator, a Falsifier that commits executable predicates, and deterministic re-execution with a two-strike rule and an "unresolved" output.
- Ericsson's weak evaluation is our opening: a controlled injection corpus with ground truth is a differentiator.

#### A4. Hatami et al. — LLM fault detection on a Kubernetes 5G core
**Citation.** Parsa Hatami, Ahmadreza Majlesara, Ali Majlesi, Babak Hossein Khalaj, "Automated Fault Detection in 5G Core Networks Using Large Language Models," arXiv:2512.19697, submitted 24 Nov 2025. https://arxiv.org/abs/2512.19697

**Status.** VERIFIED. Three notes files cite this paper. One read the full HTML and gives the testbed and numbers. Two saw only the abstract page, which names neither OAI nor Chaos Mesh and gives no numbers; one of those flagged "OAI + Chaos Mesh" as unverified. The full-text reading is taken as authoritative here.

**Summary.**
- **Testbed:** OAI 5G Core Rel-15 (AMF, SMF, UPF, DB) plus an OAI gNB and UEs, all as Kubernetes pods.
- **Faults and data:** five Chaos Mesh fault types (pod failure, pod kill, network delay, network loss, I/O or disk-I/O injection) across **118 experiments**, split 50/25/25.
- **LLM input:** kubectl pod status, filtered pod logs, K8s events, and per-UE RTT before and after injection.
- **Headline result:** fine-tuned GPT-4.1-nano reaches **93% accuracy and 95% F1** for binary detection, against 40% and 45% for the base model. Recall rose from 30% to 93%.
- **Per class:** I/O 1.00 (only 10 instances, flagged by a distinctive "unknown database" line), pod failure 0.97, pod kill 0.93 (base model 0.23), network loss 0.91, network delay 0.87.
- **Failure mode:** the base model mostly called faulty networks "normal".

**Correlation with our project.** The fault corpus, the "core NF stopped" class, the no-LLM baseline, and evidence that an open 5G testbed is feasible.

**What it tells us.**
- A labelled corpus of about 100 injections is realistic for a small team.
- Infrastructure faults with distinctive log lines are easy. Our config faults (PLMN mismatch, wrong F1 address, wrong key) are semantically richer and should be harder.
- Base-model *under*-detection is the mirror image of FaulT-Bench's *over*-diagnosis. Measure both.

#### A5. Isaac et al. — ML on PCAP frames first, LLM explanation second
**Citation.** Joseph H. R. Isaac, Harish Saradagam, Nallamothu Pardhasaradhi (one notes file attributes them to Ericsson GAIA), "5G Core Fault Detection and Root Cause Analysis using Machine Learning and Generative AI," arXiv:2508.09152, 4 Aug 2025; CoaCoNS 2025. https://arxiv.org/abs/2508.09152

**Status.** VERIFIED (abstract only, in three notes files). The HTML returned 404 and the PDF text could not be extracted. The "golden call flow" detail is UNVERIFIED.

**Summary.**
- An ML "Fault Analysis Engine" uses NLP to classify 5G packet-core PCAP frames as successful or faulty.
- An LLM grounded in 3GPP and internal test documents then explains the error and suggests fixes.
- Only "high classification accuracy" on an 80/20 split is reported. No testbed, taxonomy or dataset is released.
- UNVERIFIED (search summary): traces are compared with an expected "golden" call flow, flagging, for example, a Registration Reject where an Initial Context Setup Request was expected.

**Correlation with our project.** The Broker's PCAP ingestion and the Falsifier's predicate types, such as "message X precedes message Y".

**What it tells us.** "Deterministic protocol-flow check first, LLM explains second" is existing precedent. It supports a golden-flow predicate library for the NGAP, F1AP and NAS procedures.

#### A6. DAST — VLM→LLM→VLM cross-interface anomaly detection in O-RAN
**Citation.** Francesco Spinelli, Esteban Municio, Pau Baguer, Gines Garcia-Aviles, Xavier Costa-Perez, "DAST: A VLM-LLM Framework for Cross-Interface Anomaly Detection in O-RAN," arXiv:2606.06261, 4 Jun 2026; submitted to IEEE. https://arxiv.org/abs/2606.06261

**Status.** VERIFIED (abstract).

**Summary.**
- **Method:** a zero-shot three-stage chain. A VLM renders KPI streams as images; an LLM scores per-interface text descriptions against O-RAN knowledge; a second VLM re-checks suspect intervals on high-resolution heatmaps.
- **Output:** the problematic interfaces, the time intervals, an O-RAN WG11-aligned impact rating, and its reasoning.
- **Results:** **F1 0.910 and accuracy 0.843** on real O-RAN testbed traces, beating state-of-the-art time-series anomaly detectors.
- **Related work:** several authors also appear on the UPC/NEC thesis (E4) and the "Attacking O-RAN Interfaces" paper (E5).

**Correlation with our project.** The format of the Generator's input summary, the KPI-based no-LLM baseline, and a lightweight re-check stage.

**What it tells us.**
- Raw multivariate KPIs are hard for LLMs directly; DAST needed rendering plus per-interface text.
- The Broker summary should be per interface (F1, NG, Uu) and keep time intervals.
- DAST addresses detection and interface localisation, not root cause. Our claims should centre on identification and verification, where a z-score baseline is weaker.

#### A7. QoEReasoner — deterministic KPI tools plus a protocol knowledge base plus a stateful planner
**Citation.** Q. Li, H. Chen, S. Dai, Z. Li, Z. Hu, X. Li, G. Zhu, Q. Shi, "QoEReasoner: An Agentic Reasoning Framework for Automated and Explainable QoE Diagnosis in RANs," arXiv:2606.01925, Jun 2026. https://arxiv.org/abs/2606.01925

**Status.** VERIFIED (abstract only). The LLM backbones are not named.

**Summary.**
- **Motivation:** LLMs on raw RAN telemetry "struggle with numeric time-series analysis, produce invalid causal links, and lack state tracking".
- **Design:** deterministic tools turn KPIs into structured evidence; a knowledge base "enforces protocol-consistent fault propagation"; a bank of expert-validated cases guides hypothesis generation; and a stateful planner runs detection → causal tracing → root-cause localisation.
- **Results:** it outperforms baselines by **18–40%** in accuracy and cuts diagnosis time **from about 30 to about 3 minutes**, robustly across backbones, on real operational RAN data.

**Correlation with our project.** The closest architectural analogue to Architecture A and a related-work anchor. It also validates the Broker's deterministic evidence extraction.

**What it tells us.** Deterministic evidence plus constrained causal links is the winning pattern. VERDICT must differentiate through adversarial falsification and abstention, not through "deterministic tools" alone.

#### A8. Pellejero et al. — agentic design patterns for RAN management
**Citation.** Jorge Pellejero, Luis A. Hernández Gómez, Luis Mendo Tomás, Zoraida Frias Barroso, "Agentic AI for Mobile Network RAN Management and Optimization," arXiv:2511.02532, 4 Nov 2025. https://arxiv.org/abs/2511.02532

**Status.** VERIFIED (abstract only). The self-reflection detail is from a search summary.

**Summary.** The paper introduces agentic design patterns for RAN: reflection, planning, tool use and multi-agent. A 5G case study combines time-series analytics with large-model agents for KPI-based decisions. The abstract reports no RCA numbers. Per the search summary, a reasoning pass is followed by self-reflection that checks dependencies across network layers.

**Correlation with our project.** Background for Architectures A and B.

**What it tells us.** Self-reflection inside one agent is the common pattern, and a separate adversarial Falsifier is the contrast to draw. This is weak evidence (no numbers).

#### A9. Gajjar & Shah position paper — agents as the 6G AI-RAN orchestrator
**Citation.** Pranshav Gajjar, Vijay K. Shah, "Agents Should Replace Narrow Predictive AI as the Orchestrator in 6G AI-RAN," arXiv:2605.11516, 12 May 2026. https://arxiv.org/abs/2605.11516

**Status.** VERIFIED (abstract; two notes files, merged).

**Summary.** A position paper with no experiments. It argues that "Large Telecom Model" agents should orchestrate the RIC, and that with RAG they could "autonomously diagnose complex, multi-vendor network anomalies". It explicitly calls for **"neuro-symbolic verification to curb hallucinations"** and for defences against prompt injection.

**Correlation with our project.** External motivation for the Falsifier and for deterministic re-execution.

**What it tells us.** The O-RAN community itself names the verification gap that VERDICT targets. This is citable framing, not evidence.

#### A10. Navidan et al. — multi-scale agentic O-RAN (LLM rApp, SLM xApps, PHY foundation-model agents)
**Citation.** H. Navidan, M. Cheraghinia, J. Fontaine, M. Seif, E. De Poorter, H. V. Poor, I. Moerman, A. Shahid, "Toward Autonomous O-RAN: A Multi-Scale Agentic AI Framework for Real-Time Network Control and Management," IEEE Network (accepted), DOI 10.1109/MNET.2026.3701847; arXiv:2602.14117 (v3 Jun 2026). https://arxiv.org/abs/2602.14117

**Status.** VERIFIED (abstract).

**Summary.** The framework is a hierarchy. A Non-RT RIC LLM agent turns intent into policy and manages model lifecycles. Near-RT RIC SLM agents tune or disable control apps. PHY foundation-model agents run near the DU. An open-source proof of concept covers robustness and intent-driven slicing, with no numbers in the abstract.

**Correlation with our project.** Places an RCA assistant at the Non-RT RIC/SMO level.

**What it tells us.** Use it for positioning only; it does not address RCA.

#### A11. xTRUCE — a deterministic arbiter for hallucinated LLM-xApp proposals
**Citation.** L. Xia, R. Q. Hu, P. S. Kudyba, Z. An, H. Sun, "xTRUCE," arXiv:2608.28532, Aug 2026; submitted to IEEE. https://arxiv.org/abs/2608.28532

**Status.** VERIFIED (abstract).

**Summary.** xTRUCE is a provably safe Near-RT RIC arbiter for conflicts among LLM xApps whose proposals may be "conflicting, infeasible, or hallucinated". It has a structured proposal interface, a three-layer constraint hierarchy and two-stage arbitration, and it returns conflict certificates. On OAI/FlexRIC with live LLM xApps and over the air, it protected **100% of services** despite severe hallucinations.

**Correlation with our project.** The typed predicate language and the deterministic Orchestrator.

**What it tells us.** "LLM proposes in a typed schema, a deterministic layer verifies and certifies" is gaining traction in agentic O-RAN. That helps position VERDICT and argues for a strict predicate schema.

#### A12. AutORAN — natural-language-to-xApp generation
**Citation.** X. Li, S. Yu, L. Shen, J. Zhang, Y. Zheng, Y. Xie, "AutORAN," arXiv:2603.18604, Mar 2026. https://arxiv.org/abs/2603.18604

**Status.** VERIFIED (abstract). Part of the intro claim comes from a search snippet.

**Summary.** AutORAN is billed as the first LLM-driven natural-language programming framework for xApps. It covers requirement elicitation, AI/ML design and validation, synthesis and deployment, and its generated xApps match or beat hand-crafted baselines. The paper argues that off-the-shelf LLMs "cannot directly generate correct or deployable xApps": they lack O-RAN knowledge, violate interface semantics and hallucinate control logic.

**Correlation with our project.** How the Falsifier writes predicates.

**What it tells us.** Free-form code from an LLM will reference non-existent fields and counters. Predicates need a typed DSL validated against the Broker schema.

#### A13. Zhou et al. — survey of LLMs for telecommunications
**Citation.** Zhou et al., "Large Language Model (LLM) for Telecommunications: A Comprehensive Survey on Principles, Key Techniques, and Opportunities," arXiv:2405.10825 (v2, Sep 2024). https://arxiv.org/abs/2405.10825

**Status.** VERIFIED (abstract). The cited COMST 2025 version is UNVERIFIED.

**Summary.** A broad survey of LLM-for-telecom principles and techniques, including troubleshooting.

**Correlation with our project.** Background for the GenAI part of the survey.

**What it tells us.** Use it for context only; it contains no RCA evidence.

#### A14. Ameur, Mekrache, Brik, Ksentini — tutorial and survey on agentic AI for 5G/6G
**Citation.** "LLM-Powered Agentic AI for 5G/6G Networks: A Tutorial and Survey on Architectures, Protocols, and Standardization," arXiv:2607.16066, 17 Jul 2026. https://arxiv.org/abs/2607.16066

**Status.** VERIFIED (abstract). The coverage details come from a search summary.

**Summary.** A survey covering O-RAN troubleshooting agents and the risk of prompt injection over A1/E2/O1.

**Correlation with our project.** Positioning, and the threat model for an alarm-fed Generator.

**What it tells us.** Alarm and ticket text is an injection surface. This is one more reason to keep the Generator blind to raw text from the network.

#### A15. Tran et al. — building an RCA knowledge base with LLMs
**Citation.** Tran, Jaumard, Delgado, Glatard, Premkumar, Ni, "LLM-Augmented Knowledge Base Construction For Root Cause Analysis," arXiv:2604.06171; IEEE Access (accepted). https://arxiv.org/abs/2604.06171

**Status.** VERIFIED (abstract).

**Summary.** Compares fine-tuning, RAG and a hybrid for building an RCA knowledge base from real industrial support tickets.

**Correlation with our project.** The Generator's knowledge source, if Cyshield provides tickets.

**What it tells us.** Low relevance for the OCUDU corpus.

#### A16. Shi et al. (Ericsson) — LLM fine-tuning on a single edge GPU
**Citation.** "Edge-Deployable LLM Fine-Tuning on a Single GPU for Telecom Network Troubleshooting," arXiv:2607.02523. https://arxiv.org/abs/2607.02523

**Status.** VERIFIED (abstract).

**Summary.** A GPU profiling study of SFT and RFT for troubleshooting Q&A.

**Correlation with our project.** Cost only.

**What it tells us.** Relevant only if the team ever fine-tunes, which the scope recommendation below excludes.

#### A17. Daniel et al. — an LLM-enabled NWDAF
**Citation.** "LLM-Enabled NWDAF," arXiv:2606.11877. https://arxiv.org/abs/2606.11877

**Status.** VERIFIED (abstract).

**Summary.** An open-source NWDAF for free5GC, with Prometheus analytics and an LLM intent interface.

**Correlation with our project.** A possible reference for collecting core-side KPIs in the Broker.

**What it tells us.** It is a template for exporting core analytics to Prometheus. Our core is Open5GS, so it is not a drop-in.

#### A18–A19. Unverified agentic O-RAN leads
**A18. LLM-xApp** (UNVERIFIED). An LLM-prompted RRM xApp evaluated on the OAIC platform, found via [NSF PAR](https://par.nsf.gov/servlets/purl/10628444).

**A19. "Multi-Agentic AI for Conflict-Aware rApp Policy Orchestration in Open RAN"** (UNVERIFIED), [arXiv:2603.07375](https://arxiv.org/pdf/2603.07375).

Neither was opened, and both address control rather than RCA. The TM Forum multi-agent fault-repair Catalyst ([TM Forum](https://inform.tmforum.org/research-and-analysis/proofs-of-concept/how-multi-agent-ai-is-transforming-network-fault-repair)) is industry material and was not assessed.

### Theme B — Agent failure modes and reasoning-process evaluation in network operations

#### B1. NIKA — network-incident arena: detection is easy, localization and RCA are not
**Citation.** Zhihao Wang, Alessandro Cornacchia, Alessio Sacco, Franco Galante, Marco Canini, Dingde Jiang, "A Network Arena for Benchmarking AI Agents on Network Troubleshooting," arXiv:2512.16381, 18 Dec 2025 (preprint; no venue stated). https://arxiv.org/abs/2512.16381 — code: https://github.com/sands-lab/nika

**Status.** VERIFIED (full HTML; three notes files, merged).

**Summary.**
- **Benchmark:** 640 incidents covering 54 issue types in 6 categories (including 14 misconfiguration types) across 5 scenarios: DC CLOS, campus, ISP backbone, SDN cloud POP and P4. The evaluation subset is 150 incidents, each run twice.
- **Environment:** Kathará container emulation with tc and scripted fault injection.
- **Tooling discrepancy:** one notes file says agents get "30+ tools via an MCP-based Agent Access Layer"; another reports 22 tools, citing FaulT-Bench's description. The notes do not resolve this.
- **Results (Detection / Localization / RCA, steps, tool calls):**
  - GPT-OSS-20B: 19.0% / 5.5% / 5.5%, 12.6 steps, 11.7 tool calls.
  - GPT-5-mini: 74.0% / 36.0% / 22.0%, 9.5 steps, 15.0 tool calls.
  - GPT-5: **89.0% / 68.7% / 55.3%**, 7.0 steps, 28.4 tool calls.
- **By fault type:** GPT-5 localization is 97% for link failures but 58% for resource contention.
- **Tool errors:** only 1.6% (GPT-5-mini) and 0.7% (GPT-5), mostly parameter mismatches.
- **Failures:** shallow, connectivity-centric diagnoses ("link unstable", "transient congestion") despite CRC-error and queue-drop evidence; poor integration of application-layer tools; and degradation with topology size (about 11 → 27 → 101 nodes), with tokens nearly doubling.
- **Side effects:** NIKA also scores the network side-effects of diagnosis.

**Correlation with our project.**
- A ready template for splitting top-1 accuracy into detection / localization / RCA.
- Our "DU CPU starvation" fault is a resource-contention fault, NIKA's hardest class.
- Architecture A can expose Broker queries as MCP tools, following NIKA.

**What it tells us.**
- Expect vague "degradation" answers on the CPU-starvation and channel-noise faults. That is where typed predicates over counters help most.
- The Falsifier should require *coverage*: a hypothesis must explain all salient anomalies, not just one.
- Tool-call hallucination is rare, so typed predicates matter for linking evidence to claims, not for preventing malformed calls.
- VERDICT is read-only on an immutable snapshot. That removes NIKA's side-effect risk by design and is worth stating as a safety property.

#### B2. FaulT-Bench — agents over-diagnose healthy networks when tickets are misleading
**Citation.** Kuan-Hao Tseng, Niruth Bogahawatta, Yasod Ginige, Kunjan Patel, Kosta Dakic, Suranga Seneviratne (Univ. of Sydney), "FaulT-Bench: Towards Benchmarking Network Troubleshooting LLM Agents under Unreliable User Tickets," arXiv:2608.27021, 27 Aug 2026 (preprint). https://arxiv.org/abs/2608.27021

**Status.** VERIFIED (full HTML; three notes files, merged; one listed it only as a lead). Internal inconsistency: the Related Work section says "170 free-text tickets", while the rest of the paper reports 200 scenarios.

**Summary.**
- **Scenarios:** 200 Kathará scenarios over 8 topologies (3 from NIKA): 80 Correct-Fault, 72 False-Premise (healthy network), 24 Wrong-Device and 24 Wrong-Cause.
- **Personas:** the 72 False-Premise tickets are rewritten into 5 reporter personas (360 rewrites) with the network state held fixed.
- **Agents:** SADE (claude-sonnet-4-6), Claude Code and ReAct (GPT-5), each with NIKA's tools and a 20-turn budget.
- **Scoring:** a gpt-5-mini judge computes outcome = 0.7 × diagnosis accuracy + 0.3 × explanation quality; a fix score of 1, 0.5 or 0; and a reasoning score of (grounding + causality + coverage) / 30.
- **Outcomes:** Correct-Fault mean outcome 0.932; False-Premise 0.820 (−0.112).
- **Over-diagnosis on healthy networks** (share of answered runs reporting a fault): **SADE 24% (51/210), ReAct 16% (33/209), Claude Code 11% (21/198)**.
- **By persona:** Standard 17%, Novice 31%, Naive-unsure 35%, Naive-no-detail **47%**.
- **Ticket content:** removing the ticket's certainty costs 0.182 outcome, and removing identifiers costs a further 0.141. A confidently wrong ticket is handled about as well as an accurate one; vague tickets hurt most.
- **Cost:** spend was US$1,525 over 3,960 runs. Timeouts were 9% of runs but 23% of spend (36% of Claude Code's spend), and Claude Code timed out in up to 49% of no-detail runs.
- **Authors' diagnosis:** agents probe "until a benign condition can be promoted to a root cause". They lack "a criterion for concluding, with evidence, that no fault exists".

**Correlation with our project.** For VERDICT, this is the single most important new paper. It bears on the null-evidence condition, the "unresolved" output, the Generator's treatment of alarm text as a hypothesis rather than an instruction, the fratricide and void-refutation metrics, and the two-strike rule.

**What it tells us.**
- Over-diagnosis is the mirror image of fratricide: the system "verifies" a cause that does not exist.
- Add healthy-snapshot and misleading-alarm episodes, make "no fault" or "unresolved" a scoreable correct answer, and report a false-verification rate next to fratricide.
- Add alarm or ticket wording perturbation to the perturbation control.
- Report timeout cost separately.
- The grounding/causality/coverage rubric is reusable for R2.

#### B3. SADE — phase-gated diagnosis that separates evidence from commitment
**Citation.** Kuan-Hao Tseng, Niruth Bogahawatta, Yasod Ginige, Kosta Dekic, Arunan Sivanathan, Suranga Seneviratne, "Symptom-Aware Diagnostic Escalation for LLM-Based Network Troubleshooting," arXiv:2605.04530, 6 May 2026 (preprint). https://arxiv.org/abs/2605.04530

**Status.** VERIFIED (abstract/PDF page).

**Summary.**
- **Diagnosis of baseline agents:** they "rely on free-form deliberation that conflates evidence acquisition with hypothesis commitment".
- **Method:** the Cisco layer-by-layer methodology encoded as a phase-gated policy, with a routed library of fault-family skills and diagnostic helpers.
- **Results:** on 523 held-out NIKA incidents (11 unseen scenarios), root-cause F1 is **+37 pp over ReAct + GPT-5**. A same-backend (Claude Sonnet) ablation attributes **22 pp to the policy alone**.

**Correlation with our project.** The Generator/Falsifier split and the Orchestrator's phase structure.

**What it tells us.**
- This is the strongest network-domain effect size for structurally separating hypothesis generation from evidence handling.
- Cross-paper warning: the same SADE agent has the highest over-diagnosis in FaulT-Bench (24%; 20–34% false alarms regardless of wording). Disciplined pipelines can trade specificity for sensitivity, and VERDICT must report both.

#### B4. NetArena (formerly NetPress) — dynamic benchmarks; small static sets cannot separate agents
**Citation.** Yajie Zhou, Jiajun Ruan, Eric S. Wang, Sadjad Fouladi, Francis Y. Yan, Kevin Hsieh, Zaoxing Liu, arXiv:2506.03231. v1 (3 Jun 2025) was titled "NetPress: Dynamically Generated LLM Benchmarks for Network Applications"; v2 (13 Mar 2026) is "NetArena: Dynamic Benchmarks for AI Agents in Network Automation". https://arxiv.org/abs/2506.03231

**Status.** VERIFIED (abstract plus partial v2 HTML, truncated). An ICLR 2026 poster listing was seen in search but not fetched.

**Summary.**
- **Applications:** datacenter capacity planning on a ~5,493-node topology, routing-misconfiguration repair in Mininet, and Kubernetes network-policy troubleshooting.
- **Scoring:** correctness is final-state equivalence; safety is checked at every step; latency is the number of steps.
- **Results:** average correctness is 24%, with the best agent below 60%. The abstract reports 13–38% on large realistic queries, and as low as 3%.
- **Statistical power:** confidence-interval overlap between agents falls "from as high as 85% to 0%" when moving from small static sets (under 200 queries) to large generated ones.
- **Failures:** hallucinated node attributes, wrong-layer capacity, misordered commands, correct-but-unsafe fixes, over-aggressive versus over-conservative agents, and redundant command sequences.
- **Training:** mixed-level SFT keeps correctness above 0.96, while level-specific SFT overfits.

**Correlation with our project.** Corpus size and statistics, and the perturbation (contamination) control.

**What it tells us.** With a few dozen faults, differences between configurations will sit inside the noise. Report bootstrap confidence intervals and generate many parameterised instances.

#### B5. Safety Signals — per-action verification; LLM judges get worse with longer trajectories
**Citation.** Tobias Labarta, Frederik Pahde, Novak Boškov, Maximilian Dreyer, David Birkenberger, Manzoor Ahmed Khan, Sebastian Lapuschkin, Wojciech Samek, "Safety Signals to Verify NetOps Agents with Action-Level Granularity," arXiv:2609.14422 (v2 16 Sep 2026). https://arxiv.org/abs/2609.14422

**Status.** VERIFIED (v2 HTML).

**Summary.**
- **Ground truth:** per-action labels for NetArena's routing-repair task come from a symbolic replay checked against the emulator every turn. Each action counts as progress (repair distance down) or harm (repair distance up).
- **Agents:** across 10 models, repaired episodes range from 18% (Nemotron-3-Nano-9B) to 77% (Gemma-4-31B).
- **Behaviour:** harmful actions rise as repair success falls, and the share of turns spent inspecting correlates with success (**r_s = +0.78**).
- **Verifiers:** probes on model-internal signals cut false negatives on harm by **38%** at k=3 (sensitivity 0.845 → 0.905). **The LLM-as-a-judge baseline peaks at k=1 and declines as k grows.**
- **Caveat:** 9.1% of turns were excluded because the symbolic replay disagreed with the benchmark.

**Correlation with our project.** R2's process evaluation, and the Orchestrator's deterministic per-step re-execution.

**What it tells us.** Score the trajectory with deterministic per-step checks, not an LLM judge. Add an "inspection-before-commit" metric, such as the share of hypotheses that have at least one executed predicate.

#### B6. ANI-Gamut — typed, bounded interfaces beat raw shell access
**Citation.** Lorenzo Bracciale, Pierpaolo Loreti, Andrea Mayer, Stefano Salsano, Wim Henderickx, "Benchmarking Agent Reliability across the Gamut of Agent-Network Interface Abstractions," arXiv:2609.22723, 19 Sep 2026; extended version of a CNSM 2026 paper. https://arxiv.org/abs/2609.22723

**Status.** VERIFIED (abstract).

**Summary.** The interface abstraction is the controlled variable, from raw CLI (A0) up to typed transactional intent (A3-T) and a reconciled source of truth (A3-R). In a pilot (n = 20/6/4 per level) on a live change-set task, the raw-shell agent failed all 6 seeds, while the typed transactional interface succeeded on all 6 (**McNemar p = 0.031**) at about one tenth of the cost. There was no collateral damage at any level.

**Correlation with our project.** The typed predicate language.

**What it tells us.** This is pilot-scale but direct evidence that typed, bounded interfaces improve both reliability and cost.

#### B7. NetAgentBench — FSM-formalised evaluation of multi-turn agents
**Citation.** Ahmed Twabi, Yepeng Ding, Tohru Kondo, "NetAgentBench: A State-Centric Benchmark for Evaluating Agentic Network Configuration," arXiv:2604.09678, 3 Apr 2026. https://arxiv.org/abs/2604.09678

**Status.** VERIFIED (abstract only; no numbers).

**Summary.** A finite-state-machine formalisation guarantees determinism, correctness and bounded execution. Four LLM agents handled the basic tasks but showed "exploration meltdowns and coherence collapse" on expert-level configuration.

**Correlation with our project.** The bounded Orchestrator, the two-strike rule, and FSM-style scoring of trajectories.

**What it tells us.** This is the network counterpart of cloud "stalled/confused" behaviour. Bound the loop and score its states.

#### B8. TeleResilienceBench — models rarely recover from inherited flawed reasoning
**Citation.** Pranshav Gajjar, Emmanuel Ojo, Vijay K. Shah, "TeleResilienceBench: Quantifying Resilience for LLM Reasoning in Telecommunications," arXiv:2605.09929, 11 May 2026. https://arxiv.org/abs/2605.09929

**Status.** VERIFIED (abstract). The "3GPP_TSG impervious" quote is from a search snippet of the full text.

**Summary.** Failed reasoning traces from a weak model, across 7 GSMA Open-Telco sub-domains, are cut at the midpoint, and a target model must continue and correct them. Across 8 models (Qwen3.5, Gemma4, Nemotron-3), the best macro **Correct Flip Rate is 29.1%**. Scale does not reliably help: Nemotron-3-nano-4B beats every Qwen3.5 size up to 27B. Difficulty labels track factual specificity rather than reasoning depth.

**Correlation with our project.** The Falsifier receives the Generator's hypothesis. This bears on void refutations and on missed refutations.

**What it tells us.**
- An LLM critic that reads the Generator's reasoning will tend to anchor on it.
- Show the Falsifier only the claim, force refutation through executable predicates, and add a missed-refutation rate (the critic accepts a wrong hypothesis) next to fratricide.

#### B9. Twin-Pass CoT-Ensembling — telecom LLMs are systematically overconfident
**Citation.** Anton Saenko, Pranshav Gajjar, Abiodun Ganiyu, Vijay K. Shah, "Enhancing Confidence Estimation in Telco LLMs via Twin-Pass CoT-Ensembling," arXiv:2604.13271, 14 Apr 2026. https://arxiv.org/abs/2604.13271

**Status.** VERIFIED (abstract).

**Summary.** Gemma-3 at 4B, 12B and 27B was tested on TeleQnA, ORANBench and srsRANBench. Single-pass verbalised confidence shows "systematic overconfidence". Twin-pass CoT ensembling cuts expected calibration error (ECE) by **up to 88%**. No accuracy gains are reported.

**Correlation with our project.** The "unresolved" decision and any reported confidence.

**What it tells us.** Never base abstention on self-reported confidence. If confidence is reported, derive it from ensembling or self-consistency.

#### B10. Sengupta et al. — free-text 5G evaluation with LLM-as-judge
**Citation.** Rishiraj Sengupta, Sotiris Chatzimiltis, Mohammad Shojafar, Xiatian Zhu, "Free-Text Evaluation of LLMs for 5G Domain Knowledge and Fault Analysis using LLM-as-Judge," arXiv:2608.21021, 21 Aug 2026; IEEE CSCN (accepted). https://arxiv.org/abs/2608.21021

**Status.** VERIFIED (full HTML in one notes file; abstract in two; merged, consistent).

**Summary.**
- **Setup:** Claude-Haiku-4.5, GPT-5.4-Mini and Gemini-3.1-Flash-Lite answered free-text versions of TeleQnA-ORAN, 5G-Faults (100 items derived from greenwich157/5G-Faults-Full-v2, with the multiple-choice options removed) and TeleInter. Three frontier judges graded each answer as correct or incorrect.
- **Fault diagnosis:** Haiku **90.0%**, GPT-5.4-Mini **98.3%**, Gemini Flash-Lite **95.3%**.
- **Spec recall:** zero-shot 3GPP/O-RAN recall is **below 60%** for all three.
- **Judges:** mean inter-judge agreement is at least 0.90, yet GPT-5.5 graded Haiku at **82%** where both Gemini judges gave about **94%**. The authors note that agreement is not correctness, and no human validation is reported.
- **Recommendation:** Gemini Flash-Lite, on cost and latency.

**Correlation with our project.** R2's evaluation methodology, the null-evidence control, and the Generator's prior.

**What it tells us.**
- Text-only fault Q&A is saturated, and its fault sets look pattern-matchable. Interactive telemetry RCA is the real test.
- Any LLM judge needs calibration against human experts.
- Spec retrieval must be mandatory.

#### B11. Nakamura & Eguchi — LLM help for operators at a large demonstration network
**Citation.** Ryo Nakamura, Koshi Eguchi, "How Helpful is LLM Assistance in Network Operations? A Case Study at a Large Demonstration Network," IEEE NOMS 2026, pp. 1–10; arXiv:2605.19627. https://arxiv.org/abs/2605.19627

**Status.** VERIFIED (abstract).

**Summary.** 105 engineers used a chatbot with RAG, CLI control and ticket access while building and running a 21-rack network. **68.1%** of evaluations were positive, and users who understood the chatbot's capabilities got better answers.

**Correlation with our project.** The dashboard and assistant UX.

**What it tells us.** This is a helpfulness baseline, not an RCA-accuracy measure.

#### B12. NetConfEval — an LLM front end with a formal back end for network configuration
**Citation.** Changjie Wang, Mariano Scazzariello, Alireza Farshin, Simone Ferlin, Dejan Kostić, Marco Chiesa, "Can LLMs Facilitate Network Configuration?", Proc. ACM Netw. 2(CoNEXT2), Art. 7, June 2024, DOI 10.1145/3656296. Metadata via [Red Hat Research](https://research.redhat.com/blog/publication/can-llms-facilitate-network-configuration/).

**Status.** VERIFIED (metadata; the ACM page returned 403). The "small models suffice for spec translation" claim is from a snippet.

**Summary.** Four tasks: requirements to formal specification, API calls, routing algorithms, and low-level configuration. Two GPT-4 prototypes pair an LLM front end with existing network synthesizers.

**Correlation with our project.** The Falsifier plus deterministic re-execution pattern.

**What it tells us.** It is configuration-side precedent for "LLM proposes, formal tool verifies".

#### B13. LogGPT — ChatGPT for log anomaly detection
**Citation.** Jiaxing Qi, Shaohan Huang, Zhongzhi Luan, Carol Fung, Hailong Yang, Depei Qian, "LogGPT: Exploring ChatGPT for Log-Based Anomaly Detection," arXiv:2309.01189, 3 Sep 2023. https://arxiv.org/abs/2309.01189

**Status.** VERIFIED (abstract; no numbers). The high-false-positive claim is UNVERIFIED (snippet).

**Summary.** ChatGPT was evaluated on BGL and Spirit logs. A snippet reports a high false-positive rate and sensitivity to the prompt.

**Correlation with our project.** The null-evidence condition.

**What it tells us.** A possible log-domain analogue of over-diagnosis; check it before citing.

#### B14–B18. Unverified network-agent leads
All of these were seen only in search results:
- **B14.** "Towards a Playground to Democratize Experimentation and Benchmarking of AI Agents for Network Troubleshooting", the NIKA precursor (LLM4NetLab, SIGCOMM 2025 NGNO), [arXiv:2507.01997](https://arxiv.org/pdf/2507.01997).
- **B15.** RoutingBench, arXiv:2609.22848.
- **B16.** "LLMs for Agentic NetOps and AIOps: Architectures, Evaluation, and Safety" (survey), arXiv:2605.12729.
- **B17.** LLMParser (ICSE 2024), arXiv:2404.18001.
- **B18.** NetOpsBench (NetX-lab), known only from a citation.

None should be cited until opened.

### Theme C — Telecom/O-RAN LLMs and specification RAG (knowledge layer and model screening)

#### C1. TeleQnA — 10,000 telecom MCQs; standards specs are the weak spot
**Citation.** A. Maatouk, F. Ayed, N. Piovesan, A. De Domenico, M. Debbah, Z.-Q. Luo, "TeleQnA: A Benchmark Dataset to Assess Large Language Models Telecommunications Knowledge," arXiv:2310.15051, 23 Oct 2023. https://arxiv.org/abs/2310.15051

**Status.** VERIFIED (full text). Password protection of the dataset and the "digest and memorize" quote are UNVERIFIED snippets.

**Summary.**
- **Dataset:** 10,000 MCQs: Lexicon 500, Research overview 2,000, Research publications 4,500, Standards overview 1,000, Standards specifications 2,000.
- **Accuracy (GPT-3.5 / GPT-4 / professionals):**
  - Lexicon: 82.20 / 86.80 / 80.33
  - Standards specifications: **56.97 / 64.78 / 56.33**
  - Overall: 67.29 / 74.91 / 64.86
- **Retrieval:** retrieved context (~500-word segments, Ada-v2 embeddings, top 3) gave a 22.5% relative gain on standards specs for GPT-3.5.

**Correlation with our project.** Model screening, and the spec-retrieval tool.

**What it tells us.**
- The standards-spec subset is a cheap first filter.
- Clause-level recall is weak even for strong models, so spec retrieval should be mandatory.

#### C2. ORAN-Bench-13K — general LLMs are "not proficient in O-RAN"
**Citation.** P. Gajjar, V. K. Shah, "ORAN-Bench-13K: An Open Source Benchmark for Assessing LLMs in Open Radio Access Networks," arXiv:2407.06245, Jul 2024. https://arxiv.org/abs/2407.06245

**Status.** VERIFIED (abstract).

**Summary.** 13,952 MCQs from 116 O-RAN specifications at three difficulty levels. The ORANSight RAG pipeline reaches macro accuracy 0.784 and weighted accuracy 0.776, about 21.55% and 22.59% above the other LLMs tested.

**Correlation with our project.** An O-RAN knowledge screen for Generator and Falsifier candidates.

**What it tells us.** RAG over O-RAN specs is a large lever for O-RAN knowledge questions.

#### C3. ORANSight-2.0 — the main evidence for screening open-weight models
**Citation.** P. Gajjar, V. K. Shah, "ORANSight-2.0: Foundational LLMs for O-RAN," arXiv:2503.05200, Mar 2025 (v2 Jul 2025). https://arxiv.org/abs/2503.05200

**Status.** VERIFIED (full text).

**Summary.**
- **Training:** QLoRA fine-tuning of 18 open models (1B–70B) on RANSTRUCT, 151,500 instruction pairs (58.6% from the srsRAN codebase, 41.4% from O-RAN specs), all on a single RTX 4090.
- **Benchmarks:** ORANBench (1,500 questions) and srsRANBench (1,502 questions).
- **Best cumulative scores:**
  - Qwen-2.5 32B: **0.794**, against GPT-4o at 0.760 (+4.47%).
  - Gemma-2 27B: **0.829**, with srsRANBench **0.911**.
  - Mistral 22B: 0.790.
  - Mistral-Nemo 12B: 0.772.
  - The smallest models to beat GPT-4o were Gemma-2 9B and Qwen-2.5 7B.
- **Weak families:** Llama 1B/3B "struggle", and Llama and Phi generally lag.
- **Quantisation:** 2-bit AQLM 70B and 8x7B models show diminishing returns.
- **RAG at inference** (FAISS, bge-large, 88,808 chunks):
  - Qwen-2.5 32B 0.795 → **0.854**. One notes file gives the base as 0.794 and another as 0.795.
  - Gemma-2 9B 0.787 → 0.834.
  - Mistral-Nemo 0.772 → 0.821.
  - Gemma-2 27B *dropped* 0.829 → 0.820.
  - RAG added about 9.5% inference energy.
- **Earlier telecom LLMs:** ORANSight-2.0 beats Tele-LLM, TSpec-LLM and the NVIDIA O-RAN chatbot by 55.1%, 37.4% and 7.6% on ORANBench.

**Correlation with our project.** Model screening, and srsRAN-code understanding (OCUDU is srsRAN-derived).

**What it tells us.**
- Screen the Qwen-2.5 and Gemma-2 families and their successors at 7–32B.
- Test every candidate with and without RAG.
- Models of 1–3B are not viable.

#### C4. TSpec-LLM — an open dataset of all 3GPP documents
**Citation.** R. Nikbakht, M. Benzaghta, G. Geraci, "TSpec-LLM: An Open-source Dataset for LLM Understanding of 3GPP Specifications," arXiv:2406.01768, 3 Jun 2024. https://arxiv.org/abs/2406.01768

**Status.** VERIFIED (abstract).

**Summary.** The dataset covers 3GPP Rel-8 to Rel-19 (1999–2023). Naive RAG raised accuracy from 44% to **71%** (GPT-3.5), 46% to 75% (Gemini 1.0 Pro) and 51% to 72% (GPT-4).

**Correlation with our project.** The corpus for the spec-retrieval index.

**What it tells us.** A ready-made corpus with a large naive-RAG gain.

#### C5. Telco-RAG — retrieval engineering that matters for acronym-dense telecom text
**Citation.** A.-L. Bornea, F. Ayed, A. De Domenico, N. Piovesan, A. Maatouk, "Telco-RAG: Navigating the Challenges of Retrieval-Augmented Language Models for Telecommunications," IEEE Globecom 2024; arXiv:2404.15939. https://arxiv.org/abs/2404.15939

**Status.** VERIFIED (full text).

**Summary.**
- **Pipeline:** a glossary expands abbreviations in the query; candidate answers refine the query (+1.2 to +4.8 points); and a neural router picks the 3GPP series. The router's top-1/3/5 rates are 51.3% / 80.6% / 88.3%, against 30.4% / 70.8% / 85.6% for GPT-4, and it uses 45% less RAM.
- **Settings:** 125-token chunks beat 500-token chunks by 2.9%, and text-embedding-3-large beats ada-002 by 2.29%. Accuracy rises with context up to about 1,500 tokens.
- **Results:** lexicon questions go from 80.2% (no context) to 84.8% (benchmark RAG) to **90.8%**. On 1,840 3GPP MCQs, Telco-RAG is 6.6% above benchmark RAG and **14.45%** above no RAG.

**Correlation with our project.** Design of the spec-retrieval tool, and acronym expansion for log and trace queries.

**What it tells us.** Small chunks and glossary expansion are cheap wins on acronym-heavy OCUDU logs.

#### C6. Chat3GPP — a fully open RAG recipe reaching 0.787 with no fine-tuning
**Citation.** L. Huang, M. Zhao, L. Xiao, X. Zhang, J. Hu, "Chat3GPP: An Open-Source Retrieval-Augmented Generation Framework for 3GPP Documents," arXiv:2501.13954, 20 Jan 2025. https://arxiv.org/abs/2501.13954

**Status.** VERIFIED (full text).

**Summary.**
- **Corpus:** Rel-17 and Rel-18 specs, text only; tables, figures and the Contents/References/Annex sections are dropped.
- **Chunking:** hierarchical by subheading, with the full title path on each chunk, then recursive splitting to about 1,250 characters.
- **Retrieval:** BGE-M3 dense plus BM25 (Elasticsearch HNSW), merged with Reciprocal Rank Fusion, then a BGE-M3 rerank to the top 5. The generator is Llama-3-8B-Instruct.
- **Results:** on the TeleQnA 3GPP subset, Rel-17 0.783, Rel-18 0.791, overall **0.787**, against Telco-RAG at 0.725 / 0.784 and Llama3-8B-Tele-it at 0.531 / 0.571. On Tele-Eval open-ended questions it scores 0.543, against 0.273 for Tele-it.

**Correlation with our project.** The closest open, budget-friendly blueprint for the spec tool.

**What it tells us.**
- It does not handle tables or ASN.1, so field-level IE semantics (cause values) must come from Wireshark/ASN.1 decoders, not text RAG.
- No paper shows that spec RAG improves *RCA*, as opposed to MCQ accuracy.

#### C7. Tele-LLMs — small telecom-adapted models lag behind spec RAG
**Citation.** A. Maatouk, K. Chirino Ampudia, R. Ying, L. Tassiulas, "Tele-LLMs: A Series of Specialized Large Language Models for Telecommunications," arXiv:2409.05314 (v3 May 2025). https://arxiv.org/abs/2409.05314

**Status.** VERIFIED (abstract). The MCQ "selection bias" argument is an UNVERIFIED snippet.

**Summary.** The 1–8B models beat their base models on Tele-Eval "while avoiding catastrophic forgetting"; the abstract gives no numbers. Measured by Chat3GPP, Llama3-8B-Tele-it scores only 0.552 overall on the TeleQnA 3GPP subset.

**Correlation with our project.** Model screening.

**What it tells us.** Small domain-pretrained models are not a shortcut. Tele-Eval is an optional extra screen.

#### C8. TelecomGPT — telecom-specific pre-training without open weights
**Citation.** Zou, Zhao, Tian, Bariah, Bader, Lestable, Debbah, "TelecomGPT," arXiv:2407.09424, Jul 2024. https://arxiv.org/abs/2407.09424

**Status.** VERIFIED (abstract; no numbers).

**Summary.** Continual pre-training, then instruction tuning, then alignment. It beats GPT-4 on Telecom Math Modeling but is only "comparable" on TeleQnA, 3GPP document classification and code. ORANSight-2.0 excluded it because no open implementation exists.

**Correlation with our project.** Model screening.

**What it tells us.** It is not usable in screening. Its agentic successor TelecomGPT-R1 scored 4.76% on CTBench.

#### C9. RRC-LLM — the structure of RRC procedures is learnable
**Citation.** Z. Liu, B. Liu, A. Valcarce, X. Chu, "LLM-Based Emulation of the Radio Resource Control Layer: Towards AI-Native RAN Protocols," arXiv:2505.16821 (v5 Jan 2026). https://arxiv.org/abs/2505.16821

**Status.** VERIFIED (abstract). The dataset openness detail is from a snippet.

**Summary.** An 8B LoRA model trained on multi-vendor real 4G/5G RRC traces, with ASN.1 linearised into Q&A form (30k 5G request–response pairs and 4.8k 4G turns). It is checked for ASN.1 conformance, field coverage, uplink→downlink state-machine consistency and similarity. It reaches a **0.97 median cosine similarity** and a 61% gain over zero-shot. The real traces are proprietary; a synthetic nrRRC_Simulator corpus is open.

**Correlation with our project.** The Falsifier's procedure predicates.

**What it tells us.** Its ASN.1-conformance and state-machine checks are a template for golden-flow predicates. Decode deterministically rather than asking the LLM to parse bytes.

#### C10. CellularSpecSec-Bench — why 3GPP specs are hard for LLMs
**Citation.** K. Xie, X. Zhao, Y. Hu, S. Yuan, T. Xie, "CellularSpecSec-Bench / CellSpecSec-ARI," arXiv:2601.12716, Jan 2026. https://arxiv.org/abs/2601.12716

**Status.** VERIFIED (abstract; no numbers). The RRC 38.331 / NAS 24.501 coverage comes from a snippet.

**Summary.** It names three challenges: normative language, reasoning across cross-referenced clauses, and grounding in tables and figures. It supplies expert-corrected subsets of earlier datasets.

**Correlation with our project.** The design of spec-based predicates.

**What it tells us.** Spec-derived predicates are where Falsifier errors are most likely, so they should cite the retrieved clause.

#### C11. GSMA Open Telco benchmark suite
**Citation.** GSMA Open Telco (Inspect-AI based), [HF README](https://huggingface.co/spaces/GSMA/README/blob/main/README.md).

**Status.** VERIFIED (README; no scores). The leaderboard scores seen via a third-party mirror are UNVERIFIED: Qwen2.5-32B averages 50.7% (TeleMath 41.9%, TeleLogs 24.9%) and Qwen2.5-7B 45.8% ([mirror](https://benchmarklist.com/models/qwen-qwen2.5-32b/)). The GSMA newsroom page returned 403.

**Summary.** 16,866 samples across 7 benchmarks: TeleQnA 10,000; TeleMath 1,500; TeleTables 500; TeleLogs 586; 3GPP TSG 3,780; ORANBench 200; srsRANBench 300.

**Correlation with our project.** Stage 1 of model screening.

**What it tells us.** It is a ready "lite" knowledge screen. Do not quote the leaderboard numbers until they are confirmed with GSMA.

#### C12. LLM blind DoS detection in O-RAN (UNVERIFIED)
**Citation.** "From Description to Detection: LLM based Extendable O-RAN Compliant Blind DoS Detection," [arXiv:2510.06530](https://arxiv.org/pdf/2510.06530).

**Status.** UNVERIFIED (search summary; not opened).

**Summary.** Reportedly, giving an LLM several past RRC/NAS messages degraded detection, while a single message worked.

**Correlation with our project.** How the Generator's context is built.

**What it tells us.** It hints that dumping long message histories hurts. Verify it before relying on it.

### Theme D — Classical non-LLM RAN RCA baselines (the Condition 0 lineage)

#### D1. Khanafer et al. 2008 — naive-Bayes diagnosis over discretised KPIs
**Citation.** R. M. Khanafer, B. Solana, J. Triola, R. Barco, L. Moltsen, Z. Altman, P. Lázaro, "Automated Diagnosis for UMTS Networks Using Bayesian Network Approach," IEEE Trans. Veh. Technol. 57(4):2451–2461, 2008. DOI 10.1109/TVT.2007.912610. https://doi.org/10.1109/TVT.2007.912610

**Status.** VERIFIED (abstract; no numbers).

**Summary.** A naive Bayes classifier over KPI "symptoms", with entropy-minimisation discretisation of thresholds. It was built on a UMTS simulator and then adapted to real OMC counters, and it is described as efficient on both.

**Correlation with our project.** Condition 0 and the failure-classifier deliverable.

**What it tells us.** It is the canonical auditable symptom→cause classifier, and it follows the same simulator-first-then-real path the team plans.

#### D2. Szilágyi & Nováczki 2012 — profile deviation × learned fault signatures (Nokia)
**Citation.** P. Szilágyi, S. Nováczki, "An Automatic Detection and Diagnosis Framework for Mobile Communication Systems," IEEE TNSM 9(2):184–197, 2012. DOI 10.1109/TNSM.2012.031912.110155. https://doi.org/10.1109/tnsm.2012.031912.110155

**Status.** VERIFIED (abstract; no numbers). The mechanism is described via the Mulvey survey.

**Summary.** Detection compares measurements against automatically built "profiles" of normal behaviour, "without the need for thresholding or manual calibration". Diagnosis learns each fault's characteristic impact on the KPIs. Each candidate cause is scored as standardised KPI deviation × the historical likelihood that the cause produces that symptom. In LTE simulation it found the correct root cause and ranked severity.

**Correlation with our project.** It is a published, operator-grade version of the planned KPI z-score Condition 0, **plus a diagnosis layer**.

**What it tells us.** Cite it so that Condition 0 is a recognised baseline, not a strawman. VERDICT must beat it on the same corpus, or build on it.

#### D3. Gómez-Andrades et al. 2016 — SOM plus Ward clustering, labelled by experts
**Citation.** A. Gómez-Andrades, P. Muñoz, I. Serrano, R. Barco, "Automatic Root Cause Analysis for LTE Networks Based on Unsupervised Techniques," IEEE TVT 65(4):2369–2386, 2016. DOI 10.1109/TVT.2015.2431742. [UMA portal](https://portaldelainvestigacion.uma.es/documentos/62ee8e55fc166b010cb70b47?lang=en)

**Status.** VERIFIED (abstract). The KPIs, classes and accuracy are not verified.

**Summary.** Iterated self-organising maps and Ward clustering, with clusters labelled by experts and refined using the silhouette index. It was validated on real and simulated LTE data. The motivation is that no labelled fault history exists.

**Correlation with our project.** A label-scarce route if Cyshield data arrives without labels.

**What it tells us.** HYDRA (D7) notes that SOM methods need expert input and are not robust to distribution shift.

#### D4. Chernov et al. 2015 — sleeping cells are found by event sequences, not radio KPIs
**Citation.** S. Chernov, M. Cochez, T. Ristaniemi, "Anomaly Detection Algorithms for the Sleeping Cell Detection in LTE Networks," IEEE VTC-Spring 2015. DOI 10.1109/VTCSpring.2015.7145707. [Open PDF](https://jyx.jyu.fi/bitstreams/072e0d7d-4179-4b29-bc44-3852be2feaf7/download)

**Status.** VERIFIED (full text).

**Summary.** A RACH-failure "sleeping cell" raises no alarm. It was detected from 1-gram counts of MDT events (A2/A3, HO command/complete, PHY problem, RLF) in sliding windows, with a threshold at the 95th percentile of normal-data scores. PAD performed best but is costly; kNN was "fairly strong" and stable; SOM+kNN was weakest.

**Correlation with our project.** Our "silent" faults (wrong F1 address, PLMN mismatch) and the Condition 0 feature set.

**What it tells us.** Condition 0 needs protocol and event-count features from logs and pcaps, not just KPIs.

#### D5. Mulvey, Foh, Imran, Tafazolli 2019 — survey of ML for cell fault management
**Citation.** "Cell Fault Management Using Machine Learning Techniques," IEEE Access 7:124514–124539, 2019. DOI 10.1109/ACCESS.2019.2938410. [Open PDF](https://eprints.gla.ac.uk/199033/1/199033.pdf)

**Status.** VERIFIED (full text in the classical notes; bibliographic snippet in the standards notes; merged).

**Summary.**
- Classical alarm correlation is rule-based.
- Bayesian approaches have been popular "from the earliest studies onwards".
- The RCA state of the art is "automatic rule extraction … typically using a modified version of the FP-growth algorithm", put into an expert-reviewed causality graph.
- Deep learning "do[es] not attempt to build a causal model".
- RCA is "much more domain dependent … a harder problem" with "significantly less work" than detection.
- There is "no consensus" on evaluation criteria.

**Correlation with our project.** Track B event correlation, the provenance argument, and Condition 0 Tier 1.

**What it tells us.** VERDICT's typed predicates are a modern form of the expert-verified causality rule, and FP-growth rules are a cheap deterministic correlation baseline.

#### D6. Zhang, Zhu, Hossain — five obstacles to ML self-healing
**Citation.** T. Zhang, K. Zhu, E. Hossain, "Data-Driven Machine Learning Techniques for Self-healing in Cellular Wireless Networks: Challenges and Solutions," arXiv:1906.06357; Intelligent Computing 2022, DOI 10.34133/2022/9758169. https://arxiv.org/abs/1906.06357

**Status.** VERIFIED (abstract).

**Summary.** Five obstacles: data imbalance, data insufficiency, cost insensitivity, non-real-time response, and multisource data fusion. Includes a cost-sensitive case study.

**Correlation with our project.** The motivation for the Broker's multisource snapshot.

**What it tells us.** Multisource fusion is a recognised open problem and a legitimate motivation for an LLM reasoner.

#### D7. HYDRA 2022 — multi-fault diagnosis; classical models collapse when data is sparse
**Citation.** M. S. Riaz, H. N. Qureshi, U. Masood, A. Rizwan, A. Abu-Dayya, A. Imran, "A Hybrid Deep Learning-Based (HYDRA) Framework for Multifault Diagnosis Using Sparse MDT Reports," IEEE Access 10:67140–67151, 2022. DOI 10.1109/ACCESS.2022.3185639. [NSF PAR PDF](https://par.nsf.gov/servlets/purl/10406952)

**Status.** VERIFIED (full text).

**Summary.**
- **Setup:** 72 cells using real Belgian BS locations in a ray-tracer; 19,933 MDT snapshots, each with 4 simultaneously faulty cells.
- **Faults:** outage, low TX power, uptilt, downtilt.
- **Method:** SINR maps, inpainting, a CNN, then XGBoost, reaching **93% accuracy**.
- **Classical baselines:** RF/SVM exact-match ratio is 92% / 90.2% on dense maps, falling to 71.3% / 69% at 100 reports per cell. SVM falls to 13.5% at 20 reports per cell, against HYDRA's 45% (67% after enrichment).
- **Confusion:** outage and low TX power are mutually confused.

**Correlation with our project.** Compound faults, confusable pairs, and the corpus design.

**What it tells us.** Build confusable pairs into the corpus on purpose (DU CPU starvation vs channel noise), so that KPI-only Condition 0 fails where predicate evidence disambiguates.

#### D8. Simba — GNN plus Transformer RCA for 5G RAN on Simu5G
**Citation.** Antor Hasan, Conrado Boeira, Khaleda Papry, Yue Ju, Zhongwen Zhu, Israat Haque (Dalhousie Univ. + Ericsson GAIA Montreal per the full-text read), "Root Cause Analysis of Anomalies in 5G RAN Using Graph Neural Network and Transformer," arXiv:2406.15638, 21 Jun 2024. https://arxiv.org/abs/2406.15638 — dataset: https://github.com/PINetDalhousie/NetRepAIr

**Status.** VERIFIED (full HTML in the classical notes; abstract or snippet in two others; merged). One notes file said the Ericsson affiliation was unchecked; the full-text reading confirms it.

**Summary.**
- **Motivation:** "providers do not share such data with ground truth".
- **Data:** a calibrated Simu5G 7-site eMBB-Urban layout at 30 and 90 UEs per BS, about 3 million KPI points with about 2% anomalies, released publicly.
- **Features and faults:** RSRP, RSRQ, SINR, throughput and distance per BS at 1 s; two faults, Excessive Power Reduction and Interference.
- **F1 (normal / peak load):** Simba **0.97 / 0.90**, MTGNN 0.91 / 0.88, GNN_RCA 0.82 / 0.78.
- **Per fault:** EPR 0.99; Interference 0.95, falling to 0.84 at peak load. The authors claim about 0.8 F1 with simultaneous failures.

**Correlation with our project.** The channel-noise fault, and a learned classical baseline.

**What it tells us.** It is strong but easy-mode (2 classes), radio-layer only, and needs training data. Cite it as a stronger baseline that is out of scope, or add a light supervised KPI classifier as a second baseline.

#### D9. Azkaei et al. 2025 — Random Forest xApp on O-RAN KPM features
**Citation.** B. Azkaei, K. C. Joshi, G. Exarchakos, "Machine Learning-Driven Anomaly Detection for 5G O-RAN Performance Metrics," arXiv:2509.03290, 3 Sep 2025. https://arxiv.org/abs/2509.03290

**Status.** VERIFIED (full HTML).

**Summary.**
- **Data:** the O-RAN SC `ric-app-ad` `ue.csv` set, 10,000 KPI reports from 20 UEs, with 19 serving and neighbour features. The label is throughput below target.
- **Random Forest:** P 0.86, R 0.86, **macro-F1 0.90**, accuracy 93%, latency **0.224 ms**.
- **Other models:** Isolation Forest F1 0.79; AutoEncoder 0.84.
- **Explanation:** SHAP and permutation importance point to PRB utilisation and RS-SINR.
- **RCA:** described only as a Non-RT RIC capability; no RCA is evaluated.

**Correlation with our project.** Condition 0 Tier 3, and a public O-RAN dataset.

**What it tells us.** RF plus SHAP is the natural cheap deterministic classifier. VERDICT has to add something beyond "PRB utilisation mattered": a causal, verified cause.

#### D10. Zhang et al. (Huawei) — influence-based root-alarm discovery on real carrier alarms
**Citation.** K. Zhang, M. Kalander, M. Zhou, X. Zhang, J. Ye, "An Influence-based Approach for Root Cause Alarm Discovery in Telecom Networks," AIOPS 2020 (ICSOC); arXiv:2105.03092. https://arxiv.org/abs/2105.03092 — code/data: https://github.com/shaido987/alarm-rca

**Status.** VERIFIED (full text).

**Summary.**
- **Method:** HPCI builds an alarm causal DAG (a Hawkes process, then CI-test pruning); CPBE embeddings weight the edges; IRIE influence maximisation ranks root alarms.
- **Data:** 672,639 alarms, 3,818 devices and 78 alarm types from one Chinese carrier (Aug–Oct 2018). Ground truth is 44 causal edges plus 6,000 labelled transactions.
- **Causal-graph F1:** **0.612**, against 0.194–0.545 for baselines.
- **Root-alarm accuracy:** **top-1 61.8%, top-3 85.1%, top-5 96.1%**, against top-1 40.7% for a Pearson baseline.
- **Pre-processing:** alarms are filtered (missing fields, periodic types) and grouped by connected sub-graph.

**Correlation with our project.** Track B alarm analysis, Broker alarm grouping, top-K reporting, and Architecture C reselection.

**What it tells us.**
- Even the best classical method gets the top-1 root alarm right only about 62% of the time on real data, but the correct cause is usually in the top 3–5.
- That makes a deterministic top-K list a natural candidate pool for the Generator, and for Architecture C to reselect from.

#### D11. THP — topological Hawkes processes for alarm causality
**Citation.** R. Cai, S. Wu, J. Qiao, Z. Hao, K. Zhang, X. Zhang, "THP: Topological Hawkes Processes for Learning Causal Structure on Event Sequences," IEEE TNNLS 2022; arXiv:2105.10884. https://arxiv.org/abs/2105.10884

**Status.** VERIFIED (full text). Which column holds the best F1 was inferred by the notes' author.

**Summary.** Alarms are modelled as excited by events on topologically neighbouring elements. On real data (18 alarm types, 3,087 elements, about one week), F1 ranges from 0.29 to 0.51, and recall is "not well enough" for every method.

**Correlation with our project.** Broker topology, meaning the DU↔CU↔AMF adjacency.

**What it tells us.** Data-driven causal discovery is not a plug-in baseline (F1 about 0.5). That leaves room for hypothesis-driven verification. gCastle (E14) implements these methods.

#### D12. Shi et al. 2025 — causal intervention sequences for RAN fault tracking
**Citation.** C. Shi, J. Philip, S. Bandyopadhyay, J. Choudhury, "Causal Intervention Sequence Analysis for Fault Tracking in Radio Access Networks," IEEE FMLDS 2025, pp. 115–120; arXiv:2511.17505. https://arxiv.org/abs/2511.17505

**Status.** VERIFIED (abstract). The use of PCMCI is from a snippet; no numbers are visible.

**Summary.** Learns the causal chain from normal records to SLA breaches and outputs root-cause indicators *in temporal order*. Monte Carlo tests claim "high precision" at millions of points.

**Correlation with our project.** A form of ordered KPI-deviation evidence the Broker could precompute.

**What it tells us.** This is weak evidence (a short workshop-type paper with no numbers). Temporal-order predicates are nevertheless a natural Falsifier type.

#### D13. XAInomaly — explainable O-RAN anomaly detection
**Citation.** Basaran & Dressler, arXiv:2502.09194. https://arxiv.org/abs/2502.09194

**Status.** VERIFIED (abstract; no numbers).

**Summary.** Explainable O-RAN anomaly detection designed for accuracy, low complexity, scalability and interpretability under multi-vendor heterogeneity.

**Correlation with our project.** Related work for explainability.

**What it tells us.** Explainable-AI work in RAN addresses detection, not root-cause diagnosis.

#### D14. Farmani & Khalil Zadeh — overview of AI self-healing in cellular networks
**Citation.** "AI-based Self-healing Solutions Applied to Cellular Networks: An Overview," arXiv:2311.02390, Nov 2023 (preprint). https://arxiv.org/abs/2311.02390

**Status.** VERIFIED (abstract; marked lower-confidence in the notes).

**Summary.** An overview of AI self-healing methods for cellular networks.

**Correlation with our project.** Related work.

**What it tells us.** Background only.

### Theme E — Testbeds, fault injection, datasets and OCUDU facts

#### E1. OCUDU platform documentation and governance — what the platform actually emits
**Citation.** OCUDU docs: [Migrating from srsRAN](https://docs.ocudu.org/migration/), [Outputs](https://docs.ocudu.org/user_manual/outputs/), [Logging Guide](https://docs.ocudu.org/dev_guide/logging_guide/), [Supported E2 Metrics](https://docs.ocudu.org/knowledge_base/e2sm_kpm_metrics/), [gNB Interfaces](https://docs.ocudu.org/knowledge_base/gnb_interfaces/), [ocudu.org](https://ocudu.org). Governance: [6GWorld, 3 Mar 2026](https://6gworld.com/linux-foundation-launches-ocudu-to-turn-ai-ran-into-an-open-software-foundation/), [Linux Foundation press release, 27 May 2026](https://www.linuxfoundation.org/press/ocudu-ecosystem-foundation-emerges-as-key-hub-for-open-source-ran-innovation-with-21-new-global-member-organizations-since-launch).

**Status.** VERIFIED (official pages; two notes files, merged). Several points are UNVERIFIED: O1 support in the code (the interfaces page reads like a generic O-RAN description), the founding/premier member list, the v1.0 and 26.04 releases, the Configuration Reference key names, and any Prometheus support.

**Summary.**
- **Lineage:** OCUDU is the srsRAN Project's successor, forked at **commit 7d6183f**, relicensed **AGPLv3 → BSD-3-Clause**, and moved to GitLab under Linux Foundation governance. "The underlying architecture is unchanged", but variables, types and functions were renamed.
- **Funding:** National Spectrum Consortium and US DoD FutureG funding, with software built by DeepSig and SRS.
- **Logs:** per layer (MAC, RLC, PDCP, RRC, SDAP, NGAP, GTPU, F1U, DU, CU, PHY and others), levels E/W/I/D, in the format timestamp [Layer] [Level] [TTI] message. A strict logging style guide fixes the field order, uses ASN.1 names without spaces, and states that "Messages with incorrectly formatted context are not allowed".
- **PCAPs:** MAC, RLC, NGAP, N3, E1AP, F1AP and E2AP, with DLTs 149/157, 152, 156, 153, 154 and 155.
- **JSON metrics:** over a websocket (`metrics_subscribe`, example port 8001), with per-layer toggles for executor, app usage, NGAP, RRC, E1AP, PDCP, scheduler, RLC, MAC, DU-low and RU.
- **E2SM-KPM:** 27 metrics, 24 of the 278 in TS 28.552 and 3 of 9 from O-RAN WG3. They include `RRC.ConnEstabAtt/Succ/FailCause`, `UECNTX.ConnEstabAtt/Succ` and `RRC.ReEstabAtt`.
- **Not documented:** Prometheus export, file metrics, tracing and VES alarms. There is no PCAP for F1-U, PDCP or SDAP, and the scheduler latency histogram only covers 0–500 µs.

**Correlation with our project.** The Broker's collectors, the perturbation tooling (the strict log grammar makes ID renaming tractable), and the feasibility verdict.

**What it tells us.**
- Logs, pcaps and metrics are available out of the box.
- Prometheus export and alarms are project work.
- Pin versions, because names have already changed in the rename.

#### E2. srsRAN Project "Outputs" documentation — the lineage reference
**Citation.** [srsRAN Project docs, Outputs](https://docs.srsran.com/projects/project/en/latest/user_manuals/source/outputs.html).

**Status.** VERIFIED. That it applies to OCUDU is inferred from the lineage.

**Summary.** The same log format, PCAP DLTs, websocket JSON metrics and Grafana GUI as OCUDU. InfluxDB and Prometheus are not mentioned.

**Correlation with our project.** Confirms the Broker's telemetry inventory.

**What it tells us.** The telemetry gaps are inherited, not new.

#### E3. srsUE channel emulator — how channel noise can be injected over ZMQ
**Citation.** [srsLTE docs: Advanced Usage](https://srslte-docs.readthedocs.io/en/next/usermanuals/source/srsue/source/4_ue_advanced.html); osmocom commits for the [SNR-based emulator](https://gitea.osmocom.org/fixeria/srsRAN/commit/0e96ef3df0635805f4806b91a126effe48bbcd5b) and the [RLF simulator](https://gitea.osmocom.org/fixeria/srsRAN/commit/2ffa1f9f1efb9823bdfba62381f1cf9c69537d5f).

**Status.** VERIFIED for the 4G/srsLTE line. The AWGN config key names and NR availability under OCUDU are UNVERIFIED.

**Summary.** The emulator supports fading models (epa5, eva70, etu300), sinusoidal delay and RLF on/off cycles via `channel.dl.*` and `channel.ul.*` keys. An SNR-based AWGN option exists in the code history.

**Correlation with our project.** The channel-noise injection.

**What it tells us.** Channel noise is only emulated. Label it as an "emulated-PHY" stratum and report it separately.

#### E4. Baguer i Fàbrega (UPC/NEC) master's thesis — the most mature ground-truth recipe
**Citation.** P. Baguer i Fàbrega (supervisor X. Costa-Pérez, NEC Labs Europe), "Leveraging Large Language Models for Mobile Systems Operations," Master's thesis, UPC/UB/URV, ~123 pp., 2025 or 2026 (year not printed). [PDF](https://upcommons.upc.edu/bitstreams/99fb80d8-978c-477e-a66e-42adefbedfd5/download)

**Status.** VERIFIED (full text). No public dataset link was found.

**Summary.**
- **Testbed:** O-RAN SC RICs, srsRAN Project O-CU/O-DU, Open5GS, a USRP B210 and two Quectel COTS UEs over the air. KPM is collected at 1 s.
- **Motivation:** "In the absence of publicly available datasets for this task, we developed a realistic O-RAN testbed".
- **Faults:** loss and delay on A1, E2, F1-c and F1-u at Low, Medium, High and Link-Down strengths.
- **Ground truth:** an "Action YAML" for benign background events, an "Anomaly YAML" for faults, a fresh Docker Compose redeploy per run, and a metadata file with absolute timestamps. Data comes from InfluxDB and PCAPs.
- **Method:** an LLM "Perception Agent" over PC-algorithm causal graphs with GNN soft-prompting.
- **Accuracy@1:** **0.64 for loss and 0.73 for delay**, with all anomalies above 75% at AC@3. F1-c delay reaches only **0.20**, because "highly sparse metrics in F1-c".

**Correlation with our project.** The corpus harness, the Broker's incident windows, Track A replay, and the case against KPI-only RCA.

**What it tells us.**
- Copy the Action/Anomaly YAML, redeploy and metadata recipe.
- F1-c faults need F1AP pcaps and logs, not metrics.

#### E5. Baguer et al. 2024 — attacking O-RAN interfaces
**Citation.** P. Baguer, G. M. Yilma, E. Municio, G. Garcia-Aviles, A. Garcia-Saavedra, M. Liebsch, X. Costa-Pérez, "Attacking O-RAN Interfaces: Threat Modeling, Analysis and Practical Experimentation," IEEE OJ-COMS 5:4559–4577, 2024. DOI 10.1109/OJCOMS.2024.3431681. [Zenodo](https://zenodo.org/records/12771582)

**Status.** PARTIAL (metadata and abstract summary only).

**Summary.** DoS and performance-degradation attacks on A1, E2, F1-c and F1-u of an open-source O-RAN deployment, mapped to the WG11 threat model. Per E4, 60% of WG11 risks are DoS or degradation.

**Correlation with our project.** Justifies choosing transport loss and delay as cheap fault families.

**What it tells us.** Loss and delay on F1/E2 are realistic, standards-anchored fault primitives.

#### E6. FALCON++ (IIT Hyderabad) — anomalies on split CU/DU srsRAN in Docker
**Citation.** Y. Kumar L S, S. Jain, M. S. K. Victor, A. Ovais, S. K. Amalapuram, B. R. Tamma, C. S. R. Murthy, "FALCON++: A Semi-Supervised Anomaly Detection and Localization Framework for Resilient O-RAN Deployments." [PDF](https://newslab.iith.ac.in/media/publications/pdfs/FALCON___Open_AI_RAN_workshop_2025.pdf)

**Status.** VERIFIED (full text). The venue ("Open AI RAN workshop 2025", from the filename) is UNVERIFIED.

**Summary.**
- **Testbed:** srsRAN in Docker with 2 O-CUs, 3 O-DUs and one UE per DU.
- **Telemetry:** 403 features from node-exporter, cAdvisor and the srsRAN metrics server at 1 s.
- **Faults:** CPU and memory stress via stress-ng, and packet loss via tc netem. Injection is "randomized yet controlled", with cleanup and cool-down.
- **Results:** FALCON++ P/R/F1 0.66 / 0.92 / 0.77, against BGMM 0.71 F1. Recall is CPU 0.90, memory 0.87 and loss 1.00.
- **Confounding:** under loss, retransmissions inflate DU buffer and radio metrics (a "false impression of high traffic demand").
- **Data scarcity:** "the availability of labeled fault data is extremely limited".

**Correlation with our project.** The DU CPU starvation fault, the cheap memory and loss families, and cross-layer confounding.

**What it tells us.** CPU, memory and loss faults are all injectable on split srsRAN containers. Their KPI signatures mislead, which supports a multimodal Broker.

#### E7. Bonev (TU Delft) — a cross-layer fault atlas for a cloud-native 5G core
**Citation.** B. Bonev, "A Cross-Layer Fault Atlas for Cloud-Native 5G Core Networks," BSc thesis, TU Delft, 19 Jun 2026. [Repository](https://repository.tudelft.nl/record/uuid:c5f4b0eb-2e6b-4636-8498-e26411274e5a)

**Status.** VERIFIED (abstract page). The data URL was not located.

**Summary.**
- **Setup:** Open5GS on Kubernetes with **22 chaos faults in 8 classes**, mapped to **40 observability signals**.
- **Orchestration layer:** it detected only **10 of 22** faults and missed all CPU-stress, delay and PFCP-attack faults.
- **Modalities:** 21 of 22 faults were visible in more than one modality.
- **Stability:** at least 95.9% of signals were stable across thresholds and methods, and a second run agreed on 93.1% of cells.
- **Release:** published as "reusable ground truth".

**Correlation with our project.** Broker modality coverage, and evidence of feasibility at single-student scale.

**What it tells us.** Container- or orchestrator-level alarms alone would miss CPU and delay faults. The Broker must snapshot NF logs, pcaps and RAN metrics.

#### E8. OM_module (PUCP) — config and subscriber faults on Open5GS + srsRAN over ZMQ
**Citation.** R. Barrios, "OM_module: An O&M module for 4G/5G core testbeds," GitHub, MIT, 2026. https://github.com/Parz1val02/OM_module

**Status.** VERIFIED (repository page; a code artifact, not peer-reviewed).

**Summary.**
- **Stack:** docker_open5gs, srsRAN and UERANSIM over ZMQ.
- **5G faults:** SUPI missing, wrong K (authentication failure), wrong DNN and non-existent SST/SD, plus fault-free baselines.
- **Telemetry:** tshark → OTLP spans in Tempo (NGAP, PFCP, SBI and others), Loki, Prometheus via a json-exporter, and Grafana.

**Correlation with our project.** Our wrong-subscriber-key and config faults, healthy baseline runs, and the Prometheus exporter pattern.

**What it tells us.** Config and auth faults reproduce faithfully over ZMQ, with distinct NAS reject causes. Healthy baselines are cheap to include.

#### E9. RANsacked — fuzzing finds crash bugs in open-source cores
**Citation.** N. Bennett, W. Zhu, B. Simon, R. Kennedy, W. Enck, P. Traynor, K. R. B. Butler, "RANsacked: A Domain-Informed Approach for Fuzzing LTE and 5G RAN-Core Interfaces," ACM CCS '24. DOI 10.1145/3658644.3670320. [PDF](https://cise.ufl.edu/~butler/pubs/ccs24-bennett-ransacked.pdf)

**Status.** VERIFIED (full text). The CVE count is inconsistent: the abstract says 93 CVEs, the introduction says 96, and [secondary press](https://thehackernews.com/2025/01/ransacked-over-100-security-flaws-found.html) says 97. Some table headers were garbled in extraction.

**Summary.**
- **Targets:** grey-box fuzzing of NGAP/S1AP/NAS/GTP in Magma, NextEPC, Open5GS 2.6.1, OAI, SD-Core and srsEPC.
- **Findings:** **119 vulnerabilities**, deduplicated from about 37,000 crashes. Reachable assertions are the largest class, and NAS bugs are reachable before authentication.
- **Crash detection:** a liveness "canary" SCTP connection.

**Correlation with our project.** An optional "software bug" fault class (an AMF crash after a specific message).

**What it tells us.** Replaying a known crash input against a pinned Open5GS version is a realistic bug fault. Most known bugs are core-side; there is no RAN-side equivalent.

#### E10. 5Greplay — replaying modified 5G traffic
**Citation.** Z. Salazar, H. N. Nguyen, W. Mallouli, A. R. Cavalli, E. Montes de Oca, "5Greplay: a 5G Network Traffic Fuzzer — Application to Attack Injection," ARES 2021. DOI 10.1145/3465481.3470079; arXiv:2304.05719. https://arxiv.org/abs/2304.05719

**Status.** VERIFIED (abstract). The free5GC/Open5GS/UERANSIM details are UNVERIFIED.

**Summary.** An open tool that replays and modifies control- and user-plane traffic toward the AMF, SMF and gNB at 9.56 Gbps on one core.

**Correlation with our project.** Protocol-level fault injection without radio hardware.

**What it tells us.** It is an injector for malformed-message faults.

#### E11. Moreira et al. — DDoS chaos on a large 5G core
**Citation.** R. Moreira, L. F. Rodrigues Moreira, F. de Oliveira Silva, "Performance Evaluation and Threat Mitigation in Large-scale 5G Core Deployment," arXiv:2507.17850. https://arxiv.org/abs/2507.17850

**Status.** VERIFIED (abstract; no numbers).

**Summary.** Studies how DDoS on network functions affects UE registration, concluding that diverse resource profiles are needed.

**Correlation with our project.** Background for core-side faults.

**What it tells us.** Low relevance.

#### E12. SAJD — self-adaptive jamming detection in O-RAN
**Citation.** M. H. Rahman, M. S. Hossen, N. H. Stephenson, V. K. Shah, A. Da Silva, arXiv:2511.17519 (listed for IEEE MILCOM). https://arxiv.org/abs/2511.17519

**Status.** VERIFIED (abstract). The srsRAN/Kafka/InfluxDB stack details are UNVERIFIED.

**Summary.** An xApp performs inference while an rApp detects drift, auto-labels data and retrains.

**Correlation with our project.** The channel-noise and jamming analogue.

**What it tells us.** Low relevance.

#### E13. TelecomTS — a multimodal 5G observability dataset (ICML 2026)
**Citation.** Austin Feng, Andreas Varvarigos, Ioannis Panitsas, Daniela Fernandez, Jinbiao Wei, Yuwei Guo, Jialin Chen, Ali Maatouk, Leandros Tassiulas, Rex Ying, "TelecomTS: A Multi-Modal Observability Dataset for Time Series and Language Analysis," arXiv:2510.06063; ICML 2026 (PMLR 306). https://arxiv.org/abs/2510.06063

**Status.** VERIFIED (abstract and PMLR). The jammer, the 10 synthetic fault types and the "flags normal samples" finding are secondary ([HF README](https://huggingface.co/datasets/SamalaSharan/TelecomTS/blob/main/README.md)).

**Summary.** A de-anonymised 5G dataset that keeps absolute scale, with anomaly detection, RCA and multimodal Q&A tasks. Time-series models, LLMs and multimodal foundation models all "struggle with the abrupt, noisy, and high-variance dynamics". It is also one of the datasets used by 2609.02805.

**Correlation with our project.** The KPI modality, the null-evidence condition, and the channel-noise fault.

**What it tells us.**
- KPIs are the least reliable modality for LLMs.
- Keep absolute units in the Broker summary.
- Expect false positives under null evidence.

#### E14. gCastle and PCIC 2021 — telecom alarm causal-discovery datasets
**Citation.** gCastle toolbox, [arXiv:2111.15155](https://arxiv.org/abs/2111.15155); [PCIC 2021 Track 1](https://pattern.swarma.org/pcic/competition.html).

**Status.** VERIFIED (gCastle abstract); PCIC is a SNIPPET.

**Summary.** gCastle provides "three real-world datasets in telecommunications". PCIC 2021 targeted causal discovery from alarm sequences. Whether the two share data or carry root-cause labels is unknown.

**Correlation with our project.** An optional causal-discovery baseline.

**What it tells us.** gCastle implements THP- and PC-style methods if a causal baseline is wanted.

#### E15. ICASSP 2022 Grand Challenge — RCA for wireless network fault localization
**Citation.** [IEEE SPS page](https://signalprocessingsociety.org/index%2ephp/publications-resources/data-challenges/root-cause-analysis-wireless-network-faults-localization).

**Status.** VERIFIED (page). The organiser, metric and current availability are unknown.

**Summary.** A "real-world telecommunication dataset collected from live 5G networks" with an expert-endorsed causal graph. It emphasises limited labels, hybrid faults and missing data.

**Correlation with our project.** A possible external sanity check.

**What it tells us.** Check access early; do not depend on it.

#### E16. Real cellular alarm benchmark (UNVERIFIED)
**Citation.** [arXiv:2608.21815](https://arxiv.org/pdf/2608.21815).

**Status.** UNVERIFIED (snippet). The notes call it a 2025 paper, which conflicts with its August 2026 arXiv identifier.

**Summary.** Reportedly 18 alarm types, about 35,000 events over 8 months, expert ground truth, and a best F1 of about 0.6.

**Correlation with our project.** The alarm-analysis baseline.

**What it tells us.** If confirmed, it is consistent with real-data causal F1 of about 0.5–0.6.

#### E17. AI Telco Troubleshooting Challenge (GSMA/ITU/Zindi)
**Citation.** [GSMA newsroom](https://www.gsma.com/newsroom/?p=25052); [ITU AI for Good](https://aiforgood.itu.int/?p=45805); [Zindi data page](https://zindi.africa/competitions/the-ai-telco-troubleshooting-challenge/data).

**Status.** SNIPPET (two notes files, merged). Zindi describes the data as real drive-test logs, while the TeleLogs card says synthetic; this is unresolved.

**Summary.** A GSMA-led challenge (Nov 2025 – Mar 2026, with ETSI, IEEE, ITU and TM Forum) calling for LLMs that do RCA, using 8 TeleLogs-style fault classes C1–C8.

**Correlation with our project.** Industry-momentum framing.

**What it tells us.** It shows industry demand. Its data is radio-layer, not CU/DU control plane.

#### E18. ARA testbed — OCUDU in monolithic and split CU/DU modes
**Citation.** [ARA docs](https://arawireless.readthedocs.io/en/latest/ara_experiments/araran_experiments/ORAN_OCUDU_FlexRIC_xApp.html).

**Status.** SNIPPET.

**Summary.** A third-party testbed ran OCUDU monolithic and as an O-CU/O-DU split over F1, with a FlexRIC KPM xApp collecting per-UE throughput.

**Correlation with our project.** Feasibility of the split CU/DU deployment.

**What it tells us.** Others have already run OCUDU split over F1 with a KPM xApp, which lowers integration risk.

#### E19–E22. Unverified testbed leads
All four were seen only in snippets:
- **E19.** "Smart Fuzzing of 5G Wireless Software Implementation", AFL++ fuzzing of OAI config files, [arXiv:2309.12994](https://arxiv.org/pdf/2309.12994).
- **E20.** CSIR, "Deploying a Stable 5G SA Testbed Using srsRAN and Open5GS", with a symptom/cause/fix table, [ResearchGate](https://www.researchgate.net/publication/373640179_Deploying_a_Stable_5G_SA_Testbed_Using_srsRAN_and_Open5GS_UE_Integration_and_Troubleshooting_Towards_Network_Slicing).
- **E21.** Virginia Tech "Video Streaming Network KPIs for O-RAN Testing", srsRAN + B210 with injected interference, [IEEE DataPort](https://ieee-dataport.org/documents/video-streaming-network-kpis-o-ran-testing).
- **E22.** Channel modelling in GNU Radio between srsUE and gNB ZMQ streams, [arXiv:2205.13178](https://arxiv.org/pdf/2205.13178).

### Theme F — Standards and feasibility anchors

#### F1. 3GPP TS 28.104 — Management Data Analytics, where RCA lives in 3GPP
**Citation.** 3GPP TS 28.104, "Management and orchestration; Management Data Analytics (MDA)", latest Rel-20 v20.1.0 (2026-09-25). [3GPP portal](https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=3877); [cl. 4.1](https://itecspec.com/3gpp/28.104/s/4.1); [cl. 7.2.3.2.3](https://www.itecspec.com/3gpp/28.104/s/7.2.3.2.3)

**Status.** VERIFIED (portal and mirrored clauses). The normative fault-analysis MDA type names were not read.

**Summary.**
- **Inputs:** MDA consumes PM, KPIs, Trace/MDT/RLF/RRC reports, QoE reports and alarms.
- **Outputs:** statistics, predictions, root-cause analysis and optional recommendations, delivered to management functions, NWDAF, SON and operators.
- **Fault management (cl. 7.2.3):** covers failure prediction and service failure recovery. REQ-FAILURE_RECOV_MDA-01 requires the ability to "collect, filter and analyse alarm information".

**Correlation with our project.** The output schema, and the positioning statement.

**What it tells us.** Position VERDICT as a prototype MDA producer for "MDA-assisted fault management". "Unresolved" is a defensible extension because MDA output is advisory.

#### F2. 3GPP TR 28.866 — 3GPP itself names the missing root-cause and demarcation output
**Citation.** 3GPP TR 28.866, "Study on MDA Phase 3" (Rel-19). [cl. 5.6.3.1](https://www.itecspec.com/3gpp/28.866/s/5.6.3.1); [cl. 5.6.3.3](https://www.itecspec.com/3gpp/28.866/s/5.6.3.3)

**Status.** VERIFIED (cl. 5.6.3.1); cl. 5.6.3.3 is a SNIPPET.

**Summary.** The existing FailurePrediction output is "Missing important information includes the root cause of the service problem and demarcation information". The study recommends an "MDAAssistedFaultManagement.FailureRecovery" type with correlated alarms and recommended actions.

**Correlation with our project.** The problem statement and the output fields.

**What it tells us.** It gives a 3GPP-backed problem statement: VERDICT adds the root cause and demarcation that 3GPP says are missing.

#### F3. SA5 contribution drafts — alarm incident analysis (SNIPPET)
**Citation.** [S5-213389rev2](https://3gpp.org/ftp/tsg_sa/WG5_TM/TSGS5_137e/Inbox/Drafts/S5-213389rev2%20pCR%2028.104%20add%20alarm%20incident%20analysis.doc); [S5-222376rev4](https://www.3gpp.org/FTP/TSG_SA/WG5_TM/TSGS5_142e/Inbox/Drafts/S5-222376rev4%20pCR%2028.104%20Add%20alarm%20analysis%20use%20case.docx).

**Status.** SNIPPET. Whether they were adopted is UNVERIFIED.

**Summary.** Huawei and China Mobile proposals (2021–22) for "alarm related fault demarcation and root cause analysis", with output including a "root alarm and cause", fault location and affected objects.

**Correlation with our project.** The output vocabulary.

**What it tells us.** Use the vocabulary; do not cite the drafts as adopted text.

#### F4. 3GPP TS 28.552 — 5G performance measurements
**Citation.** 3GPP TS 28.552, latest Rel-20 v20.4.0 (2026-09-25). [Portal](https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=3413)

**Status.** VERIFIED (portal).

**Summary.** Standard PM counter names. OCUDU covers 24 of the 278.

**Correlation with our project.** Broker KPI names and Prometheus labels.

**What it tells us.** Name metrics exactly as in TS 28.552 (e.g. `RRC.ConnEstabFailCause`). It costs nothing and supports a standards-alignment claim.

#### F5. 3GPP TS 38.401 — the normative CU/DU procedure flows behind predicates and taxonomy
**Citation.** ETSI TS 138 401 V19.3.0 (2026-07) = 3GPP TS 38.401 v19.3.0, "NG-RAN; Architecture description". [ETSI PDF](https://www.etsi.org/deliver/etsi_ts/138400_138499/138401/19.03.00_60/ts_138401v190300p.pdf)

**Status.** VERIFIED (full text). TS 23.502/24.501 (NAS) and the F1AP/NGAP cause values (38.473/38.413) were not fetched.

**Summary.**
- **Cl. 8.5, F1 startup:** F1 SETUP REQUEST → optional NG Setup → F1 SETUP RESPONSE → CU CONFIGURATION UPDATE, whose ACK can list "cells that failed to be activated".
- **Cl. 8.1, UE Initial Access:** an 18-step flow from RRCSetupRequest through INITIAL UL RRC MESSAGE TRANSFER, NGAP INITIAL UE MESSAGE, INITIAL CONTEXT SETUP, F1 UE CONTEXT SETUP and SecurityModeCommand, to INITIAL CONTEXT SETUP RESPONSE.
- **Cl. 8.9:** adds E1 BEARER CONTEXT SETUP and MODIFICATION.
- **RAN UE ID:** allocated by the DU and carried over E1 and F1 (cl. 6.2.5).

**Correlation with our project.** The golden-flow predicate library, the failure taxonomy, and Broker correlation keys.

**What it tells us.**
- Each predicate becomes "expected message M at step k of procedure P on interface I is absent, failed, or carries cause C".
- Anchor the taxonomy on (procedure × interface × NE × layer × cause), with about 12–18 classes.

#### F6. ETSI GS ZSM 002 — a named "Root cause analysis service" in closed-loop automation
**Citation.** ETSI GS ZSM 002 V1.1.1 (2019-08), "ZSM; Reference Architecture". [PDF](https://www.etsi.org/deliver/etsi_gs/ZSM/001_099/002/01.01.01_60/gs_zsm002v010101p.pdf)

**Status.** VERIFIED (full text).

**Summary.** The architecture has data collection, analytics and E2E service analytics responsible for "root cause analysis". Table 6.6.3.2.1-2 defines a "Root cause analysis service" that works by "correlating information about multiple faults, identifying dependencies and using additional insights or knowledge". Service-health responses can include "probable root cause".

**Correlation with our project.** Broker = data collection; Generator/Falsifier/Orchestrator = analytics.

**What it tells us.** An architecture-mapping sentence for reviewers. Closed-loop actuation is excluded.

#### F7. Polese et al. — O-RAN architecture tutorial (COMST 2023)
**Citation.** M. Polese, L. Bonati, S. D'Oro, S. Basagni, T. Melodia, "Understanding O-RAN: Architecture, Interfaces, Algorithms, Security, and Research Challenges," IEEE COMST 25(2):1376–1411, 2023. [NSF PAR](https://par.nsf.gov/biblio/10488080); [arXiv:2202.01032](https://arxiv.org/abs/2202.01032)

**Status.** VERIFIED (full text). The DOI was not shown on the fetched pages.

**Summary.**
- O1 carries Fault Supervision (3GPP fault events via REST) and Performance Assurance (streamed or file-based KPIs, with VES).
- rApps provide "data analytics" among other services.
- The AI/ML workflow has six steps.
- Proprietary SMOs are "closed solutions".
- Multi-vendor interoperability tests focus first on fronthaul and E2.

**Correlation with our project.** The rApp/SMO placement, O1 FM/PA vocabulary, and the multi-vendor motivation.

**What it tells us.** Describe the rApp mapping architecturally; do not build SMO integration.

#### F8. O-RAN SC Fault Management wiki and the harmonised VES format
**Citation.** [O-RAN SC wiki, Fault Management](https://lf-o-ran-sc.atlassian.net/wiki/spaces/IAT/pages/14516420/Fault+Management) (Dec 2020); [harmonised VES annex (wiki)](https://wiki.o-ran-sc.org/x/q4AGB).

**Status.** VERIFIED (FM flow page). The harmonised VES annex is a SNIPPET, and the WG10 document number and version are UNVERIFIED.

**Summary.** An O1 device sends a VES "fault" event to the SMO collector, which forwards it via DMaaP to the O1 controller's AlarmLog. 3GPP notifications (notifyNewAlarm, notifyClearedAlarm and others) map to VES 7.2.1 and TS 28.532.

**Correlation with our project.** The shape of Broker-derived alarms, and an optional VES-JSON ingest.

**What it tells us.** Emit alarms in VES/3GPP-FM shape (eventId, sourceName, perceivedSeverity, probableCause, specificProblem, raised/cleared) without building the plumbing.

#### F9. Dell patent US11838169B1 — multi-vendor troubleshooting pain
**Citation.** Sudletsky, Roshan, Liu, Pham, Atawia, "Remote logging management in multi-vendor O-RAN networks," US11838169B1, granted 2023-12-05. [Google Patents](https://patents.google.com/patent/US11838169B1/en)

**Status.** VERIFIED.

**Summary.** States that operators "may need to rely on manual input from the various vendors" and that automating troubleshooting "is difficult and prone to errors in multi-vendor deployments".

**Correlation with our project.** Motivation.

**What it tells us.** It is the clearest primary statement of multi-vendor pain. Peer-reviewed quantitative evidence of that pain is absent.

#### F10. CN121984837A — prior art for "LLM generates, queries verify" (VERIFIED, cloud domain)
**Citation.** Zhu Xuefeng, Cheng Xiaozhong, Xue Lei; applicant Shanghai Anchnet Network Technology Co., Ltd. "一种告警根因分析系统及方法" (An alarm root cause analysis system and method). Chinese patent application CN121984837A, application no. CN202610318429.8A. Filed and priority date 2026-03-16, published 2026-05-05, status pending (not granted). [Google Patents](https://patents.google.com/patent/CN121984837A/en) · [goveda](https://www.goveda.com/patent/CN-121984837-A)

**Status.** VERIFIED. Claims and description were read via the machine-translated Google Patents and goveda pages on 2026-10-08. The original Chinese text is authoritative, and claim 1 was read in substance, not verbatim.

**Summary.** It has 10 claims: 2 independent (system claim 1 and method claim 8) and 8 dependent.
- **Claim 1 (system):** a flow-orchestration platform and a data-docking module.
  1. A cloud alarm arrives, and its type selects a data-docking template.
  2. The module pulls raw O&M data (logs, application monitoring, cloud monitoring; examples are Alibaba Cloud SLS and ARMS) and standardizes it.
  3. The platform builds prompts and asks an LLM for candidate root causes.
  4. The platform generates a verification query for each candidate.
  5. The module runs those queries against the original data and returns evidence.
  6. Candidates whose evidence meets a preset confidence condition are kept, and those "with lack of data support or weak evidence" are rejected.
- **Dependent claims:**
  - Claim 2: prompt enrichment by alarm type.
  - Claims 3–4: drag-and-drop analysis templates classified by resource type and fault level, with adjustable time range, model timeout and confidence threshold.
  - Claim 5: versioned data-source templates.
  - Claim 6: a data-integrity check for time coverage around the alarm and required fields, with retries and then an exception notice.
  - Claim 7: results linked to evidence, a full audit log and a generated report.
  - Claims 9–10: method versions of claims 2–3.
- **Problem it states:** plain LLM RCA "lacks a closed-loop verification mechanism."

**Correlation with our project.** The patent's chain is LLM candidate generation, a per-candidate query against immutable raw data, evidence-thresholded selection, and an evidence-linked audit trail. That covers the skeleton of VERDICT's Generator → Broker query → evidence → provenance, and Architecture A's "commit a check, re-execute it." It does **not** describe:
1. a Generator kept blind to raw telemetry (information separation);
2. an adversarial step that tries to *refute*: its verification is confirmatory, with refutation only as failing a threshold;
3. typed predicates re-executed by an independent Orchestrator, void refutations, or the two-strike rule;
4. an "unresolved" or abstention output when no candidate passes;
5. multiple agents;
6. repair or reselection (Architecture C);
7. any evaluation, so no fratricide, void-refutation or contamination controls;
8. anything about telecom, RAN, 5G or 3GPP. It is cloud O&M, with only a generic "network packet loss" example.

**What it tells us.**
- **Academic novelty:** "LLM proposes root causes, then queries over raw telemetry verify them" is prior art from March 2026, before our August 2026 proposal. Cite it, and do not claim generate-then-verify as new. The defensible contribution remains the combination of items 1–4 and 7 above, plus the first O-RAN CU/DU fault corpus.
- **A design argument it hands us:** the patent's verifier looks for *supporting* evidence, which is exactly the confirmation bias that a blind Generator and an adversarial Falsifier are built to avoid. VERDICT's contrast is confirmatory versus falsificationist verification.
- **Ideas worth borrowing:** the claim-6 data-integrity gate, which maps to our "unverified when logs were not captured"; alarm-type → query templates, for Broker query templates per fault family; and the audit report for the Track B dashboard.
- **Legal position:** a pending Chinese application has no force outside China, and its scope may still narrow. Any commercial use beyond the graduation project should go to patent counsel. This is not legal advice.

#### F11–F13. Snippet-only industry and standards context
- **F11. TM Forum Autonomous Network levels L0–L5** (IG1218/IG1252). Assessment is per scenario, and "RAN fault management" is a listed scenario. [TM Forum fault-management hub](https://www.tmforum.org/member-projects/innovation-hubs/projects/fault-management), SNIPPET (403).
- **F12. VIAVI:** multi-vendor O-RAN makes product-related performance problems harder to pin down. [eeNews Europe](https://www.eenewseurope.com/en/test-suite-for-multi-vendor-based-o-ran-networks), SNIPPET, vendor marketing.
- **F13. O-RAN SC O-DU** (a different project from OCUDU) has a VES PM stream to the SMO. [Release notes](https://o-ran-sc-o-du-l2.readthedocs.io/en/latest/release-notes.html), SNIPPET.

None should carry weight in the argument. No nGRG or ATIS report specifically on LLMs for RAN troubleshooting was found.

## Feasibility verdict: OCUDU RCA is doable in 9 months if the Broker builds what OCUDU lacks

**Verdict: feasible, if scoped.** The evidence points the same way from three directions.

First, the platform emits most of what RCA needs. OCUDU keeps srsRAN's architecture and telemetry: per-layer logs with a strict, parseable grammar, separate PCAPs for F1AP, NGAP, E1AP, E2AP, MAC, RLC and N3, websocket JSON metrics with per-layer toggles, and 27 E2SM-KPM metrics including RRC failure causes ([OCUDU Outputs](https://docs.ocudu.org/user_manual/outputs/); [OCUDU KPM](https://docs.ocudu.org/knowledge_base/e2sm_kpm_metrics/)). A third-party testbed has already run OCUDU split over F1 with a KPM xApp (SNIPPET, [ARA](https://arawireless.readthedocs.io/en/latest/ara_experiments/araran_experiments/ORAN_OCUDU_FlexRIC_xApp.html)).

Second, comparable injection corpora were each built by a single student. Examples are the UPC/NEC thesis with its YAML + redeploy + metadata recipe, the TU Delft 22-fault atlas, and the OM_module config-fault repository ([UPC thesis](https://upcommons.upc.edu/bitstreams/99fb80d8-978c-477e-a66e-42adefbedfd5/download); [TU Delft](https://repository.tudelft.nl/record/uuid:c5f4b0eb-2e6b-4636-8498-e26411274e5a); [OM_module](https://github.com/Parz1val02/OM_module)). Published corpora are also small: 3 fault types in FALCON++, 8 interface × impairment combinations at UPC, 7 in OM_module, and 118 experiments in Hatami et al. A corpus of about 6–10 fault families × 2–4 severities × 10–30 seeded repetitions, a few hundred incidents in total, would already be at or above the state of the art for CU/DU.

Third, no existing work occupies the exact niche, so even a modest working system is a contribution.

The gaps are concrete and must be budgeted, not discovered in month 6:

| Need | What OCUDU provides | Gap and required Broker work |
|---|---|---|
| KPIs in Prometheus (Cyshield observability) | Websocket JSON metrics, Grafana GUI | No documented Prometheus, file or tracing export. Build a websocket→Prometheus exporter with TS 28.552 names |
| Alarms (Track B alarm analysis) | None documented; O1 described only generically (UNVERIFIED in code) | Derive VES/3GPP-FM-shaped alarms from log E/W levels, KPI thresholds and protocol failures |
| Protocol evidence | F1AP/NGAP/E1AP/E2AP/MAC/RLC/N3 PCAPs | No F1-U/PDCP/SDAP PCAP, so user-plane evidence comes from logs only. Decode PCAPs deterministically to JSON |
| F1-c diagnosis | F1AP PCAP, DU/CU logs | F1-c metrics are sparse: UPC reached AC@1 0.20 on F1-c delay using metrics. Rely on PCAP and log predicates |
| Cross-component ordering | Per-component timestamps | No guidance on clock alignment. Use a single host clock or chrony |
| Reproducibility | Recent fork with renamed symbols | Pin OCUDU and Open5GS versions in every snapshot |
| Channel noise | srsUE emulator (4G-line docs; NR availability UNVERIFIED) | Emulated only; report as a separate "emulated-PHY" stratum |
| DU CPU starvation | stress-ng, cgroups | Under ZMQ it may surface as stalls rather than real-time deadline misses. This is an inference to validate in Phase 1 |

The fault-realism picture over ZMQ is favourable for the protocol-level families:
- **Fully realistic:** PLMN/TAC/DNN/S-NSSAI mismatches, wrong F1 address, NF stop, wrong subscriber key, and tc loss or delay on F1/N2. They exercise the same code and messages as with an SDR.
- **Emulated only:** channel noise and CPU starvation.

The wrong-F1-address fault is a "silence" fault: its evidence is the *absence* of F1 SETUP. That makes expected-message predicates mandatory. A realistic plan, consistent with the testbed notes:
- **Months 1–4:** deploy OCUDU, srsUE/ZMQ and Open5GS with pinned versions, and build the collectors.
- **Months 4–5:** a scripted harness (Action and Anomaly YAML, fresh redeploy, timestamped metadata with an "expected first evidence" field).
- **Throughout:** generate perturbation variants offline from the same raw snapshots, so they cost no extra testbed time.

Exclude these from scope:
- real SMO, Non-RT RIC, O1/NETCONF/VES and A1/R1 integration;
- closed-loop remediation;
- Open Fronthaul, RU and RF faults;
- mobility and multi-cell;
- claims of multi-vendor validation (claim "interface-centric, vendor-agnostic evidence" instead);
- TeleLogs-style fine-tuning of telecom LLMs;
- TM Forum level certification.

## R2 lens: telecom failure modes and how to score the reasoning, not the answer

### Cloud failure families transfer; telecom adds four of its own

Every family in R2's cloud-RCA taxonomy has at least one network-domain instance in the new papers, so the taxonomy transfers with little change. Telecom adds failure modes that single-fault cloud benchmarks cannot measure, because they always contain exactly one fault and an accurate symptom:

| Failure mode | Cloud counterpart | Telecom/network evidence | VERDICT measurement |
|---|---|---|---|
| Premature or shallow stopping | Premature stopping | NIKA: "link unstable" despite CRC and queue-drop evidence; GPT-5 localization 58% on resource contention ([NIKA](https://arxiv.org/html/2512.16381)) | Coverage check: hypothesis must explain all salient anomalies |
| Correct answer, no evidence | Hallucinated or weak evidence | CTBench evidence F1 5.23–15.80% ([CTBench](https://arxiv.org/html/2608.12002)) | Evidence-grounding vs gold evidence |
| Anchoring on inherited reasoning | Anchoring | Best Correct Flip Rate 29.1%; scale does not reliably help ([TeleResilienceBench](https://arxiv.org/abs/2605.09929)) | Missed-refutation rate; void-refutation rate |
| Stalling, loops, budget exhaustion | Stalled/confused | Timeouts 9% of runs, 23% of spend ([FaulT-Bench](https://arxiv.org/html/2608.27021)); "exploration meltdowns" ([NetAgentBench](https://arxiv.org/abs/2604.09678)); 81.36 rounds for a 19.84% agent (CTBench) | Timeout rate, cost share, rounds per verdict |
| **Over-diagnosis of healthy networks** (telecom-specific) | None | 11–24% by agent, 47% for vague tickets (FaulT-Bench); LLMs flag normal KPI samples (TelecomTS, secondary) | False-verification rate on no-fault snapshots |
| **Under-detection by base models** | Rarely measured | Base GPT-4.1-nano recall 30%, faulty networks called "normal" ([Hatami et al.](https://arxiv.org/html/2512.19697)) | Missed-fault rate |
| **Localization weaker than identification** | Partly | Loc < ID for every CTBench agent; NIKA 89.0 → 68.7 → 55.3 | Split detection / localization / identification |
| **Degradation with topology scale** | Weak | NIKA 11 → 101 nodes, tokens nearly double | Report by number of components involved |
| **Weak spec recall despite high fault-QA scores** | None | Spec recall <60% vs fault QA 90–98% ([Sengupta et al.](https://arxiv.org/html/2608.21021)) | Clause-citation validity for spec predicates |
| **Unsafe actions on live state** | Partly | Correct-but-unsafe fixes ([NetArena](https://arxiv.org/html/2506.03231v2)); harm rises as success falls ([Safety Signals](https://arxiv.org/html/2609.14422v2)) | Removed by design: read-only snapshot |
| Overconfidence | Calibration | Systematic overconfidence; ensembling cuts ECE up to 88% ([Twin-Pass](https://arxiv.org/abs/2604.13271)) | Do not use verbalised confidence for abstention |
| Domain-model collapse | None | TelecomGPT-R1 4.76% in an agent harness (CTBench) | Screen models in-harness, not on MCQs |

The most important cross-paper interaction for R2 is **SADE versus FaulT-Bench**. Separating evidence gathering from hypothesis commitment gave **+37 pp root-cause F1, 22 pp of it from the policy alone** ([SADE](https://arxiv.org/abs/2605.04530)). Yet the same agent had the **highest over-diagnosis on healthy networks, 24%** ([FaulT-Bench](https://arxiv.org/html/2608.27021)). A Generator → Falsifier pipeline shares this structure. The literature therefore predicts that VERDICT's weak spot is specificity on healthy or ambiguous snapshots, not accuracy on clear faults. An evaluation that only scores faulty incidents would hide exactly the failure VERDICT is most likely to have.

### Score the process with deterministic per-step checks

The network-agent benchmarks score the reasoning process in five ways:
1. **Hierarchical outcome levels.** NIKA scores detection, localization and RCA.
2. **Per-step state or safety checks** against an emulator or symbolic replay: NetArena, Safety Signals, and NetAgentBench's FSM.
3. **Efficiency proxies:** steps, tool calls, tokens, timeouts, and inspection share.
4. **LLM-judge rubrics:** FaulT-Bench's grounding/causality/coverage, and the three-judge agreement in 2608.21021.
5. **Interface reliability and collateral damage** (ANI-Gamut).

The evidence favours the deterministic kinds. The LLM-judge verifier in Safety Signals peaks at the first step and degrades as more trajectory is given, while deterministic replay gives per-action ground truth ([Safety Signals](https://arxiv.org/html/2609.14422v2)). LLM judges also disagree by provider: the same answers were graded 82% versus about 94% ([Sengupta et al.](https://arxiv.org/html/2608.21021)).

VERDICT's predicate trail (claim → predicate → executed result → verdict) is a deterministic process record for free. R2 can score it per step:
- grounding coverage: the share of claims in the final explanation backed by a re-executed predicate;
- inspection-before-commit: whether a predicate ran before each verdict (the r_s = +0.78 precedent);
- predicate validity: well-typed, executable against the schema, and with a clause citation where spec-based;
- void-refutation rate: refutations whose predicates cannot discriminate;
- fratricide, and its two duals: missed refutation and false verification.

No network or telecom paper in the notes reports a fratricide or void-refutation rate, trains a process reward model for diagnosis, or checks automatically that claims cite the right protocol-trace evidence. These are genuine R2 contributions, with no external reference values to compare against.

On contamination, no telecom study measures it directly. The indirect evidence is consistent with surface pattern-matching: near-ceiling fault Q&A with weak spec recall, and difficulty labels that track factual specificity ([TeleResilienceBench](https://arxiv.org/abs/2605.09929)). That makes VERDICT's null-evidence and perturbation controls among the first explicit contamination controls in telecom RCA. srsRAN/Open5GS error strings and 3GPP cause codes are common on the web, so perturbation should also cover cause-text strings and alarm or ticket wording, not only IDs and timestamps.

## Strengthening VERDICT: evidence-backed redesign

The team has said any part of VERDICT can change. The changes below come only from findings in the notes. They are ranked by impact relative to effort, and each is marked **must-do** or **optional**.

The organising idea is simple. **Stop treating the deterministic baseline as a rival and make it VERDICT's foundation.** Then spend the LLM budget where the literature says LLMs fail: evidence, refutation and abstention.

### Ranking at a glance

| Rank | Change | Component | Priority | Effort |
|---|---|---|---|---|
| 1 | Healthy and misleading-alarm episodes; "no fault" as a scoreable output; false-verification rate | Evaluation, Outputs, Orchestrator | Must | Low |
| 2 | Gold evidence written at injection time; evidence-grounding metric; detection / localization / identification split | Corpus, Evaluation | Must | Low |
| 3 | Statistics plan: bootstrap CIs, seeded parameterised instances, pre-registered win-claims | Evaluation | Must | Low |
| 4 | Falsifier sees the claim, not the reasoning; missed-refutation rate; abstention from predicates, never verbalised confidence | Falsifier, Orchestrator, Evaluation | Must | Low |
| 5 | Typed predicate DSL validated against the Broker schema before execution | Predicate language, Orchestrator | Must | Low–Med |
| 6 | Deterministic PCAP decoding plus a TS 38.401 golden-flow predicate library, including absence predicates | Broker, Falsifier | Must | Medium |
| 7 | Tiered deterministic front-end as both Condition 0 and the Generator's candidate prior | Broker / new front-end, Generator, Arch C | Must | Medium |
| 8 | Phase-gated Orchestrator with a coverage requirement and a hard turn and cost budget | Orchestrator, Arch A/B/C | Must | Low |
| 9 | Broker: Prometheus exporter, VES-shaped derived alarms, TS 28.552 names, per-interface time-windowed summaries, pinned versions, clock sync | Broker | Must (Track B requires it) | Medium |
| 10 | Corpus design: confusable pairs, compound and held-out faults, emulated-radio strata | Corpus | Must | Medium |
| 11 | MDA-aligned output schema plus a top-K list next to the verified answer | Outputs | Should | Low |
| 12 | Extended perturbation: alarm/ticket wording personas and cause-string rewriting | Evaluation | Should | Low–Med |
| 13 | Mandatory spec retrieval (Chat3GPP/Telco-RAG recipe) with clause citation; IEs from decoders | Generator/Falsifier tools | Should | Medium |
| 14 | Model screening in three stages over 7–32B Qwen/Gemma-class models, with and without RAG | Model selection | Should | Low–Med |
| 15 | Architecture C reselects from the deterministic top-K | Arch C | Optional | Low |
| 16 | Modality ablation (logs-only, KPIs-only, PCAPs-only) | Evaluation | Optional | Low |
| 17 | Calibrated LLM judge for explanation quality only, with a human-labelled sample | Evaluation | Optional | Low |
| 18 | Self-consistency (k Generator samples) ablation for calibration | Generator | Optional | Low |
| 19 | Release the labelled corpus plus scenario YAML as a Track A replay spec | Corpus | Optional | Low–Med |

### Must-do changes

**1. Add healthy and misleading-alarm episodes, and make "no fault" a correct answer.**
- *Change.* Add no-fault snapshots and "false-premise" episodes, where the alarm or ticket text claims a fault on a healthy network or names the wrong component, to the corpus. Extend the Orchestrator's outputs from {verified cause, unresolved} to {verified cause, unresolved, no fault found}. Report a **false-verification (over-diagnosis) rate** next to fratricide.
- *Evidence.* Agents over-diagnose healthy networks at 11–24%, rising to 47% for vague tickets, and lack "a criterion for concluding, with evidence, that no fault exists" ([FaulT-Bench](https://arxiv.org/html/2608.27021)). SADE's structured pipeline had the worst over-diagnosis at 24% (same source). Base models show the opposite failure, 30% recall ([Hatami et al.](https://arxiv.org/html/2512.19697)).
- *Benefit.* It measures the failure VERDICT's architecture is most likely to have, and turns the "unresolved" design into a measured advantage.
- *Cost/fit.* Low. Healthy runs fall out of the harness for free; OM_module already ships fault-free baselines ([OM_module](https://github.com/Parz1val02/OM_module)). Fits easily.

**2. Write gold evidence at injection time, and split the headline metric.**
- *Change.* For every fault family, author once an "expected first evidence" field, e.g. "F1 SETUP absent" or "NAS Authentication Failure, MAC failure", and store it in the incident metadata. Score: detection; localization (network element and interface); identification (fault class); and **evidence grounding**, meaning the overlap between the predicates that decided the verdict and the gold evidence.
- *Evidence.* CTBench's golden-evidence metric exposes evidence F1 of only 5.23–15.80% even when answers are correct, and localization trails identification for every agent ([CTBench](https://arxiv.org/html/2608.12002)). NIKA's detection → localization → RCA ladder falls from 89.0 to 68.7 to 55.3 for GPT-5 ([NIKA](https://arxiv.org/html/2512.16381)).
- *Benefit.* It shows VERDICT's provenance advantage numerically, where a single top-1 number would hide it.
- *Cost/fit.* Low: one field per fault family. It doubles as the Falsifier's reference predicates.

**3. Plan the statistics before running anything.**
- *Change.* Generate many seeded, parameterised instances per family. Report bootstrap confidence intervals for every metric. **Pre-register** the claims VERDICT is expected to win:
  - correct "unresolved" or "no fault" on out-of-taxonomy and healthy cases;
  - evidence grounding and provenance;
  - compound and held-out faults;
  - time or effort to isolate (Track B's stated outcome).
- *Evidence.* Confidence-interval overlap between agents falls from as high as 85% on small static sets to 0% on large generated ones ([NetArena](https://arxiv.org/html/2506.03231v2)). On clean, few-class, single-fault data, classical models reach about 90% F1 or more ([Azkaei et al.](https://arxiv.org/html/2509.03290); [Simba](https://arxiv.org/html/2406.15638v1)).
- *Benefit.* It prevents an unpublishable "no significant difference" outcome, and protects against a strong Condition 0 matching VERDICT on accuracy.
- *Cost/fit.* Low.

**4. Prevent the Falsifier from anchoring, and keep confidence out of the abstention decision.**
- *Change.* Pass the Falsifier only the Generator's structured *claim* (cause, location, expected consequences), never its reasoning text. Score a **missed-refutation rate** (a wrong hypothesis survives) next to fratricide and void refutation. The Orchestrator decides "unresolved" only from predicate outcomes. If a confidence is shown, derive it from ensembling.
- *Evidence.* The best telecom model corrects only 29.1% of inherited flawed traces, and scale does not reliably help ([TeleResilienceBench](https://arxiv.org/abs/2605.09929)). Verbalised confidence is systematically overconfident, and twin-pass ensembling cuts ECE by up to 88% ([Twin-Pass](https://arxiv.org/abs/2604.13271)).
- *Benefit.* It attacks void refutations and rubber-stamping, the Falsifier's two most likely failures.
- *Cost/fit.* Low: interface discipline plus one metric.

**5. Make predicates a typed DSL that is checked against the snapshot schema before execution.**
- *Change.* Predicates are instances of a small grammar: message presence, absence or order on an interface; IE or cause equality; KPI threshold or delta over a window; log-event count; and temporal precedence. Before execution the Orchestrator rejects any predicate that names a field, counter, interface or log event absent from the Broker schema. A rejection never counts as a strike against the hypothesis. It is charged to the Falsifier's retry budget and logged as "invalid predicate", separate from a void refutation. Each predicate also carries a precondition and a one-sided tolerance, and a precondition failure means "not evaluable", never a refutation. Absence predicates must first confirm the capture was live over the window (correction from the R6 review).
- *Evidence.* LLMs violate interface semantics and hallucinate control logic in O-RAN code ([AutORAN](https://arxiv.org/abs/2603.18604)). A typed proposal interface with a deterministic arbiter protected 100% of services despite hallucinated proposals ([xTRUCE](https://arxiv.org/abs/2608.28532)). A typed transactional interface succeeded 6/6 against 0/6 for raw shell, at about one tenth the cost (pilot, [ANI-Gamut](https://arxiv.org/abs/2609.22723)). Tool-call errors are rare at 0.7–1.6% ([NIKA](https://arxiv.org/html/2512.16381)), so the DSL's job is semantic validity, not syntax.
- *Benefit.* It removes schema hallucination, makes void refutations detectable, and gives R2 a predicate-validity metric.
- *Cost/fit.* Low to medium. The grammar is small, and schema validation is a lookup.

**6. Decode protocol traces deterministically and ship a golden-flow predicate library.**
- *Change.* The Broker decodes F1AP, NGAP and E1AP PCAPs (plus NAS where visible) with tshark/ASN.1 into JSON event sequences. Correlation keys are the gNB-CU/DU UE F1AP IDs, the RAN UE NGAP ID, C-RNTI and the RAN UE ID. Build a library of expected flows from TS 38.401 cl. 8.5 (F1 startup), 8.1 (UE initial access, 18 steps) and 8.9 (E1 bearer context), plus NAS registration and authentication. The Falsifier *instantiates* library predicates rather than inventing them. Each predicate has the form "message M at step k of procedure P on interface I is present, absent or failed, with cause C". Absence predicates handle silence faults such as a wrong F1 address.
- *Evidence.* The normative flows are in TS 38.401 ([ETSI](https://www.etsi.org/deliver/etsi_ts/138400_138499/138401/19.03.00_60/ts_138401v190300p.pdf)). Metric-only ranking of F1-c delay reached only AC@1 0.20 because F1-c metrics are sparse ([UPC thesis](https://upcommons.upc.edu/bitstreams/99fb80d8-978c-477e-a66e-42adefbedfd5/download)). "Deterministic flow classification first, LLM explanation second" has precedent ([Isaac et al.](https://arxiv.org/abs/2508.09152)), and ASN.1-conformance and state-machine checks are workable ([RRC-LLM](https://arxiv.org/abs/2505.16821)). Silent faults show up in event sequences, not radio KPIs ([Chernov et al.](https://jyx.jyu.fi/bitstreams/072e0d7d-4179-4b29-bc44-3852be2feaf7/download)).
- *Benefit.* It covers 4 of the 6 planned faults, which are control-plane, and CTBench's hardest "interface-state" class. It also gives the Falsifier strong, verifiable predicates.
- *Cost/fit.* Medium; about 3–5 procedures need encoding. It fits, and it doubles as Track B's "failure classification" deliverable.

**7. Build a tiered deterministic front-end and use it twice.**
- *Change.* Build three tiers:
  - **Tier 1:** log and protocol signature rules, the golden-flow outcomes from change 6.
  - **Tier 2:** Szilágyi-style per-KPI profile deviation × a fault-signature matrix learned from the corpus, which yields a ranked cause list.
  - **Tier 3 (optional):** Random Forest or naive Bayes over KPI deltas plus protocol event counts, with SHAP.

  The front-end is used **(a) as Condition 0**, and **(b) as the Generator's prior**: the Generator receives the top-K candidate list and symptom summary, still with no raw telemetry. Add an ablation with the prior off, to measure anchoring on it.
- *Evidence.* Profile deviation × signature is an operator-grade baseline ([Szilágyi & Nováczki](https://doi.org/10.1109/tnsm.2012.031912.110155)). Naive Bayes over discretised symptoms is the canonical auditable classifier ([Khanafer](https://doi.org/10.1109/TVT.2007.912610)). RF on KPM features reaches macro-F1 0.90 at 0.224 ms ([Azkaei et al.](https://arxiv.org/html/2509.03290)). Event-count features catch silent faults (Chernov). LLM-synthesised *deterministic code* lifted alarm RCA from 0.5899 to 0.9179 F1 ([TN-AutoRCA](https://arxiv.org/html/2507.18190)). QoEReasoner's deterministic KPI tools plus a knowledge base beat baselines by 18–40% ([QoEReasoner](https://arxiv.org/abs/2606.01925)). A z-score-only baseline would be seen as a strawman (Mulvey survey; Szilágyi).
- *Benefit.* It answers the "strong Condition 0 matches VERDICT" threat: VERDICT now *adds to* Condition 0 rather than competing with it. The added value can be measured on cases where the front-end is wrong, ambiguous or out of taxonomy.
- *Risk.* The Generator may simply echo the top-1 candidate. The prior-off ablation measures this, and change 4 limits the damage.
- *Cost/fit.* Medium. Tiers 1–2 are rules and arithmetic. Tier 3 is a few lines of scikit-learn once features exist.

**8. Phase-gate the Orchestrator, require coverage, and cap the budget.**
- *Change.* Enforce phases: (i) the Broker snapshot is fixed; (ii) the Generator commits hypotheses; (iii) the Falsifier commits predicates; (iv) the Orchestrator executes; (v) the verdict. A surviving hypothesis must also pass a **coverage** check, explaining every salient anomaly flagged by the front-end, or the Orchestrator returns "unresolved" with the unexplained anomalies listed. Apply the same hard turn and token budget to Architectures A, B and C, and report timeouts separately.
- *Evidence.* Separating evidence acquisition from commitment gave +37 pp, 22 pp of it from the policy alone ([SADE](https://arxiv.org/abs/2605.04530)). Shallow single-symptom causes ("link unstable") are the dominant NIKA failure ([NIKA](https://arxiv.org/html/2512.16381)). FaulT-Bench's rubric scores coverage explicitly. Timeouts are 9% of runs but 23% of spend ([FaulT-Bench](https://arxiv.org/html/2608.27021)). A 19.84% agent used 81.36 rounds against 10.81 for the best ([CTBench](https://arxiv.org/html/2608.12002)). Expert-level tasks cause "exploration meltdowns" ([NetAgentBench](https://arxiv.org/abs/2604.09678)).
- *Benefit.* It addresses premature stopping, cost blow-ups and stalling, and makes the A/B/C comparison fair.
- *Cost/fit.* Low; this is orchestration logic.

**9. Have the Broker build what OCUDU lacks, in standard shapes.**
- *Change.* Build:
  - a websocket-JSON → Prometheus exporter using TS 28.552/KPM names;
  - rule-derived alarms in VES/3GPP-FM shape (eventId, sourceName, perceivedSeverity, probableCause, specificProblem, raised/cleared), grouped by connected component (DU↔CU↔AMF);
  - per-interface (F1, NG, E1, Uu) KPI and alarm summaries that keep time intervals and absolute units;
  - pinned versions and a single clock source.
- *Evidence.* OCUDU documents no Prometheus export, file metrics or tracing ([OCUDU Outputs](https://docs.ocudu.org/user_manual/outputs/)), and covers 24 of 278 TS 28.552 metrics ([OCUDU KPM](https://docs.ocudu.org/knowledge_base/e2sm_kpm_metrics/)). Per-interface textualisation was needed for F1 0.910 ([DAST](https://arxiv.org/abs/2606.06261)). Models struggle with noisy KPIs ([TelecomTS](https://arxiv.org/abs/2510.06063)). Topology-aware alarm grouping is standard ([Zhang et al.](https://arxiv.org/abs/2105.03092)). Orchestration-level signals missed 12 of 22 faults ([TU Delft](https://repository.tudelft.nl/record/uuid:c5f4b0eb-2e6b-4636-8498-e26411274e5a)). The O-RAN SC FM flow gives the alarm shape ([O-RAN SC wiki](https://lf-o-ran-sc.atlassian.net/wiki/spaces/IAT/pages/14516420/Fault+Management)).
- *Benefit.* It meets Cyshield's Prometheus and alarm requirements, supports a standards-alignment claim, and controls snapshot size.
- *Cost/fit.* Medium; this is unavoidable project work. Budget it in Phase 1.

**10. Design the corpus to separate VERDICT from classifiers.**
- *Change.* Include:
  - confusable pairs on purpose: DU CPU starvation vs channel noise (both raise BLER; only noise lowers SINR/CQI), and PLMN mismatch vs wrong key vs NF stopped (all block registration);
  - a compound-fault stratum;
  - a held-out stratum of fault families never seen while building the front-end's signature matrix;
  - cheap extra families: tc loss or delay on F1/N2, and memory pressure.

  Report emulated-radio strata separately.
- *Evidence.* Outage and low TX power are inseparable from radio KPIs, and RF/SVM collapse on sparse data from 92% to 71.3% exact match ([HYDRA](https://par.nsf.gov/servlets/purl/10406952)). Packet loss makes DU metrics look like high demand ([FALCON++](https://newslab.iith.ac.in/media/publications/pdfs/FALCON___Open_AI_RAN_workshop_2025.pdf)). Multi-failure F1 falls to about 0.8 for a strong classical model ([Simba](https://arxiv.org/html/2406.15638v1)).
- *Benefit.* It creates the conditions where verification and abstention matter, which are VERDICT's pre-registered win areas.
- *Cost/fit.* Medium. The compound faults need careful ground truth, using the "first manifestation" label.

### Should-do and optional changes

**11. Align the output with MDA, and add top-K.**
- *Change (should).* Emit `root_cause`, `demarcation` (NE + interface + procedure), `affected_objects`, `correlated_alarms[]`, `recommended_actions[]`, `provenance[]` and `status ∈ {verified, unresolved, no_fault}`, plus the front-end's ranked top-K for comparability.
- *Evidence.* TS 28.104 defines RCA as MDA output ([cl. 4.1](https://itecspec.com/3gpp/28.104/s/4.1)). TR 28.866 says root cause and demarcation are missing ([cl. 5.6.3.1](https://www.itecspec.com/3gpp/28.866/s/5.6.3.1)). Classical RCA reports top-K because top-1 is 61.8% while top-5 is 96.1% ([Zhang et al.](https://arxiv.org/abs/2105.03092)).
- *Cost/fit.* Low.

**12. Extend perturbation to wording and cause strings.**
- *Change (should).* Add alarm or ticket persona rewrites (standard, novice, unsure, no detail) and rewrite cause-text strings, on top of ID renaming and timestamp shifting.
- *Evidence.* Over-diagnosis rose from 17% to 47% across personas, and removing certainty cost 0.182 outcome ([FaulT-Bench](https://arxiv.org/html/2608.27021)). Error strings are widely public (testbed-notes inference).
- *Risk.* Rewriting PCAPs consistently with logs is hard; scope it early. OCUDU's strict log grammar makes log-side rewriting tractable ([Logging Guide](https://docs.ocudu.org/dev_guide/logging_guide/)).
- *Cost/fit.* Low to medium.

**13. Make spec retrieval a mandatory tool, with clause citations.**
- *Change (should).* Build a Chat3GPP-style index over TS 38.401, 38.473, 38.413, 38.331 and 38.321, plus selected O-RAN documents: section-path chunks of about 125–300 tokens, BM25 + BGE-M3 with RRF and rerank, and a Telco-RAG glossary for acronym expansion. Spec-based predicates must cite a retrieved clause. Field-level IE and cause semantics come from the decoders, not from RAG.
- *Evidence.* Zero-shot spec recall is below 60% ([Sengupta et al.](https://arxiv.org/html/2608.21021)). GPT-4 scores 64.78% on standards-spec MCQs ([TeleQnA](https://arxiv.org/abs/2310.15051)). Chat3GPP reaches 0.787 with no fine-tuning ([Chat3GPP](https://arxiv.org/abs/2501.13954)). Telco-RAG adds 14.45% over no RAG ([Telco-RAG](https://arxiv.org/abs/2404.15939)).
- *Risk.* No paper shows that spec RAG improves *RCA*, and RAG slightly hurt Gemma-2 27B ([ORANSight-2.0](https://arxiv.org/abs/2503.05200)). Treat it as an ablation, not an assumption.
- *Cost/fit.* Medium.

**14. Screen models in three stages.**
- *Change (should).*
  - Stage 1, knowledge: TeleQnA standards-spec, ORANBench and srsRANBench subsets (or GSMA Open Telco), with and without RAG.
  - Stage 2, diagnosis: a small OCUDU pilot set scored on evidence.
  - Stage 3, predicate validity: the share of Falsifier predicates that are well-typed, schema-valid and cited.

  Start from Qwen-2.5/3 and Gemma-2/3 at 7–32B. Exclude 1–3B models and small telecom fine-tunes.
- *Evidence.* Qwen-2.5 32B reaches 0.794 → 0.854 with RAG; Gemma-2 27B scores 0.911 on srsRANBench; 7–9B is the smallest size that beats GPT-4o ([ORANSight-2.0](https://arxiv.org/abs/2503.05200)). Tele-it scores 0.552 on the 3GPP subset ([Chat3GPP](https://arxiv.org/abs/2501.13954)). TelecomGPT-R1 scores 4.76% in an agent harness ([CTBench](https://arxiv.org/html/2608.12002)). Scale does not guarantee recovery from bad traces ([TeleResilienceBench](https://arxiv.org/abs/2605.09929)).
- *Cost/fit.* Low to medium. These are 2024–25 model generations, so re-screen successors.

**15. Let Architecture C reselect from the deterministic top-K (optional).**
- *Change.* When predicates refute the current hypothesis, "repair/reselect" draws the next candidate from the front-end's ranked list rather than asking the LLM to invent one. The two-strike rule still applies.
- *Evidence.* The correct cause is usually in the top 3–5 even when top-1 fails: 61.8% → 85.1% → 96.1% ([Zhang et al.](https://arxiv.org/abs/2105.03092)), and UPC's AC@1 of 0.64–0.73 rises above 75% at AC@3 ([UPC thesis](https://upcommons.upc.edu/bitstreams/99fb80d8-978c-477e-a66e-42adefbedfd5/download)).
- *Cost/fit.* Low.

**16. Run a modality ablation (optional).**
- *Change.* Give the Generator and Falsifier logs only, KPIs only, or PCAPs only, for the same incidents.
- *Evidence.* No paper isolates modality difficulty on a 5G stack, and the notes flag this as a gap. Indirect evidence suggests KPIs are hardest and distinctive logs easiest ([Hatami et al.](https://arxiv.org/html/2512.19697); [TelecomTS](https://arxiv.org/abs/2510.06063)).
- *Cost/fit.* Low; the Broker makes it cheap. It is a publishable side result.

**17. Use an LLM judge only for explanation quality, calibrated against humans (optional).**
- *Evidence.* Judges disagree by provider (82% vs about 94%) ([Sengupta et al.](https://arxiv.org/html/2608.21021)). Judges degrade on longer trajectories ([Safety Signals](https://arxiv.org/html/2609.14422v2)).
- *Cost/fit.* Low; it needs a small human-labelled sample.

**18. Ablate self-consistency for the Generator (optional).**
- *Change.* Sample k hypotheses from the Generator and use agreement for calibration.
- *Evidence.* It helps calibration (ECE) in telecom ([Twin-Pass](https://arxiv.org/abs/2604.13271)); there is no evidence yet for an accuracy gain.
- *Cost/fit.* Low.

**19. Release the corpus and scenario YAML (optional).**
- *Evidence.* Operators do not share labelled fault data ([Simba](https://arxiv.org/html/2406.15638v1)). None of the related testbeds publishes a downloadable labelled CU/DU corpus.
- *Benefit.* A contribution in its own right, and a replay spec for Track A.
- *Cost/fit.* Low to medium; the cost is mainly documentation.

Changes the evidence argues *against*:
- fine-tuning a telecom LLM (cost, plus the TelecomGPT-R1 collapse);
- giving the Generator raw multivariate KPIs (DAST, TelecomTS, QoEReasoner);
- relying on a single LLM critic that reads the Generator's chain of thought (TeleResilienceBench);
- any real O1/VES or SMO integration (low evaluation value per the standards notes).

### VERDICT v2 in one place

VERDICT v2 runs as a pipeline. Each step below is backed by the changes above.

1. **Broker.** It takes an immutable, version-pinned snapshot per incident:
   - decoded F1AP/NGAP/E1AP/NAS event sequences keyed on RAN UE IDs;
   - per-layer logs parsed to the OCUDU grammar;
   - KPIs under TS 28.552 names, also exported to Prometheus;
   - rule-derived, topology-grouped alarms in VES/3GPP-FM shape;
   - per-interface, time-windowed summaries in absolute units.
2. **Deterministic front-end.** Golden-flow rules, profile deviation × signature matrix, and an optional RF or naive Bayes produce a ranked top-K with the triggering evidence. Alone, this is Condition 0.
3. **Generator.** It still sees no raw telemetry. It receives the per-interface summary, the top-K candidates (switchable for ablation) and the spec-retrieval tool. It commits structured hypotheses, which may include "no fault", without access to the alarm text as instructions.
4. **Falsifier.** It receives only the claims and instantiates predicates from the typed DSL and the golden-flow library. Spec-derived predicates must cite a retrieved clause.
5. **Orchestrator.** It runs the phases in a fixed order, schema-validates and executes every predicate, applies the coverage check and the two-strike rule, and reselects from the top-K in Architecture C. It enforces one hard budget across Architectures A, B and C.
6. **Output.** The output is MDA-shaped: root cause, demarcation, affected objects, correlated alarms, recommended actions and the full predicate provenance, with status verified, unresolved or no fault, and the top-K alongside.

Evaluation runs these conditions:
- Condition 0 (the front-end alone);
- Architectures A, B and C;
- the null-evidence condition;
- perturbation over IDs, timestamps, cause strings and alarm wording;
- healthy and false-premise episodes;
- compound and held-out strata;
- emulated-radio strata reported separately.

It reports:
- detection, localization and identification;
- evidence grounding;
- false-verification, missed-refutation, fratricide and void-refutation rates;
- predicate validity;
- inspection-before-commit;
- timeouts and cost;
- top-K;

all with bootstrap CIs against pre-registered win-claims.

### Architecture D: Cascade (deterministic first, falsify to override)

VERDICT v2 still runs an LLM on every incident and races a strong Condition 0 on clean single-fault cases, where it will likely tie or lose on top-1 (see Open risks). Cascade, proposed by the team, changes the relationship: the deterministic front-end becomes the **first stage** of the architecture, and the LLM tiers may only **override** it when they can prove it wrong. It adds four mechanisms to VERDICT v2: a gate, an override rule, a coverage rule, and an open hypothesis space on top of the front-end's shortlist.

```
Incident snapshot (Broker)
        │
TIER 0 — deterministic, no LLM  (= Condition 0)
  • decoded F1AP/NGAP/NAS → cause-code rules
  • call-flow conformance vs TS 38.401 (expected message at step k?)
  • KPI deviation from healthy profile × fault-signature matrix
  → ranked top-K + confidence + list of unexplained anomalies
        │
GATE ──► Healthy: no anomaly vs healthy profile and all flows conform → "no fault"
     ──► Confident: top candidate passes its own predicates, explains ALL
         anomalies, clear margin over #2 → answer with 0 LLM calls
     ──► Otherwise ↓
        │
TIER 1 — Generator (LLM, still blind to raw telemetry)
  receives Tier-0 top-K + unexplained anomalies; may ADD hypotheses outside the taxonomy;
  each hypothesis = typed schema + propagation path on the OCUDU topology graph
        │
TIER 2 — Falsifier (LLM, sees the claim only) + Orchestrator (code)
  typed DSL predicates, absence predicates, "cause precedes symptom",
  must test ≥1 upstream alternative; schema validation; re-execution; two-strike
  COVERAGE RULE: the final cause set must explain every anomaly (→ multi-cause output)
        │
OVERRIDE RULE: Tier-0's top answer can be replaced only after it receives
a valid two-strike refutation
        │
Verified cause set + provenance  │  "unresolved" + ranked residuals + which evidence was missing
```

**Why it should match or beat the alternatives on each quality metric.** These are design arguments, to be confirmed by the ablations below, not measured results.

| Metric | Expected behaviour and the evidence behind it |
|---|---|
| Top-1 vs Condition 0 | Ties on gated cases because the answer is the same. Elsewhere it can only lose a correct Tier-0 answer through a re-executed two-strike refutation. Gains come from cases where the true cause is in Tier-0's top-K but not top-1: real-alarm RCA reaches 61.8% top-1 but 96.1% top-5 (Zhang et al., D10). |
| Top-1 vs A / B / C | A anchors on its first idea, and the best model corrects only 29.1% of inherited flawed reasoning (TeleResilienceBench, B8). B's Generator starts from a summary alone. Cascade starts from the deterministic shortlist and keeps the LLM's ability to add new candidates, the ceiling argument of LLM-as-an-Improver. |
| Fratricide | The override rule makes it expensive to kill a correct answer. Report **override fratricide**, the share of correct Tier-0 answers lost, as its own number. |
| Healthy networks / false verification | A deterministic healthy gate addresses FaulT-Bench's dominant failure: 11–24% over-diagnosis, rising to 47% under vague tickets (B2). |
| Evidence / provenance | Every verdict, including gated Tier-0 answers, is backed by re-executed predicates, which targets CTBench's evidence F1 of at most 15.8% (A1). |
| Compound faults | The coverage rule forces a cause *set* when one cause cannot explain every anomaly. Classical models degrade with simultaneous faults and sparse data (HYDRA, D7). |
| Out-of-taxonomy faults | Tier 1 can propose causes the rules do not know, and Tier 2 tests them. A pure rule engine scores zero here. |
| Abstention quality | "Unresolved" comes with the ranked residuals and the missing evidence, borrowing the data-integrity gate of CN121984837A claim 6 (F10). |
| Void refutations | The typed DSL is schema-validated before execution (ANI-Gamut, B6). |
| Cost / time-to-isolate | Median cost should stay near Condition 0, because most clean incidents end at the gate, and well below A, B and C. Mean cost and latency stay above a pure rule engine. This is the one dimension where no LLM architecture can win. |

**Caveats.**
1. **Tier-0 overfitting.** The team writes both the rules and the injected faults, so Tier 0 will look unrealistically strong on a clean corpus. Cascade's advantage only shows on held-out fault types, held-out configurations, compound faults, vague-alarm summaries and healthy episodes (redesign items 1 and 10). Those strata are mandatory, not optional.
2. **The gate is the single point of failure.** A confidently wrong Tier-0 answer never reaches the LLM tiers. The gate therefore requires the candidate to pass its own predicates and explain every anomaly. Report the **confident-wrong gate rate** separately.
3. **Story change.** The claim becomes "a verified hybrid that matches rules and agents everywhere and beats them where it matters", not "an adversarial LLM beats everything". It also matches Track B's "deterministic classifier first, LLM second". The four-part novelty survives: blind Generator, adversarial Falsifier, re-executed typed predicates, measured abstention.

**Ablations that attribute the gains.**
- Tier 0 alone (= Condition 0)
- No gate (the LLM always runs)
- No override rule (the LLM may replace Tier 0 freely)
- No coverage rule (single-cause output)
- No Tier-0 shortlist to the Generator (= VERDICT B)

**Plan impact.** Cascade is VERDICT v2 plus the gate, the override rule and the coverage rule. It fits the existing schedule:
- Architecture A remains the month-6 demo.
- Cascade replaces B as the main contribution.
- Architecture C's repair loop becomes Tier 2's fallback when every candidate is refuted.

## Consolidated recommendations by category

| Category | Recommendation | Source of evidence | Redesign item |
|---|---|---|---|
| New conditions | Healthy and false-premise episodes; compound and held-out strata; emulated-radio strata reported separately | FaulT-Bench; HYDRA; Simba; srsUE emulator docs | 1, 10 |
| New conditions | Perturbation of alarm/ticket wording and cause strings, in addition to IDs and timestamps | FaulT-Bench; testbed notes | 12 |
| New conditions | Modality ablation and front-end-prior on/off ablation | Gap noted in notes; TeleResilienceBench | 7, 16 |
| New metrics | Detection / localization / identification split; evidence grounding against gold evidence | NIKA; CTBench | 2 |
| New metrics | False-verification rate (dual of fratricide); missed-refutation rate; predicate validity; inspection-before-commit; timeout rate and cost share; top-K | FaulT-Bench; TeleResilienceBench; Safety Signals; Zhang et al. | 1, 4, 5, 8, 11 |
| Architecture | Adopt Cascade (Architecture D): Condition 0 as Tier 0, healthy/confident gate, override only after two-strike refutation, coverage rule for cause sets; report override fratricide and confident-wrong gate rate | Zhang et al.; FaulT-Bench; TeleResilienceBench; HYDRA; CTBench | 7, 16 + Architecture D |
| Statistics | Bootstrap CIs, seeded parameterised instances, pre-registered win-claims | NetArena | 3 |
| Baseline design | Condition 0 = log/protocol rules + Szilágyi-style deviation × signature + optional RF/naive Bayes with SHAP; never z-score-only | Szilágyi; Khanafer; Chernov; Azkaei; Mulvey | 7 |
| Scope exclusions | No real SMO/RIC/O1-VES/A1/R1, no closed-loop remediation, no OFH/RU/RF faults, no mobility or multi-cell, no multi-vendor validation claims, no telecom-LLM fine-tuning, no TM Forum certification | Standards notes; testbed notes; CTBench | — |
| Model screening | Three-stage screen; Qwen/Gemma-class models at 7–32B with and without RAG; exclude 1–3B and small telecom fine-tunes; no verbalised confidence | ORANSight-2.0; Chat3GPP; CTBench; Twin-Pass | 4, 14 |
| Positioning | Claim the four-part combination, not "multi-agent" or "verification" alone; cite Ericsson MAS, QoEReasoner and SADE; cite CN121984837A as prior art for generate-then-verify | Ericsson MAS; QoEReasoner; SADE; CN121984837A | — |

## Open risks that could sink the evaluation or the novelty claim

| Risk | Why it is real | Mitigation |
|---|---|---|
| **Strong Condition 0 matches VERDICT on a clean single-fault corpus** | Classical models reach about 90% F1 on clean few-class data (Azkaei; Simba). 4 of 6 planned faults are control-plane faults with strong log signatures, so a log-rule baseline could approach perfect discrimination (classical-notes inference) | Front-end-as-prior design (7); confusable, compound, held-out and healthy strata (1, 10); pre-registered win-claims (3) |
| **Prior-art patent CN121984837A** | VERIFIED: it claims alarm-triggered LLM candidate generation plus verification queries against raw cloud O&M data, keeping candidates above an evidence-confidence threshold (pending CN application, filed 2026-03-16; see F10) | Cite it; do not claim generate-then-verify as novel. Frame novelty as blind Generator + adversarial Falsifier + typed re-executed predicates + measured abstention, none of which the verified telecom papers combine |
| **Higher accuracy bought with more false alarms** | SADE: +37 pp F1 but the worst over-diagnosis, 24% | Report false verification next to accuracy; include healthy episodes |
| **Falsifier rubber-stamps or writes void refutations** | Best Correct Flip Rate 29.1% | Claim-only interface; DSL; golden-flow library; missed-refutation and void-refutation metrics |
| **Too few incidents to separate conditions** | CI overlap of up to 85% on small static sets | Seeded parameterised generation; bootstrap CIs |
| **ZMQ realism** | Channel noise is only emulated; CPU starvation may manifest differently under ZMQ (inference, to validate) | Separate strata; claim transfer only for protocol-level faults |
| **OCUDU churn and documentation gaps** | Recent fork and rename; O1 support, Prometheus and the release status are UNVERIFIED | Pin versions; inspect the GitLab configs in month 1; build the exporter |
| **No external comparison number** | No LLM-on-CU/DU paper exists | Present Condition 0 and the classical lineage as the reference; release the corpus |
| **Several key papers are abstract-only** | QoEReasoner, xTRUCE, AutORAN, NetAgentBench, TelecomGPT, Tele-LLMs, Isaac et al. | Re-read full texts before quoting precise figures in the survey |
| **LLM-judge bias, if used** | 82% vs about 94% across providers; judges degrade with trajectory length | Deterministic scoring first; human-calibrated judge only for prose quality |
| **Contamination through public error strings** | Fault Q&A near ceiling while spec recall stays below 60% | Null-evidence condition plus cause-string perturbation |
| **Perturbing PCAPs consistently with logs** | Hard to keep consistent | Scope early; perturb decoded JSON if raw PCAP rewriting proves too costly |
| **RAG can hurt some models** | Gemma-2 27B fell from 0.829 to 0.820 with RAG | Screen with and without RAG |

## Summary table of all catalogued sources

| ID | Source (arXiv/DOI) | Year | Theme | Status | One-line relevance |
|---|---|---|---|---|---|
| A1 | CTBench, 2608.12002 | 2026 | LLM RCA telecom | Verified (full) | Best agent 47.6% vs humans 56.4%, evidence F1 ≤15.8%; template for evidence metric |
| A2 | TN-AutoRCA, 2507.18190 | 2025 | LLM RCA telecom | Verified (full) | Direct LLMs over-flag alarms (P ~0.4, R ~0.97); code synthesis lifts F1 to 0.918 |
| A3 | Ericsson MAS, 2511.00651 | 2025 | LLM RCA telecom | Verified (full) | Closest industrial Arch B; no telemetry-executed verification |
| A4 | Hatami et al., 2512.19697 | 2025 | LLM RCA telecom | Verified (full HTML; abstract in other notes) | OAI core + Chaos Mesh, 118 runs; fine-tuned 93% vs base 40% |
| A5 | Isaac et al., 2508.09152 | 2025 | LLM RCA telecom | Verified (abstract) | PCAP-first, LLM-second precedent for golden-flow predicates |
| A6 | DAST, 2606.06261 | 2026 | LLM RCA telecom | Verified (abstract) | Per-interface KPI textualisation, F1 0.910; detection not RCA |
| A7 | QoEReasoner, 2606.01925 | 2026 | LLM RCA telecom | Verified (abstract) | Deterministic tools + KB + planner, +18–40%; Arch A analogue |
| A8 | Pellejero et al., 2511.02532 | 2025 | LLM RCA telecom | Verified (abstract) | Self-reflection pattern; no numbers |
| A9 | Gajjar & Shah, 2605.11516 | 2026 | LLM RCA telecom | Verified (abstract) | Calls for neuro-symbolic verification |
| A10 | Navidan et al., 2602.14117 | 2026 | Agentic O-RAN | Verified (abstract) | Places RCA agent at Non-RT RIC/SMO |
| A11 | xTRUCE, 2608.28532 | 2026 | Agentic O-RAN | Verified (abstract) | Typed proposals + deterministic arbiter, 100% services protected |
| A12 | AutORAN, 2603.18604 | 2026 | Agentic O-RAN | Verified (abstract) | LLMs violate interface semantics; argues for typed DSL |
| A13 | Zhou et al., 2405.10825 | 2024 | Context | Verified (abstract) | LLM-for-telecom survey |
| A14 | Ameur et al., 2607.16066 | 2026 | Context | Verified (abstract) | Survey; prompt-injection risk via A1/E2/O1 |
| A15 | Tran et al., 2604.06171 | 2026 | Context | Verified (abstract) | RCA KB from tickets |
| A16 | Shi et al., 2607.02523 | 2026 | Context | Verified (abstract) | Edge fine-tuning cost |
| A17 | Daniel et al., 2606.11877 | 2026 | Context | Verified (abstract) | LLM NWDAF with Prometheus for free5GC |
| A18 | LLM-xApp (NSF PAR) | — | Agentic O-RAN | UNVERIFIED | Control, not RCA |
| A19 | 2603.07375 | 2026 | Agentic O-RAN | UNVERIFIED | rApp conflict orchestration |
| B1 | NIKA, 2512.16381 | 2025 | Agent failures/eval | Verified (full) | Det/Loc/RCA 89/68.7/55.3; shallow causes; tool count disputed (30+ vs 22) |
| B2 | FaulT-Bench, 2608.27021 | 2026 | Agent failures/eval | Verified (full) | Over-diagnosis 11–24% (47% vague); basis for no-fault condition |
| B3 | SADE, 2605.04530 | 2026 | Agent failures/eval | Verified | +37 pp (22 pp policy) from separating evidence from commitment |
| B4 | NetArena, 2506.03231 | 2025/26 | Agent failures/eval | Verified (partial HTML) | CI overlap 85% → 0%; statistical-power warning |
| B5 | Safety Signals, 2609.14422 | 2026 | Agent failures/eval | Verified (full) | Deterministic per-step labels; LLM judge declines with k |
| B6 | ANI-Gamut, 2609.22723 | 2026 | Agent failures/eval | Verified (abstract) | Typed interface 6/6 vs shell 0/6 at ~1/10 cost (pilot) |
| B7 | NetAgentBench, 2604.09678 | 2026 | Agent failures/eval | Verified (abstract) | FSM scoring; "exploration meltdowns" |
| B8 | TeleResilienceBench, 2605.09929 | 2026 | Agent failures/eval | Verified (abstract) | Best CFR 29.1%; Falsifier anchoring risk |
| B9 | Twin-Pass CoT, 2604.13271 | 2026 | Agent failures/eval | Verified (abstract) | Overconfidence; ECE −88% with ensembling |
| B10 | Sengupta et al., 2608.21021 | 2026 | Agent failures/eval | Verified (full) | Fault QA 90–98% vs spec recall <60%; judge bias 82 vs 94 |
| B11 | Nakamura & Eguchi, 2605.19627 | 2026 | Agent failures/eval | Verified (abstract) | 68.1% positive operator evaluations |
| B12 | NetConfEval, 10.1145/3656296 | 2024 | Agent failures/eval | Verified (metadata) | LLM front end + formal back end |
| B13 | LogGPT, 2309.01189 | 2023 | Agent failures/eval | Verified (abstract); FP claim unverified | Possible log over-diagnosis analogue |
| B14–B18 | 2507.01997; RoutingBench 2609.22848; 2605.12729; LLMParser 2404.18001; NetOpsBench | various | Agent failures/eval | UNVERIFIED | Leads only |
| C1 | TeleQnA, 2310.15051 | 2023 | Telecom LLM/RAG | Verified (full) | GPT-4 64.78% on standards specs; RAG +22.5% relative |
| C2 | ORAN-Bench-13K, 2407.06245 | 2024 | Telecom LLM/RAG | Verified (abstract) | O-RAN knowledge screen; RAG 0.784 |
| C3 | ORANSight-2.0, 2503.05200 | 2025 | Telecom LLM/RAG | Verified (full) | Qwen-2.5 32B 0.794 → 0.854 with RAG; Gemma-2 27B srsRAN 0.911 |
| C4 | TSpec-LLM, 2406.01768 | 2024 | Telecom LLM/RAG | Verified (abstract) | All-3GPP corpus; naive RAG 44 → 71% |
| C5 | Telco-RAG, 2404.15939 | 2024 | Telecom LLM/RAG | Verified (full) | Glossary + 125-token chunks; +14.45% over no RAG |
| C6 | Chat3GPP, 2501.13954 | 2025 | Telecom LLM/RAG | Verified (full) | Open hybrid RAG recipe, 0.787 without fine-tuning |
| C7 | Tele-LLMs, 2409.05314 | 2024 | Telecom LLM/RAG | Verified (abstract) | Small telecom models lag (0.552) |
| C8 | TelecomGPT, 2407.09424 | 2024 | Telecom LLM/RAG | Verified (abstract) | No open weights; R1 variant 4.76% on CTBench |
| C9 | RRC-LLM, 2505.16821 | 2025 | Telecom LLM/RAG | Verified (abstract) | ASN.1 + state-machine checks; template for predicates |
| C10 | CellularSpecSec-Bench, 2601.12716 | 2026 | Telecom LLM/RAG | Verified (abstract) | Why specs are hard: normative text, cross-refs, tables |
| C11 | GSMA Open Telco suite | — | Telecom LLM/RAG | Verified README; scores UNVERIFIED | 16,866-sample knowledge screen |
| C12 | 2510.06530 blind DoS | 2025 | Telecom LLM/RAG | UNVERIFIED | Long message history may hurt |
| D1 | Khanafer et al., 10.1109/TVT.2007.912610 | 2008 | Classical RCA | Verified (abstract) | Naive Bayes symptom→cause template |
| D2 | Szilágyi & Nováczki, 10.1109/TNSM.2012.031912.110155 | 2012 | Classical RCA | Verified (abstract) | Deviation × signature = proper Condition 0 |
| D3 | Gómez-Andrades et al., 10.1109/TVT.2015.2431742 | 2016 | Classical RCA | Verified (abstract) | Unsupervised SOM + expert labels |
| D4 | Chernov et al., 10.1109/VTCSpring.2015.7145707 | 2015 | Classical RCA | Verified (full) | Silent faults need event-sequence features |
| D5 | Mulvey et al., 10.1109/ACCESS.2019.2938410 | 2019 | Classical RCA | Verified (full) | FP-growth + expert causality graph; DL lacks causal model |
| D6 | Zhang, Zhu, Hossain, 1906.06357 | 2019/22 | Classical RCA | Verified (abstract) | Five obstacles incl. multisource fusion |
| D7 | HYDRA, 10.1109/ACCESS.2022.3185639 | 2022 | Classical RCA | Verified (full) | Multi-fault; RF/SVM collapse when sparse; confusable pairs |
| D8 | Simba, 2406.15638 | 2024 | Classical RCA | Verified (full) | GNN+Transformer F1 0.97/0.90 on 2 faults; public data |
| D9 | Azkaei et al., 2509.03290 | 2025 | Classical RCA | Verified (full) | RF macro-F1 0.90 at 0.224 ms on KPM |
| D10 | Zhang et al. (HPCI), 2105.03092 | 2020/21 | Classical RCA | Verified (full) | Real alarms: top-1 61.8%, top-5 96.1% |
| D11 | THP, 2105.10884 | 2022 | Classical RCA | Verified (full) | Real-data causal F1 ≤ ~0.51 |
| D12 | Shi et al., 2511.17505 | 2025 | Classical RCA | Verified (abstract) | Temporal causal sequences; no numbers |
| D13 | XAInomaly, 2502.09194 | 2025 | Classical RCA | Verified (abstract) | XAI for detection, not RCA |
| D14 | Farmani & Khalil Zadeh, 2311.02390 | 2023 | Classical RCA | Verified (abstract, low confidence) | Self-healing overview |
| E1 | OCUDU docs + LF announcements | 2026 | Testbeds/OCUDU | Verified (parts UNVERIFIED) | Logs, PCAPs, JSON metrics, KPM 24/278; no Prometheus or alarms |
| E2 | srsRAN Project Outputs docs | — | Testbeds/OCUDU | Verified | Inherited telemetry and gaps |
| E3 | srsUE channel emulator docs | — | Testbeds/OCUDU | Verified (4G line) | Channel noise is emulated only |
| E4 | Baguer UPC/NEC thesis | 2025/26 | Testbeds | Verified (full) | YAML + redeploy + metadata recipe; F1-c AC@1 0.20 |
| E5 | Attacking O-RAN Interfaces, 10.1109/OJCOMS.2024.3431681 | 2024 | Testbeds | PARTIAL | Loss/delay on F1/E2 as standard primitives |
| E6 | FALCON++ | 2025 | Testbeds | Verified (full); venue UNVERIFIED | Split srsRAN CU/DU; CPU/mem/loss injection; confounding |
| E7 | TU Delft fault atlas | 2026 | Testbeds | Verified (abstract) | 22 faults; orchestration layer misses 12 |
| E8 | OM_module (GitHub) | 2026 | Testbeds | Verified (repo) | Config/auth faults over ZMQ; Prometheus exporter pattern |
| E9 | RANsacked, 10.1145/3658644.3670320 | 2024 | Testbeds | Verified (full); CVE count disputed | Core crash bugs as a fault class |
| E10 | 5Greplay, 2304.05719 | 2021 | Testbeds | Verified (abstract) | Protocol-level replay injector |
| E11 | Moreira et al., 2507.17850 | 2025 | Testbeds | Verified (abstract) | DDoS on core NFs; low relevance |
| E12 | SAJD, 2511.17519 | 2025 | Testbeds | Verified (abstract) | Jamming detection loop; low relevance |
| E13 | TelecomTS, 2510.06063 | 2025/26 | Datasets | Verified (abstract) | KPIs hardest for LLMs; keep absolute units |
| E14 | gCastle 2111.15155 / PCIC 2021 | 2021 | Datasets | Verified / SNIPPET | Causal-discovery baseline tooling |
| E15 | ICASSP 2022 GC | 2022 | Datasets | Verified (page) | Live 5G RCA data; access unclear |
| E16 | 2608.21815 alarm benchmark | 2026? | Datasets | UNVERIFIED | Real alarms, F1 ~0.6 |
| E17 | AI Telco Troubleshooting Challenge | 2025–26 | Datasets | SNIPPET | Industry demand; real vs synthetic disputed |
| E18 | ARA OCUDU split testbed | — | Testbeds/OCUDU | SNIPPET | OCUDU split over F1 already run |
| E19–E22 | 2309.12994; CSIR testbed; VT DataPort; 2205.13178 | various | Testbeds | UNVERIFIED | Leads only |
| F1 | 3GPP TS 28.104 | 2026 (Rel-20) | Standards | Verified | RCA is MDA output; fault-management capability |
| F2 | 3GPP TR 28.866 | Rel-19 | Standards | Verified (5.6.3.1) | Root cause and demarcation officially "missing" |
| F3 | SA5 pCRs S5-213389 / S5-222376 | 2021–22 | Standards | SNIPPET | Alarm-analysis output vocabulary |
| F4 | 3GPP TS 28.552 | 2026 (Rel-20) | Standards | Verified | Standard counter names for Broker |
| F5 | 3GPP TS 38.401 v19.3.0 | 2026 | Standards | Verified (full) | Golden flows for predicates and taxonomy |
| F6 | ETSI GS ZSM 002 | 2019 | Standards | Verified (full) | Named "Root cause analysis service" |
| F7 | Polese et al., COMST, 2202.01032 | 2023 | Standards | Verified (full) | O1 FM/PA; rApp placement |
| F8 | O-RAN SC FM wiki / VES annex | 2020 | Standards | Verified / SNIPPET | Alarm shape for Broker |
| F9 | Dell US11838169B1 | 2023 | Standards/motivation | Verified | Multi-vendor troubleshooting pain |
| F10 | CN121984837A | 2026 | Prior art | VERIFIED | Cloud-alarm patent: LLM candidates + verification queries; no blind generator, refutation or abstention |
| F11–F13 | TM Forum AN levels; VIAVI; O-RAN SC O-DU VES | — | Context | SNIPPET | Context only |

## Conclusion

The new literature changes what VERDICT should claim. Top-1 accuracy on injected faults is the wrong battlefield. Classical deterministic methods already do well on clean, few-class data, and the OCUDU corpus will be clean and few-class. The open problems that telecom benchmarks expose are the ones accuracy hides:
- answers without evidence (CTBench);
- verdicts on healthy networks (FaulT-Bench);
- critics that inherit the reasoner's mistakes (TeleResilienceBench);
- LLM judges that cannot score long trajectories (Safety Signals).

VERDICT's components each map onto one of these, which is a stronger and more defensible thesis than "LLMs diagnose better". The practical consequence is architectural humility: put the deterministic front-end underneath VERDICT, and let the LLMs work only where determinism runs out, on proposing hypotheses beyond the signature table and on choosing which typed predicate would refute them.

For R2 in particular, the gap in the literature is itself the contribution. No network or telecom paper in the notes reports fratricide, void-refutation, missed-refutation or false-verification rates, or scores diagnosis trajectories with deterministic per-step evidence checks. An OCUDU corpus with gold evidence written at injection time would let the team publish the first process-level failure analysis of LLM RCA on a CU/DU stack. That holds even if Condition 0 ties VERDICT on accuracy, provided the claims are pre-registered and the novelty section cites CN121984837A as prior art for plain generate-then-verify.
