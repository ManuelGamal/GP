# Project task breakdown: gated VERDICT on OCUDU (Track B)

Every task needed to finish the project end to end, from the testbed to the final demo and paper: 158 tasks, ranked by risk × technical demand.

**Sources.** The revised plan and the gated VERDICT design (progress-update deck); Track B's feature list (pitch); the feasibility gaps, redesign items and open risks in `5G ORAN root cause analysis survey.md`. Nothing here is a new feature: where an item is optional or should-do in the report, the task says so.

## How the ranking works

- **Risk (1–5):** how likely the task is to fail, slip or block other tasks.
- **Demand (1–5):** how technically hard it is.
- **Score = Risk × Demand** (1–25). Ties break by higher risk, then by earlier phase.
- **Bands:** Critical 16+, High 12–15, Medium 8–11, Low 7 or less.
- **Phase:** P1 = M1–M4 deploy and instrument; P2 = M5 design; P3 = M6–M9 build and validate; All = runs throughout.
- Scores are judgements from the reading, not measurements. Re-score after the month-1 OCUDU inspection (ENV-02).

| Band | Tasks |
|---|---|
| Critical | 12 |
| High | 18 |
| Medium | 46 |
| Low | 82 |

**Areas:** Testbed (18) · Broker (20) · Fault corpus (21) · Tier 0 (10) · Gate (6) · Generator (8) · Falsifier (12) · Orchestrator (10) · Outputs (3) · Architecture A (5) · Models (8) · Spec retrieval (3) · Evaluation (14) · Benchmark (7) · Dashboard (3) · Project (10)

## Ranked task list

### Critical

| Rank | ID | Task | Area | Phase | Risk | Demand | Score | Why it ranks here | Depends on |
|---|---|---|---|---|---|---|---|---|---|
| 1 | BRK-05 | Decode F1AP captures deterministically (tshark/ASN.1) into typed JSON events | Broker | P1 | 4 | 4 | **16** | F1AP dissector support for OCUDU's version is unverified; F1-c metrics are sparse, so F1AP is the main F1 evidence | BRK-04 |
| 2 | BRK-06 | Decode NGAP and the NAS it carries into typed JSON events | Broker | P1 | 4 | 4 | **16** | Needed for registration and auth faults; depends on readable NAS | BRK-04, ENV-13 |
| 3 | BRK-08 | Join events across interfaces per UE using gNB-CU/DU UE F1AP IDs, RAN UE NGAP ID, C-RNTI and RAN UE ID | Broker | P1 | 4 | 4 | **16** | Wrong joins produce wrong causal chains for every downstream check | BRK-05, BRK-06, BRK-07 |
| 4 | FLT-11 | Inject compound faults and label them with the first-manifestation rule | Fault corpus | P1 | 4 | 4 | **16** | Ground truth for overlapping faults is hard to get right | FLT-03..FLT-10 |
| 5 | T0-01 | Encode the golden-flow library from TS 38.401: cl. 8.5 F1 startup, cl. 8.1 UE initial access (18 steps), cl. 8.9 E1 bearer context, plus NAS registration and authentication | Tier 0 | P1 | 4 | 4 | **16** | Spec reading plus exact message sequences; the Falsifier reuses it | BRK-09 |
| 6 | T0-03 | Build the call-flow conformance checker (is message M at step k present, absent or failed?), including absence | Tier 0 | P1 | 4 | 4 | **16** | Silence faults are only visible this way | T0-01, BRK-14 |
| 7 | FAL-01 | Write the typed predicate DSL: message presence, absence or order on an interface; IE or cause equality; KPI threshold or delta over a window; log-event count; temporal precedence | Falsifier | P2 | 4 | 4 | **16** | Core of the contribution; too narrow can't refute, too broad can't be checked | BRK-01 |
| 8 | FAL-02 | Define three-valued semantics: true, false, not evaluable; preconditions and one-sided tolerances | Falsifier | P2 | 4 | 4 | **16** | Missing data must never count as a refutation | FAL-01 |
| 9 | GATE-03 | Define 'salient anomaly' once, shared by the gate and the coverage rule | Gate | P2 | 4 | 4 | **16** | Vague definition breaks both the gate and coverage | T0-04 |
| 10 | EVAL-04 | Condition P: rename IDs, shift timestamps, replace 3GPP cause strings with opaque tokens, rewrite alarm wording, consistently across PCAPs and logs | Evaluation | P3 | 4 | 4 | **16** | Consistent rewriting is hard; fallback is perturbing the decoded JSON | BRK-09 |
| 11 | GEN-05 | Let the Generator add causes outside Tier 0's shortlist and validate them against the schema and topology | Generator | P3 | 4 | 4 | **16** | This is where the LLM adds value over rules; hardest to make reliable | GEN-03 |
| 12 | ORC-05 | Enforce the coverage rule: the final cause set explains every anomaly, else output unresolved with residuals | Orchestrator | P3 | 4 | 4 | **16** | Compound faults and multi-cause output depend on it | GATE-03 |

### High

| Rank | ID | Task | Area | Phase | Risk | Demand | Score | Why it ranks here | Depends on |
|---|---|---|---|---|---|---|---|---|---|
| 13 | FLT-09 | Injector: channel noise through the srsUE channel emulator, and confirm it works for NR | Fault corpus | P1 | 5 | 3 | **15** | NR availability is UNVERIFIED; may have to drop the family | ENV-05 |
| 14 | BRK-01 | Define the snapshot schema: decoded events, parsed logs, KPIs, alarms, metadata, version pins, liveness markers | Broker | P1 | 4 | 3 | **12** | It is the contract every component builds against; late changes ripple everywhere | ENV-11, ENV-12 |
| 15 | BRK-16 | Build the typed query API over events, logs, KPIs and alarms with time windows and typed results | Broker | P1 | 4 | 3 | **12** | Every agent and predicate goes through it | BRK-01, BRK-09 |
| 16 | BRK-17 | Build the Generator's deterministic per-interface (F1, NG, E1, Uu) time-windowed KPI and alarm summary in absolute units | Broker | P1 | 4 | 3 | **12** | The Generator sees nothing else; a lossy summary caps its accuracy | BRK-16 |
| 17 | ENV-05 | Bring up srsUE over ZMQ against the OCUDU DU and confirm NR attach works in split mode | Testbed | P1 | 4 | 3 | **12** | srsUE NR over ZMQ with a split OCUDU is unproven for us; blocks all traffic | ENV-03, ENV-04 |
| 18 | FLT-08 | Injector: DU CPU starvation (stress-ng, cgroups) and validate how it shows up under ZMQ | Fault corpus | P1 | 4 | 3 | **12** | May appear as stalls, not real-time deadline misses (report's inference) | ENV-10 |
| 19 | FLT-15 | Write gold labels at injection: cause, location (NE + interface + procedure), propagation graph and expected first evidence | Fault corpus | P1 | 4 | 3 | **12** | A wrong label silently corrupts every score | FLT-14 |
| 20 | FAL-05 | Make absence predicates confirm the capture was live over the window first | Falsifier | P2 | 4 | 3 | **12** | Otherwise a dead collector looks like a fault | FAL-04, BRK-14 |
| 21 | FAL-06 | Write the Falsifier prompt: sees the claim only, never the Generator's reasoning, and instantiates golden-flow predicates | Falsifier | P2 | 4 | 3 | **12** | Anchoring: best telecom model corrects only 29.1% of inherited flawed reasoning | GEN-01, T0-01 |
| 22 | GATE-01 | Implement the healthy check: no anomaly against the healthy profile and all flows conform, then answer no fault | Gate | P2 | 4 | 3 | **12** | Misfiring here either hides faults or over-diagnoses | T0-03, T0-04 |
| 23 | GATE-02 | Implement the confident check: top candidate passes its own predicates, explains every anomaly, and beats #2 by a margin | Gate | P2 | 4 | 3 | **12** | The gate is the single point of failure: a confident wrong answer never reaches the LLM | T0-08 |
| 24 | GATE-04 | Tune gate thresholds on the dev split only and freeze them before any test run | Gate | P2 | 4 | 3 | **12** | Tuning on test data invalidates the results | GATE-01, GATE-02, EVAL-09 |
| 25 | T0-08 | Attach self-check predicates to every rule candidate | Tier 0 | P2 | 4 | 3 | **12** | The confident gate needs candidates that pass their own checks | T0-07, FAL-04 |
| 26 | EVAL-13 | Decide how to measure Track B's outcome 'reduced investigation effort and faster fault isolation' (time-to-isolate, possibly a small study with Cyshield engineers) | Evaluation | P3 | 4 | 3 | **12** | Cyshield's stated success measure has no method yet | EVAL-05 |
| 27 | ORC-03 | Enforce the two-strike rule with independent strikes (different check on different evidence) | Orchestrator | P3 | 4 | 3 | **12** | Same-model critic errors correlate at 0.858 | FAL-09 |
| 28 | BRK-09 | Build one timeline across all components keyed on UE and cell (Track B event correlation) | Broker | P1 | 3 | 4 | **12** | Track B requirement; basis of every predicate | BRK-08, ENV-09 |
| 29 | FAL-04 | Build the deterministic predicate executor over a snapshot | Falsifier | P2 | 3 | 4 | **12** | Shared by Tier 0, the Falsifier and the Orchestrator | FAL-02, BRK-16 |
| 30 | T0-05 | Learn the per-KPI profile deviation x fault-signature matrix from the corpus (Szilagyi-style) to rank causes | Tier 0 | P2 | 3 | 4 | **12** | Needs enough labelled runs; must not see held-out families | T0-04, FLT-15 |

### Medium

| Rank | ID | Task | Area | Phase | Risk | Demand | Score | Why it ranks here | Depends on |
|---|---|---|---|---|---|---|---|---|---|
| 31 | BRK-02 | Collect logs from every component and parse OCUDU's strict per-layer log grammar into structured records | Broker | P1 | 3 | 3 | **9** | Logs carry the user-plane evidence (no F1-U/PDCP/SDAP PCAP) | ENV-11 |
| 32 | BRK-07 | Decode E1AP captures into typed JSON events | Broker | P1 | 3 | 3 | **9** | Bearer-context faults rely on it | BRK-04 |
| 33 | BRK-10 | Build the websocket JSON to Prometheus exporter | Broker | P1 | 3 | 3 | **9** | OCUDU documents no Prometheus export; Cyshield expects Prometheus | ENV-12 |
| 34 | BRK-12 | Derive alarms in VES/3GPP-FM shape (eventId, sourceName, perceivedSeverity, probableCause, specificProblem, raised/cleared) from log levels, KPI thresholds and protocol failures | Broker | P1 | 3 | 3 | **9** | OCUDU emits no alarms; Track B requires alarm analysis | BRK-02, BRK-10 |
| 35 | BRK-13 | Group alarms by connected topology component (DU-CU-AMF) | Broker | P1 | 3 | 3 | **9** | Ungrouped alarm storms mislead both rules and LLMs | BRK-12 |
| 36 | BRK-14 | Add a freshness check per collector so a dead collector is never read as a silent DU | Broker | P1 | 3 | 3 | **9** | Absence predicates are only valid if the capture was live | BRK-02, BRK-04 |
| 37 | ENV-03 | Build OCUDU in split mode (CU-CP, CU-UP, DU) from source and containerise each part | Testbed | P1 | 3 | 3 | **9** | Split-mode build and config are the first thing everything else needs | ENV-02 |
| 38 | ENV-06 | Verify end to end: registration, PDU session, ping and iperf traffic through N3 | Testbed | P1 | 3 | 3 | **9** | Proves the stack is healthy before any fault is injected | ENV-05 |
| 39 | ENV-07 | Decide whether more than one UE is needed for realistic KPIs; if so, run several srsUE instances with distinct subscribers | Testbed | P1 | 3 | 3 | **9** | Single-UE KPIs may be too flat to show faults | ENV-06 |
| 40 | ENV-10 | Script a full fresh redeploy (compose or scripts) that restores a clean state in a fixed time | Testbed | P1 | 3 | 3 | **9** | Every injected run needs a fresh redeploy and seed | ENV-06 |
| 41 | FLT-01 | Write the fault catalogue: 12-18 classes labelled by procedure x interface x network element x cause, from the TS 38.401 call flows | Fault corpus | P1 | 3 | 3 | **9** | Defines what the benchmark and Tier 0 cover | ENV-06 |
| 42 | FLT-02 | Check each fault family's realism over ZMQ and mark emulated-PHY strata | Fault corpus | P1 | 3 | 3 | **9** | Only protocol-level faults transfer to real radios | FLT-01 |
| 43 | FLT-14 | Write the scenario YAML format (Action + Anomaly) and the runner: fresh redeploy, seed, timestamped metadata | Fault corpus | P1 | 3 | 3 | **9** | Reproducibility of every incident | ENV-10 |
| 44 | FLT-16 | Admit only faults with visible impact; record recoverability | Fault corpus | P1 | 3 | 3 | **9** | 84% of injected faults were silent in one published benchmark | FLT-14 |
| 45 | FLT-18 | Run batches unattended overnight, with crash recovery and a runs-per-day estimate | Fault corpus | P1 | 3 | 3 | **9** | Corpus size depends on throughput | FLT-14 |
| 46 | FLT-21 | Record matched healthy baselines for each operating state | Fault corpus | P1 | 3 | 3 | **9** | Needed by Tier 0's profile deviation and the healthy gate | ENV-08 |
| 47 | T0-02 | Write cause-code rules over decoded F1AP, NGAP and NAS messages | Tier 0 | P1 | 3 | 3 | **9** | Strong signals for 4 of the 6 planned faults | BRK-05, BRK-06 |
| 48 | T0-04 | Build healthy KPI profiles per operating state | Tier 0 | P1 | 3 | 3 | **9** | Basis of deviation scoring and the healthy gate | FLT-21 |
| 49 | EVAL-01 | Build the scorer: detection, localization (NE + interface), identification, and evidence grounding against gold evidence | Evaluation | P2 | 3 | 3 | **9** | Scores the reasoning, not only the answer | FLT-15 |
| 50 | EVAL-02 | Implement the process metrics: false verification, missed refutation, fratricide, override fratricide, void refutation, predicate validity, inspection-before-commit, timeouts, cost, top-K | Evaluation | P2 | 3 | 3 | **9** | No reference values exist for several of them | EVAL-01, ORC-10 |
| 51 | FAL-03 | Validate every predicate against the Broker schema before execution | Falsifier | P2 | 3 | 3 | **9** | Removes schema hallucination | FAL-01, BRK-01 |
| 52 | FAL-07 | Constrain Falsifier output to the DSL grammar | Falsifier | P2 | 3 | 3 | **9** | Invalid predicates waste the retry budget | FAL-01, MOD-01 |
| 53 | GEN-01 | Define the hypothesis schema: cause, location, expected consequences, propagation path, with 'no fault' allowed | Generator | P2 | 3 | 3 | **9** | The Falsifier sees only this claim | OUT-01 |
| 54 | GEN-03 | Write the Generator prompt: summary + Tier-0 top-K + unexplained anomalies, blind to raw data, alarm text treated as data not instructions | Generator | P2 | 3 | 3 | **9** | Prompt quality and injection safety | BRK-17, T0-07 |
| 55 | GEN-04 | Constrain Generator output to the hypothesis JSON schema | Generator | P2 | 3 | 3 | **9** | Malformed output stalls the pipeline | GEN-01, MOD-01 |
| 56 | MOD-01 | Stand up local serving for 7-32B open models with enough context length and throughput | Models | P2 | 3 | 3 | **9** | Every LLM step depends on it | ENV-18 |
| 57 | MOD-03 | Screening stage 2: diagnose a small OCUDU pilot set, scored on evidence | Models | P2 | 3 | 3 | **9** | Agent-harness performance can collapse (TelecomGPT-R1: 4.76%) | MOD-01, EVAL-01 |
| 58 | ORC-01 | Build the phase-gated loop: fixed snapshot, hypotheses committed, predicates committed, execution, verdict | Orchestrator | P2 | 3 | 3 | **9** | Separating evidence from commitment gave +37 pp in SADE | GEN-04, FAL-07 |
| 59 | T0-07 | Output a ranked top-K with confidence, the triggering evidence and the list of unexplained anomalies | Tier 0 | P2 | 3 | 3 | **9** | The gate and Generator consume this format | T0-02, T0-03, T0-05 |
| 60 | A-01 | Build the single ReAct agent with Broker tools: log search, trace decoding, KPI queries, spec retrieval, predicate checks | Architecture A | P3 | 3 | 3 | **9** | The month-6 demo depends on it | BRK-16, MOD-01 |
| 61 | A-03 | Add the commit-predicate, re-execute, list-evidence-against and grammar-constrained-answer steps | Architecture A | P3 | 3 | 3 | **9** | Makes A a fair comparison with VERDICT | A-01, FAL-04 |
| 62 | BENCH-06 | Host scoring for the hidden test split without releasing its labels | Benchmark | P3 | 3 | 3 | **9** | RCA-100's answer key was downloadable | BENCH-03 |
| 63 | DASH-02 | Web view of one incident: timeline, hypotheses, predicate outcomes, status | Dashboard | P3 | 3 | 3 | **9** | Track B dashboard requirement; shows provenance | OUT-03 |
| 64 | EVAL-05 | Build the harness that runs every condition (0, N, A, gated VERDICT, P, ablations) reproducibly | Evaluation | P3 | 3 | 3 | **9** | Everything in the results table comes from it | EVAL-01 |
| 65 | EVAL-10 | Transfer check on secondary data: TeleLogs (gated access) and RCA-100 | Evaluation | P3 | 3 | 3 | **9** | Access to TeleLogs is gated | EVAL-05 |
| 66 | FAL-08 | Require at least one upstream-alternative test and 'cause precedes symptom' predicates | Falsifier | P3 | 3 | 3 | **9** | Stops shallow single-symptom verdicts | FAL-06 |
| 67 | FAL-12 | Require a clause citation for spec-based predicates | Falsifier | P3 | 3 | 3 | **9** | Spec recall is below 60% zero-shot | T0-01 |
| 68 | ORC-04 | Enforce the override rule: Tier 0's answer is replaced only after a valid two-strike refutation | Orchestrator | P3 | 3 | 3 | **9** | Protects correct rule answers | ORC-03 |
| 69 | ORC-09 | Optional: Architecture C repair loop that reselects from Tier 0's top-K when every candidate is refuted | Orchestrator | P3 | 3 | 3 | **9** | Folded into Tier 2 by the report's design | ORC-04 |
| 70 | OUT-03 | Link every verdict to its predicates and the raw evidence behind them | Outputs | P3 | 3 | 3 | **9** | Provenance is the selling point | ORC-02 |
| 71 | ENV-02 | Pin one OCUDU commit and inspect its GitLab configs in month 1: O1 support, metrics export, release status (all UNVERIFIED in the report) | Testbed | P1 | 4 | 2 | **8** | Recent fork and rename; undocumented behaviour can break the Broker plan | — |
| 72 | ENV-13 | Configure null NAS ciphering/integrity (or capture keys) so NAS messages are readable in NGAP captures | Testbed | P1 | 4 | 2 | **8** | Encrypted NAS hides auth and registration causes that several faults depend on | ENV-04 |
| 73 | ENV-18 | Secure GPU access for 7-32B models (VRAM, hours per week) and record the budget | Testbed | P1 | 4 | 2 | **8** | No GPU means no model screening and no evaluation | — |
| 74 | FLT-19 | Reserve held-out fault families and configurations that Tier-0 authors never see | Fault corpus | P1 | 4 | 2 | **8** | The team writes both rules and faults, so Tier 0 overfits otherwise | FLT-01 |
| 75 | EVAL-14 | Estimate compute: incidents x conditions x models x seeds, in GPU hours, and cut scope to fit | Evaluation | P2 | 4 | 2 | **8** | The full grid may not fit the GPU budget | ENV-18 |
| 76 | A-04 | Prepare the M6 live demo on Cyshield's testbed: script, rehearsal, recorded fallback | Architecture A | P3 | 4 | 2 | **8** | A live demo failure is visible to the client | A-03 |

### Low

| Rank | ID | Task | Area | Phase | Risk | Demand | Score | Why it ranks here | Depends on |
|---|---|---|---|---|---|---|---|---|---|
| 77 | ENV-08 | Define traffic profiles (idle, ping, iperf low and high) as the operating states that healthy baselines are matched to | Testbed | P1 | 3 | 2 | **6** | AgentRCA fell from 87.6% to 40.6% without matched baselines | ENV-06 |
| 78 | ENV-09 | Use one clock source (single host or chrony) and check that log, PCAP and metric timestamps line up | Testbed | P1 | 3 | 2 | **6** | Cross-component ordering is unusable without it | ENV-03 |
| 79 | ENV-11 | Enable every OCUDU PCAP (MAC, RLC, NGAP, N3, E1AP, F1AP, E2AP) and per-layer logs; measure CPU and disk overhead | Testbed | P1 | 3 | 2 | **6** | Capture overhead can itself disturb the DU | ENV-03 |
| 80 | PM-04 | Run the early go/no-go: does Condition 0 or null evidence already explain the pilot results? | Project | P1 | 3 | 2 | **6** | Learn in days, not months, if the research claim is dead | T0-09, EVAL-03 |
| 81 | EVAL-07 | Write the statistics plan: bootstrap confidence intervals, per-stratum results | Evaluation | P2 | 3 | 2 | **6** | CI overlap up to 85% on small static sets | — |
| 82 | EVAL-09 | Split dev and test, keep the hidden test split, and check for leakage | Evaluation | P2 | 3 | 2 | **6** | Gate tuning and Tier 0 must never see test data | FLT-15 |
| 83 | FAL-10 | Run the Falsifier on a different model family from the Generator | Falsifier | P2 | 3 | 2 | **6** | Same-family reviewers wrongly rejected 35% of correct answers vs 2% cross-family | MOD-05 |
| 84 | BENCH-03 | Package the release: frozen snapshots, scorer, rule baselines, hidden test split, licence | Benchmark | P3 | 3 | 2 | **6** | Release quality decides whether anyone uses it | BENCH-01 |
| 85 | GATE-05 | Measure the confident-wrong gate rate and analyse each case | Gate | P3 | 3 | 2 | **6** | New metric; tells whether the gate is safe | GATE-04, EVAL-01 |
| 86 | PM-10 | Run the M9 final demo with a recorded fallback | Project | P3 | 3 | 2 | **6** | Client-facing | DASH-03 |
| 87 | SPEC-03 | Run retrieval on/off as an ablation, not an assumption | Spec retrieval | P3 | 3 | 2 | **6** | No study shows spec retrieval improves RCA; it slightly hurt Gemma-2 27B | SPEC-02 |
| 88 | FLT-13 | Parameterise each family with 2-4 severities and 10-30 seeded repetitions | Fault corpus | P1 | 2 | 3 | **6** | Too few incidents leaves confidence intervals overlapping | FLT-03..FLT-10 |
| 89 | FAL-09 | Hash each predicate's structure (queries, operators, rounded thresholds) so 'a different predicate' is a mechanical test | Falsifier | P2 | 2 | 3 | **6** | Two-strike independence depends on it | FAL-01 |
| 90 | SPEC-01 | Index TS 38.401, 38.473, 38.413, 38.331 and 38.321 in section-path chunks of about 125-300 tokens | Spec retrieval | P2 | 2 | 3 | **6** | Should-do item 13 in the report; tool listed for Architecture A | — |
| 91 | SPEC-02 | Hybrid retrieval (BM25 + BGE-M3, RRF, rerank) with a telecom acronym glossary | Spec retrieval | P2 | 2 | 3 | **6** | Recipe from Chat3GPP and Telco-RAG | SPEC-01 |
| 92 | T0-06 | Optional: Random Forest or naive Bayes over KPI deltas and event counts, with SHAP | Tier 0 | P2 | 2 | 3 | **6** | Optional Tier 3 in the report | T0-05 |
| 93 | EVAL-11 | Failure forensics: classify agent failures against the 22-mode taxonomy | Evaluation | P3 | 2 | 3 | **6** | Explains why runs fail, not just how often | ORC-10 |
| 94 | ORC-07 | Implement the appeal path from the pitch | Orchestrator | P3 | 2 | 3 | **6** | Defined in the pitch's VERDICT diagram | ORC-03 |
| 95 | BENCH-04 | Get Cyshield's agreement to publish the lab corpus; choose the licence | Benchmark | P2 | 4 | 1 | **4** | External decision; without it there is no public benchmark | — |
| 96 | BRK-03 | Build a parser test suite from real log samples for each layer | Broker | P1 | 2 | 2 | **4** | Parser drift silently drops evidence | BRK-02 |
| 97 | BRK-04 | Collect PCAPs per interface with rotation and incident time windows | Broker | P1 | 2 | 2 | **4** | Feeds the decoder | ENV-11 |
| 98 | BRK-11 | Write the mapping table from OCUDU metric names to TS 28.552/KPM names and units | Broker | P1 | 2 | 2 | **4** | Needed for standards alignment | ENV-12 |
| 99 | BRK-15 | Store each snapshot immutably with a content hash and the pinned versions | Broker | P1 | 2 | 2 | **4** | Reproducibility and audit | BRK-01 |
| 100 | BRK-18 | Enforce and test access control: Generator gets the summary only, Falsifier gets raw queries | Broker | P1 | 2 | 2 | **4** | The blind-Generator claim depends on it | BRK-16 |
| 101 | BRK-19 | Measure query latency and snapshot size; set budgets | Broker | P1 | 2 | 2 | **4** | Slow queries inflate agent cost and time-to-isolate | BRK-16 |
| 102 | BRK-20 | Write integration tests that replay recorded snapshots through the whole Broker | Broker | P1 | 2 | 2 | **4** | Regression safety for every later change | BRK-16 |
| 103 | ENV-01 | Spec the testbed host: CPU cores, RAM, disk for PCAP retention, and CPU isolation for the DU's real-time threads; write it down | Testbed | P1 | 2 | 2 | **4** | Undersized host makes CPU-starvation faults and KPIs unreliable | — |
| 104 | ENV-04 | Deploy Open5GS at a pinned version and provision the subscriber database (IMSI, keys, slices) | Testbed | P1 | 2 | 2 | **4** | Known stack, but every config fault depends on it | ENV-01 |
| 105 | ENV-12 | Enable OCUDU's websocket JSON metrics and confirm the 27 metrics it emits | Testbed | P1 | 2 | 2 | **4** | Exporter is built on this feed | ENV-03 |
| 106 | ENV-15 | Write a smoke test (attach succeeds, metrics and captures flowing) that runs before every injection | Testbed | P1 | 2 | 2 | **4** | Catches a broken testbed before it pollutes the corpus | ENV-06 |
| 107 | FLT-03 | Injector: PLMN, TAC, DNN and S-NSSAI mismatches | Fault corpus | P1 | 2 | 2 | **4** | Realistic over ZMQ; config edits | ENV-10 |
| 108 | FLT-04 | Injector: wrong F1 address (a silence fault: F1 SETUP never appears) | Fault corpus | P1 | 2 | 2 | **4** | Needs absence predicates downstream | ENV-10 |
| 109 | FLT-05 | Injector: stop a network function (AMF, SMF or UPF) | Fault corpus | P1 | 2 | 2 | **4** | Simple; confusable with config faults | ENV-10 |
| 110 | FLT-07 | Injector: tc loss and delay on F1 and N2 | Fault corpus | P1 | 2 | 2 | **4** | Severity tuning needed | ENV-10 |
| 111 | FLT-10 | Injector: memory pressure | Fault corpus | P1 | 2 | 2 | **4** | Cheap extra family | ENV-10 |
| 112 | FLT-12 | Generate healthy snapshots (15-20% of the corpus) and false-premise episodes with misleading alarm or ticket text | Fault corpus | P1 | 2 | 2 | **4** | Agents over-diagnose 11-24% of healthy networks; must be measured | ENV-08 |
| 113 | FLT-17 | Have a second person audit a sample of labels per family | Fault corpus | P1 | 2 | 2 | **4** | Catches systematic label errors | FLT-15 |
| 114 | FLT-20 | Include confusable pairs on purpose: CPU starvation vs channel noise; PLMN mismatch vs wrong key vs NF stopped | Fault corpus | P1 | 2 | 2 | **4** | Separates verification from KPI-only classifiers | FLT-01 |
| 115 | BENCH-01 | Freeze the benchmark protocol | Benchmark | P2 | 2 | 2 | **4** | Plan item for Phase 2 | FLT-01, EVAL-01 |
| 116 | EVAL-03 | Condition N: null evidence (metadata only) | Evaluation | P2 | 2 | 2 | **4** | Contamination control | EVAL-05 |
| 117 | FAL-11 | Charge invalid predicates to a retry budget and log them apart from void refutations | Falsifier | P2 | 2 | 2 | **4** | Keeps metrics honest | FAL-03 |
| 118 | GEN-02 | Encode the OCUDU topology graph (UE, DU, CU-CP, CU-UP, AMF, SMF, UPF and their interfaces) | Generator | P2 | 2 | 2 | **4** | Propagation paths are expressed on it | — |
| 119 | GEN-08 | De-duplicate and order hypotheses before the Falsifier sees them | Generator | P2 | 2 | 2 | **4** | Wasted Falsifier budget otherwise | GEN-04 |
| 120 | MOD-02 | Screening stage 1, knowledge: TeleQnA standards subset, ORANBench and srsRANBench subsets, with and without retrieval | Models | P2 | 2 | 2 | **4** | Cheap first filter | MOD-01 |
| 121 | MOD-04 | Screening stage 3: share of Falsifier predicates that are well-typed, schema-valid and cited | Models | P2 | 2 | 2 | **4** | Predicate validity drives the whole pipeline | FAL-03 |
| 122 | MOD-05 | Pick cross-family pairs (Qwen- and Gemma-class, 8B and up); exclude 1-3B models and small telecom fine-tunes | Models | P2 | 2 | 2 | **4** | Plan item | MOD-02..MOD-04 |
| 123 | ORC-02 | Re-execute every predicate and reject refutations whose cited evidence does not support them | Orchestrator | P2 | 2 | 2 | **4** | Void refutations never count | FAL-04 |
| 124 | ORC-06 | Apply one hard turn, token and time budget to every architecture; report timeouts | Orchestrator | P2 | 2 | 2 | **4** | Timeouts were 9% of runs and 23% of spend in FaulT-Bench | — |
| 125 | ORC-08 | Emit the three outcome states (verified, unresolved, no fault) with provenance | Orchestrator | P2 | 2 | 2 | **4** | Abstention is a scored output | OUT-01 |
| 126 | ORC-10 | Log every agent call (prompt, output, tokens, latency, cost) for forensics | Orchestrator | P2 | 2 | 2 | **4** | Failure analysis needs full traces | — |
| 127 | OUT-01 | Define the MDA-shaped output: root_cause, demarcation, affected_objects, correlated_alarms, recommended_actions, provenance, status, plus top-K | Outputs | P2 | 2 | 2 | **4** | Standards alignment (TS 28.104, TR 28.866) | — |
| 128 | PM-02 | Write the requirements and architecture document | Project | P2 | 2 | 2 | **4** | Phase 2 deliverable | — |
| 129 | A-02 | Wrap the typed query API as function-calling tool schemas | Architecture A | P3 | 2 | 2 | **4** | Shared with VERDICT's agents | BRK-16 |
| 130 | DASH-01 | Grafana dashboards over the Prometheus KPIs and derived alarms | Dashboard | P3 | 2 | 2 | **4** | Track B dashboard requirement | BRK-10, BRK-12 |
| 131 | DASH-03 | Let a user pick a snapshot and run a diagnosis from the dashboard | Dashboard | P3 | 2 | 2 | **4** | Needed for the final demo | DASH-02 |
| 132 | EVAL-06 | Ablations: no gate, no override rule, no coverage rule, no shortlist (= ungated VERDICT), modality (logs, KPIs or PCAPs only) | Evaluation | P3 | 2 | 2 | **4** | Attributes each gain to a mechanism | EVAL-05 |
| 133 | EVAL-12 | Optional: LLM judge for explanation prose only, calibrated on a human-labelled sample | Evaluation | P3 | 2 | 2 | **4** | Judges disagree by provider (82% vs about 94%) | EVAL-05 |
| 134 | GEN-06 | Ablation: Generator with the Tier-0 shortlist turned off (measures anchoring) | Generator | P3 | 2 | 2 | **4** | The Generator may just echo Tier 0's top-1 | GEN-03 |
| 135 | GEN-07 | Optional ablation: sample k hypotheses and use agreement for calibration | Generator | P3 | 2 | 2 | **4** | Calibration only; no accuracy evidence | GEN-03 |
| 136 | OUT-02 | Write the recommended fix text for each fault family | Outputs | P3 | 2 | 2 | **4** | Track B asks for root-cause recommendations | FLT-01 |
| 137 | PM-08 | Write the paper on the benchmark and gated VERDICT, citing CN121984837A as prior art | Project | P3 | 2 | 2 | **4** | Novelty must be framed as the four-part combination | — |
| 138 | PM-09 | Write the graduation thesis and final documentation | Project | P3 | 2 | 2 | **4** | Required deliverable | — |
| 139 | MOD-07 | Pin model versions, temperatures and seeds for every run | Models | All | 2 | 2 | **4** | Reproducibility | — |
| 140 | PM-01 | Produce Cyshield's phase deliverables (Phase 1 40%, Phase 2 10%, Phase 3 50%) | Project | All | 2 | 2 | **4** | Grading and client milestones | — |
| 141 | PM-05 | Get mentor review of the fault catalogue and the Tier-0 call-flow checks | Project | P1 | 3 | 1 | **3** | External dependency (the ask) | FLT-01, T0-01 |
| 142 | EVAL-08 | Pre-register the win-claims and freeze them before test runs | Evaluation | P2 | 3 | 1 | **3** | Protects against a strong Condition 0 tie | EVAL-07 |
| 143 | PM-07 | Submit the survey to arXiv (needs an endorsement for the chosen category) | Project | P3 | 3 | 1 | **3** | Endorsement can take time | — |
| 144 | PM-06 | Set interface-freeze dates and weekly integration checkpoints | Project | All | 3 | 1 | **3** | Six owners build against shared contracts | — |
| 145 | BENCH-02 | Size v1 (a few hundred incidents) with Cyshield's mentors | Benchmark | P2 | 2 | 1 | **2** | Plan item | EVAL-14 |
| 146 | MOD-06 | Re-screen successor models before the final freeze | Models | P3 | 2 | 1 | **2** | Screened model generations are 2024-25 | MOD-05 |
| 147 | ENV-16 | Set up shared remote access, accounts and a booking schedule for testbed time | Testbed | All | 2 | 1 | **2** | Six people on one testbed collide | — |
| 148 | ENV-14 | Run and document the baseline scenarios (a Phase 1 deliverable) | Testbed | P1 | 1 | 2 | **2** | Required by Cyshield's Phase 1 | ENV-06 |
| 149 | T0-09 | Run Tier 0 alone as Condition 0 | Tier 0 | P2 | 1 | 2 | **2** | Main baseline | T0-07 |
| 150 | BENCH-05 | Publish the scenario YAML as a Track A replay spec | Benchmark | P3 | 1 | 2 | **2** | Optional item 19 | FLT-14 |
| 151 | BENCH-07 | Write the dataset documentation (datasheet) | Benchmark | P3 | 1 | 2 | **2** | Release requirement | BENCH-03 |
| 152 | MOD-08 | Account cost and latency per incident | Models | P3 | 1 | 2 | **2** | Cost per incident is a reported metric | ORC-10 |
| 153 | ENV-17 | Create the code repository, folder layout, CI with lint and tests, and branch rules | Testbed | All | 1 | 2 | **2** | Low risk, but needed from day one | — |
| 154 | FLT-06 | Injector: wrong subscriber key | Fault corpus | P1 | 1 | 1 | **1** | Simple subscriber edit | ENV-04 |
| 155 | GATE-06 | Add a switch that disables the gate (no-gate ablation) | Gate | P2 | 1 | 1 | **1** | Needed to attribute gains | GATE-01 |
| 156 | PM-03 | Write the risks and plan document | Project | P2 | 1 | 1 | **1** | Phase 2 deliverable | — |
| 157 | T0-10 | Keep the KPI z-score baseline as a weak reference only | Tier 0 | P2 | 1 | 1 | **1** | A z-score-only baseline alone would read as a strawman | T0-04 |
| 158 | A-05 | Run A under the same budget as VERDICT | Architecture A | P3 | 1 | 1 | **1** | Fair comparison | ORC-06 |

## Coverage check

Every Track B feature and every item on the revised plan maps to at least one task.

| Requirement | Source | Tasks |
|---|---|---|
| Log collection | Track B | BRK-02, BRK-04, BRK-15 |
| Event correlation | Track B | BRK-08, BRK-09 |
| Alarm analysis | Track B | BRK-12, BRK-13 |
| Failure classification | Track B | T0-01..T0-07 |
| Root-cause recommendations | Track B | OUT-01..OUT-03, ORC-08 |
| Dashboard visualization | Track B | DASH-01..DASH-03 |
| Deploy OCUDU with srsUE and a 5G core | Plan P1 | ENV-01..ENV-15 |
| Broker collectors: Prometheus exporter, trace decoder, derived alarms | Plan P1 | BRK-05..BRK-07, BRK-10, BRK-12 |
| Injection and capture pipeline | Plan P1 | FLT-01..FLT-21 |
| Tier-0 rules from TS 38.401 call flows | Plan P1 | T0-01..T0-03 |
| Requirements and gate design | Plan P2 | PM-02, GATE-01..GATE-03 |
| Gate thresholds tuned on a dev split | Plan P2 | GATE-04, EVAL-09 |
| Model screening: cross-family, 8B and up | Plan P2 | MOD-01..MOD-05 |
| Freeze the benchmark protocol | Plan P2 | BENCH-01, BENCH-02 |
| M6: Architecture A live demo | Plan P3 | A-01..A-05 |
| M7: gated VERDICT end to end | Plan P3 | GEN-*, FAL-*, ORC-* |
| M8: benchmark v1 and full evaluation | Plan P3 | EVAL-01..EVAL-14, BENCH-03 |
| M9: dashboard, release, paper and survey | Plan P3 | DASH-*, BENCH-03..BENCH-07, PM-07..PM-10 |
| Asks to Cyshield: mentor review, publishing agreement, testbed time | Deck | PM-05, BENCH-04, ENV-16 |

## Tasks inferred, not quoted

These tasks are not named in the deck, pitch or report. They are steps the documented work cannot be done without. Check them with the team:

- **ENV-07:** whether one UE gives realistic enough KPIs
- **ENV-13:** NAS is ciphered after security mode, so auth and registration causes are unreadable without null ciphering or keys
- **ENV-15:** smoke test before each injection
- **ENV-16:** shared testbed access for six people
- **ENV-18:** GPU access for 7-32B models
- **BRK-19:** query latency and snapshot size budgets
- **FLT-17:** second-person label audit
- **FLT-18:** unattended batch runs
- **EVAL-13:** a method for measuring Track B's investigation-effort outcome
- **EVAL-14:** the compute estimate for the full evaluation grid
- **PM-06:** interface-freeze dates
- **PM-07:** arXiv endorsement

## Out of scope (from the report)

Real SMO, Non-RT RIC, O1/NETCONF/VES and A1/R1 integration; closed-loop remediation; Open Fronthaul, RU and RF faults; mobility and multi-cell; multi-vendor validation claims; telecom-LLM fine-tuning; TM Forum certification.
