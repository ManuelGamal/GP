# Reader grades: VERDICT survey reading assignment

Each reader's work was checked against the full text of the primary papers (arXiv/venue) and graded on one rubric:
- factual accuracy: 25
- coverage: 20
- technical depth: 15
- critical analysis: 15
- relevance to VERDICT / O-RAN: 15
- presentation and citations: 10

Full reviews, with every verified error, are in `C:\Users\manue\research_notes\VERDICT survey reader review\R*_review.md`. R2 was not graded because it is the coordinator's own work.

| Reader | Role | Acc /25 | Cov /20 | Depth /15 | Crit /15 | Rel /15 | Pres /10 | Total | Grade |
|---|---|---|---|---|---|---|---|---|---|
| R6 (Verina Hany) | Falsification & Contamination | 23 | 18 | 14 | 12 | 13 | 9 | **89** | B |
| R4 | Evidence & Broker | 22 | 17 | 11 | 10 | 12 | 8 | **80** | B |
| R3 | Competing Architectures | 16 | 17 | 14 | 13 | 11 | 7 | **78** | C |
| R5 | Fratricide & Critic | 23 | 17 | 13 | 12 | 3 | 8 | **76** | C |
| R1 | Corpus & Benchmarks | 22 | 11 | 5 | 6 | 2 | 4 | **50** | F |

## One-line verdicts
- **R6:** the strongest. Accurate long tables, real defects caught in the papers, and a concrete build list (predicate preconditions, one-sided tolerance, snapshot hashing, falsifier validation with Youden's J). It caught our error: a malformed predicate must not count as a strike. Missing: an O-RAN adaptation, and message presence/absence predicate forms.
- **R4:** about 75 numbers checked, all correct. Two results are mis-scoped: AgentRCA's 40% covers 10 faults, not 21, and OpsHarness's 0.83 vs 0.43 is a training-split figure. It missed validity problems in CoreSec and ARGUS, and the Broker/provenance design is only partly delivered.
- **R3:** the GALA+, LATS-RCA, OpsAgent and STAR chapters are A-grade. The RCLAgent chapter and summary Table 4 contain invented details (dataset sizes, IEEE TSC venue, example), and several references are wrong. The novelty claim is overstated (it ignores the patent, SADE and the Ericsson system), and it uses the old architecture letters.
- **R5:** accurate summaries, with 4 minor errors in about 75 numbers. It never connects the papers to VERDICT: no Falsifier capability floor, no fratricide metric, no two-strike analysis.
- **R1:** a 3-page casual summary with no citations or IDs. It never answers the RCA-100 usability question and never mentions VERDICT. The numbers are mostly right; a few metrics are mislabelled.

## RCA-100 usability (answered by the reviewer, since R1 did not)
- **Access:** public (v1.1, 103 cases, about 3.43 GB).
- **Licence:** CC BY-NC-SA 4.0, so academic use is fine but Cyshield cannot use it commercially.
- **Scoring:** no scoring script is released, so we must write our own scorer.
- **Contamination risk:** the answer key is publicly downloadable.
