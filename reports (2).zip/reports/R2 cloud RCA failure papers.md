# Five cloud failure studies sharpen VERDICT

All five R2 papers agree on one thing. Cloud RCA agents rarely fail because the evidence is missing. They fail because they **misread it, never collect it, or override it with a story**, and a final-answer score hides all three.

- **#6 (Kim et al.)** finds interpretive hallucination in **71.2% of 1,675 OpenRCA runs**, and prompting does not remove it.
- **#7 (Riddell et al.)** finds that agentic loops give open models **no accuracy gain over a single pass**. Anchoring, stalling and failure to update belief each cut the chance of a correct answer by at least 45%.
- **#8 (Lu et al.)** finds that even correct localizations rest on partial causal maps. Edge F1 on correct runs **never exceeds 0.67**.
- **#9 (Gopal & Krishnan)** attributes most errors to reasoning gaps, not missing data. This is measured on a benchmark that was filtered for solvability.
- **#10 (ORCA-bench)** finds that the best frontier agents reach **25.3% accuracy on Medium tasks and 10.0% on Hard**, with 7–40% hallucinated diagnoses.

VERDICT already gives the remedy every paper asks for: external verification against raw data. Its typed, re-executed predicates do this. Its null-evidence condition directly measures the dominant failure.

The papers also show where VERDICT is still exposed:
- a symptom-level hypothesis can survive refutation;
- chronic background noise can be read as incident evidence;
- invented propagation edges go unchecked, because there is no topology graph;
- a single-cause output cannot handle compound faults;
- healthy snapshots can be over-diagnosed;
- the Falsifier can wrongly refute the true cause ("fratricide").

Blinding the Generator also moves the misreading risk into the Broker's summary.

On transfer to 5G: the failure families carry over to OCUDU, and the telecom evidence (CTBench, NIKA, FaulT-Bench, TeleResilienceBench) confirms them. The headline numbers do not carry over. Every paper is cloud microservice or IT data, and OpenRCA's "Telecom" domain is a database system, not a RAN. Code-generation failure, a major mode in #6, is contradicted wherever tools are typed.

R2's most valuable deliverable is a **deterministic trajectory evaluation**. It is computed from Broker query logs and a gold propagation graph written when each fault is injected, and it yields Node/Edge F1, verified Edge F1, first-hit, fratricide, evidence-use and loop rates. No telecom paper reports any of these.

**Architecture D (Cascade).** The earlier survey now proposes a fourth architecture, Cascade, to replace B as the main contribution:
- Condition 0 runs first, as Tier 0.
- A healthy/confident gate answers clear cases with no LLM call.
- The LLM tiers may override Tier 0's answer only after a re-executed two-strike refutation.
- A coverage rule forces a *set* of causes when one cause cannot explain every anomaly.

Cascade directly targets four of the gaps above: anchoring, symptom-as-cause, compound faults and over-diagnosis. It also creates two new risks that R2 must measure: **override fratricide** and **confidently wrong gate answers**. This report treats Cascade's expected benefits as design arguments to test, not as results.

**How to read this report.** Every number comes from the R2 notes, which were verified against full texts. Numbers marked *(notes' arithmetic)* were computed by the researcher, and values marked "≈" were read off charts. Telecom evidence and the numbered "survey change N" items refer to the team's earlier 5G/O-RAN survey ([Survey](file:///C:/Users/manue/reports/5G%20ORAN%20root%20cause%20analysis%20survey.md)), cited with its primary URLs. Architectures:
- A = single ReAct agent;
- B = VERDICT (deterministic Broker, blind Generator, Falsifier with typed predicates, Orchestrator with a two-strike rule and an "unresolved" output);
- C = verify-repair-reselect;
- D = Cascade.

---

## Paper #6: interpretive hallucination dominates and resists prompting

### Citation and availability

| Field | Details |
|---|---|
| Title | "Why Do AI Agents Systematically Fail at Cloud Root Cause Analysis?" |
| Authors | Taeyoon Kim and Woohyeok Park (equal contribution) and Kyungyong Lee (corresponding), Dept. of Data Science, Hanyang University; Hoyeong Yun, OKESTRO Co. (Intelligent Cloud Lab), Seoul |
| arXiv | 2602.09937 [cs.AI]; v1 10 Feb 2026, v2 4 Mar 2026; CC BY-NC-SA 4.0 ([arXiv v2](https://arxiv.org/html/2602.09937v2)) |
| Venue | Cloud Intelligence / AIOps Workshop 2026, co-located with ASPLOS 2026, Pittsburgh, 22 Mar 2026 ([workshop PDF](https://cloudintelligenceworkshop.org/papers/aiops26-Kim.pdf)). *Unverified:* acceptance is inferred only from the workshop hosting the PDF, because its landing page does not list the paper. |
| Length | Short workshop paper, about 5 pages |
| Code and data | No code, trajectories or pitfall labels released. The benchmark is the public OpenRCA. |

The 12 binary diagnostic questions are printed verbatim in the paper, so R2 can reimplement the instrument even without the artifacts.

### Summary: 1,675 runs, 3.9–12.5% perfect accuracy, and a 12-pitfall audit

**Problem.** Existing RCA-agent evaluations score only the final answer. They therefore cannot tell practitioners whether to invest in "stronger models, better prompts, or redesigned agent frameworks" ([arXiv v2](https://arxiv.org/html/2602.09937v2)).

**Setup.**
- **Agent:** the stock OpenRCA Controller–Executor agent. The Controller writes natural-language instructions. The Executor turns them into Python, runs the code in a persistent kernel, and returns a natural-language summary.
- **Data:** all **335 OpenRCA incidents**: Telecom 51, Bank 136 and Market 148, with 73 components, 28 fault reasons and 68.5 GB of metrics, logs and traces.
- **Models:** Claude Sonnet 4, GPT-5 mini, Gemini 2.5 Pro, Solar Pro 2 and GPT-OSS 120B.
- **Scale:** one run per model–incident pair, giving **1,675 runs**. Runs averaged 11.1 steps and in total took 609.9 hours, about 1.38 billion tokens and about $1,394.
- **Labelling:** a Claude Code / Opus 4.5 "analysis agent" first discovered failure patterns free-form. The authors consolidated these into a codebook, and the agent then answered binary diagnostic questions per pitfall. Humans verified every label ([arXiv v2](https://arxiv.org/html/2602.09937v2)).

Baseline "perfect" accuracy (component, time and reason all correct) is low for every model.

| Model | Overall Perfect / Partial (%) | Telecom | Bank | Market |
|---|---|---|---|---|
| Gemini 2.5 Pro | 12.5 / 22.4 | 11.8 / 13.7 | 19.9 / 19.9 | 6.1 / 27.7 |
| GPT-5 mini | 8.4 / 21.5 | 15.7 / 21.6 | 11.8 / 16.2 | 2.7 / 26.4 |
| GPT-OSS 120B | 6.9 / 12.2 | 9.8 / 15.7 | 7.4 / 11.8 | 5.4 / 11.5 |
| Solar Pro 2 | 5.7 / 15.8 | 9.8 / 11.8 | 6.6 / 15.4 | 3.4 / 17.6 |
| Claude Sonnet 4 | 3.9 / 14.3 | 5.9 / 7.8 | 4.4 / 15.4 | 2.7 / 15.5 |

Source: [arXiv v2, Table 1](https://arxiv.org/html/2602.09937v2).

The taxonomy has **12 pitfalls on three "interfaces"**:
- **Intra-agent reasoning (7 pitfalls)**, counted per run. The run rates sum to more than 100% because labels are multi-label.
- **Controller–Executor communication (3 pitfalls)**, counted per step.
- **Agent–environment interaction (2 pitfalls).**

| Pitfall (core issue) | Overall rate | Range across models |
|---|---|---|
| Hallucination in Interpretation (narrative fabrication) | **71.2%** | 66.9% (Gemini) – 79.5% (Claude) |
| Incomplete Exploration (skipped KPI/component) | **63.9%** | 53.7% (Solar) – 73.5% (Claude) |
| Symptom-as-Cause (premature attribution) | 39.9% | 34.2% – 45.4% |
| Code generation error | 27.2% | 1.8% (Gemini) – 65.5% (Claude) |
| Limited Telemetry Coverage (one modality only) | 26.9% | 12.2% – 39.3% |
| Timestamp Error | 23.3% | 14.0% – 33.9% |
| No Cross-Validation | 18.6% | 11.9% – 35.4% |
| Instruction-Code Mismatch (step-level) | 18.8% | 0.5% – 25.5% |
| Meaningless Repetition (step-level) | 8.3% | 0% – 17.6% |
| Misattributed Evidence (step-level) | 3.4% | 0% – 6.4% |
| Out-of-Memory | 2 of 41 Bank scenarios | — |
| Max Step Exhaustion | 4.1% of executions | 0% (Solar) – 10.4% (GPT-5 mini) |

Source: [arXiv v2, Tables 2–3, §4](https://arxiv.org/html/2602.09937v2).

**The authors' headline claim.** The two dominant pitfalls stay above 66% and 53% for every model. Because the five models differ in provider and tier but share one framework, the authors conclude that "the shared framework [is] the primary bottleneck". The model-specific differences show up mainly in code generation and communication ([arXiv v2 §4.1](https://arxiv.org/html/2602.09937v2)).

**Mitigation 1: prompting.** Hypothesis-driven and pitfall-aware prompts were tested with Claude Sonnet 4 on 70 Bank tasks. Neither "produced a meaningful improvement in root cause identification".
- Hypothesis prompts *did* widen exploration.
- Hallucination in Interpretation "persisted at comparable rates": the agent reached the relevant data and still misread it.
- With pitfall-aware prompts, the agent acknowledged the pitfalls in its reasoning trace and then reproduced them.
- The authors conclude that hallucination is "a structural property of the generation process" and that fixing it needs "external verification modules".
- No numbers are reported for this experiment.

**Mitigation 2: richer Controller–Executor exchange.** The Executor returns its generated code and the full output, including stack traces, and the Controller passes its full analysis to the Executor.
- Step-level inter-agent pitfalls fell by **about 14 and 15 pp** for GPT-5 mini and Claude Sonnet 4.
- Bank perfect detections rose by 1–2 incidents out of 41 per model.
- Steps fell **22.1%** and wall time fell **22.3%**. Tokens per step rose 24.8%, but total tokens fell 1.6%.

**Mitigation 3: memory watcher.** It removed every out-of-memory failure ([arXiv v2 §5](https://arxiv.org/html/2602.09937v2)).

### Critical read: the "framework, not model" claim is under-identified

**Limitations the authors state.** Mitigations were tested only on Bank. Labelling was semi-automated. The taxonomy may not generalise to other frameworks ([arXiv v2 §6](https://arxiv.org/html/2602.09937v2)).

**Further problems in the method.**
- **The causal claim does not follow from the design.** The framework is held fixed and only the model varies. Uniformly high rates are equally consistent with task difficulty or label noise.
- **OpenRCA's labels are disputed.** A vendor blog shows OpenRCA cases whose labelled root cause cannot be recovered from the telemetry. In Bank 0, memory sits at about 98% "before, during, and after injection". In Bank 47, two components look nearly identical ([Traversal blog](https://www.traversal.com/blog/openrca-isnt-root-cause-analysis-why-that-matters)). Unrecoverable labels would inflate Hallucination in Interpretation and Symptom-as-Cause regardless of framework.
- **Step-level denominators are not disclosed.** Implied per-model denominators total roughly 2,150–2,200 step units, far below the ~18,600 steps actually executed *(notes' arithmetic)*. The step-level rates therefore cannot be compared with the run-level ones.
- **Figure 2 adds a category.** It includes a "Logical/Reasoning Error" series that is not in the taxonomy.
- **The "mutually exclusive" categories overlap**, and no κ is reported:
  - Hallucination in Interpretation vs Misattributed Evidence;
  - Incomplete Exploration vs Limited Telemetry Coverage;
  - Symptom-as-Cause vs No Cross-Validation.
- **The labeller is in the same family as one subject.** Opus 4.5 labelled Claude Sonnet 4, which had the highest hallucination rate.
- **The accuracy gains from Mitigation 2 are within noise.** Fisher exact tests on the before/after counts give p ≈ 0.49–1.0 *(notes' arithmetic)*.
- **Two pitfalls largely come from the agent's own design:**
  - Code-generation errors and the inter-agent pitfalls follow from free Python and a natural-language-only handoff.
  - Timestamp Error comes "mainly from timezone misalignment in the OpenRCA dataset".
- **No healthy incidents exist**, so false positives and abstention cannot be measured.

### Correlation with VERDICT: the paper asks for the module VERDICT already has

The paper reaches three conclusions, and VERDICT already acts on each of them:

| Paper's conclusion | VERDICT's existing answer |
|---|---|
| Interpretation must be checked against raw data | Typed predicates that the Orchestrator re-executes turn each "interpretation" into a boolean computed by code. The Generator never reads raw values. |
| Handoffs must carry code and raw output | Every verdict carries a provenance trail (predicate, raw result, data slice). |
| The environment must be managed outside the LLM | The Broker produces an immutable, bounded snapshot. |

**Largely removed in B and C.** Code-generation errors and Instruction-Code Mismatch disappear, because there is no free Python and every predicate is schema-validated (survey change 5). Both remain live in Architecture A if A writes free code.

**Removed by design.** Repetition and step exhaustion are bounded by the two-strike rule and the hard budget (survey change 8). Misattributed Evidence is handled by Orchestrator re-execution.

**Still exposed: breadth.**
- Incomplete Exploration and Limited Telemetry Coverage now live in two places: the Broker summary, if it omits a KPI family or interface, and the Falsifier's choice of predicates.
- The two-strike rule can end the search early.

**Still exposed: depth.**
- Symptom-as-Cause can survive the Falsifier. A symptom-level hypothesis such as "UE registration fails" has true predicates, so it is never refuted.
- No Cross-Validation is untouched. The two-strike rule is about refutation, not corroboration.

**Still exposed: narrative.**
- If an LLM writes the final explanation, fabrication re-enters there.
- The Broker summary can itself be lossy or mislabelled.

**Untested assumption.** The paper never tested whether *blinding* a reasoner reduces Hallucination in Interpretation. For VERDICT this is a hypothesis to pre-register: Architecture A (sees raw data) against B (blind), on a coded hallucination rate.

### Transfer to 5G O-RAN: reasoning pitfalls transfer, code errors do not

**Hallucination in Interpretation: confirmed in telecom.**
- CTBench agents reach evidence F1 of only **5.23–15.80%** even when their answers are right ([CTBench](https://arxiv.org/html/2608.12002)).
- FaulT-Bench agents probe "until a benign condition can be promoted to a root cause" ([FaulT-Bench](https://arxiv.org/html/2608.27021)).

**Incomplete Exploration and Limited Telemetry Coverage: confirmed, and arguably worse.**
- Metric-only ranking of F1-c delay reached only AC@1 0.20, because F1-c metrics are sparse ([UPC thesis](https://upcommons.upc.edu/bitstreams/99fb80d8-978c-477e-a66e-42adefbedfd5/download)).
- OCUDU documents only 24 of the 278 TS 28.552 metrics ([OCUDU KPM](https://docs.ocudu.org/knowledge_base/e2sm_kpm_metrics/)). PCAP and log evidence are therefore mandatory, not optional.
- Silence faults add a telecom twist. A wrong F1 address shows up only as the *absence* of F1 SETUP, so "incomplete exploration" includes never checking for expected-but-missing messages.

**Symptom-as-Cause: confirmed.**
- NIKA's dominant failure is a shallow cause ("link unstable") despite CRC and queue-drop evidence. GPT-5 localization is 58% on resource-contention faults ([NIKA](https://arxiv.org/html/2512.16381)).
- On FALCON++, packet loss makes DU metrics look like high demand ([FALCON++](https://newslab.iith.ac.in/media/publications/pdfs/FALCON___Open_AI_RAN_workshop_2025.pdf)).
- The propagation chain DU→CU→AMF puts UE-visible symptoms downstream of CU/DU or core causes.

**Code-generation error: contradicted wherever tools are typed.**
- NIKA's tool-call errors are only 0.7–1.6% ([NIKA](https://arxiv.org/html/2512.16381)).
- A typed transactional interface succeeded on 6 of 6 seeds, against 0 of 6 for a raw shell ([ANI-Gamut](https://arxiv.org/abs/2609.22723), abstract-level, pilot).
- The paper's 27.2% is therefore mostly a property of OpenRCA's free-Python Executor. It is confirmed only where code is free-form: LLMs violate O-RAN interface semantics when they generate code ([AutORAN](https://arxiv.org/abs/2603.18604)).

**Timestamp Error: plausible on OCUDU, but untested.** OCUDU components carry their own timestamps with no clock-alignment guidance ([Survey](file:///C:/Users/manue/reports/5G%20ORAN%20root%20cause%20analysis%20survey.md)). PCAP capture time, log wall-clock, TTI/SFN and KPI sample periods are four different time bases. No telecom paper measures this.

**Modes the paper's single-fault benchmark cannot see.**
- Over-diagnosis of healthy networks.
- Spec misrecall.
- Localization trailing identification.

The cross-synthesis below covers each.

### What it tells us: adopt the codebook, mechanise it, and run the factorial the paper skipped

**1. Adopt the binary codebook as R2's instrument.** Rewrite "KPI & Component" as interface, procedure and KPI family, and "telemetry source" as logs, F1AP/NGAP/E1AP PCAP, KPI and alarm. Add five telecom questions:
- Did the agent report a fault on a healthy snapshot?
- Did it ignore an expected-but-absent message?
- Did it cite a wrong spec clause or IE?
- Did it localize to the wrong network element while naming the right class?
- Did a refuted hypothesis reappear?

State run-level and step-level denominators explicitly.

**2. Mechanise every question VERDICT's logs can answer.**

| Pitfall | Deterministic metric from VERDICT logs |
|---|---|
| Code generation error | Predicate validity |
| Timestamp Error | Window misalignment against the gold window |
| Limited Telemetry Coverage | Modality coverage |
| Incomplete Exploration | Exploration coverage against a per-interface Broker checklist |
| No Cross-Validation | Corroboration count |
| Meaningless Repetition | Duplicate-predicate rate |
| Max Step Exhaustion | Budget exhaustion |

Only Hallucination in Interpretation and Symptom-as-Cause need semantic judgement. Even these can mostly be scored against a gold causal chain and executed predicate results.

**3. Run Architectures A, B and C with at least two model families.** Report a pitfall × architecture × model matrix. This is the framework-varying test the paper lacks.

**4. Add two controls.**
- An **A+prompts** control: A with hypothesis-driven and pitfall-aware prompts. This replicates §5.1 and pre-empts the objection "just prompt ReAct better".
- A **provenance-channel ablation**: replace typed predicate results with an LLM-written natural-language summary. This replicates §5.2 inside VERDICT.

**5. Template the user-facing explanation.** Render it from executed predicates, or require a predicate ID per sentence. Then treat any "verified" verdict under null evidence as a measured hallucinated interpretation.

---

## Paper #7: agentic loops add failures, not accuracy, for open models

### Citation and availability

| Field | Details |
|---|---|
| Title | "Stalled, Biased, and Confused: Uncovering Reasoning Failures in LLMs for Cloud-Based Root Cause Analysis" |
| Authors | Evelien Riddell, James Riddell, Gengyi Sun, Michał Antkiewicz, Krzysztof Czarnecki (University of Waterloo) |
| arXiv | 2601.22208v1 [cs.SE], 29 Jan 2026, CC BY 4.0 ([arXiv](https://arxiv.org/abs/2601.22208)) |
| Venue | FORGE '26, Rio de Janeiro, 12–13 Apr 2026; DOI 10.1145/3793655.3793732 |
| Award | ACM SIGSOFT Distinguished Paper ([UWaterloo news](https://uwaterloo.ca/computer-science/news/se-researchers-win-acm-sigsoft-distinguished-paper-award-forge-2026)) |
| Funding | General Motors of Canada |
| Code and data | Released under MIT at [github.com/boerste/rca-llm-reasoning](https://github.com/boerste/rca-llm-reasoning): inference and judge code, alert extractor, knowledge graphs (KGs), ground-truth labels, results, and a ZIP of the 3,073 judged traces with the GPT-5 batch inputs and outputs |
| Companion | E. Riddell's MMath thesis ([UWSpace](https://uwspace.uwaterloo.ca/handle/10012/22841)) |

This is the most reproducible paper in the set.

### Summary: 48,000 scenarios, HA@1 at most 0.31, and 16 reasoning failures that predict wrong answers

**Problem.** The authors deliberately strip away peripheral design choices to isolate LLM reasoning.

**Inputs and tools.**
- **Alerts:** pre-extracted from logs (Drain), traces (IsolationForest) and metrics (3-sigma).
- **Knowledge graph:** hand-built and typed.
- **Tools:** six deterministic KG tools. Every call must carry a "reasoning" argument.
- **Excluded:** no raw telemetry and no code execution.

**Workflows.** A single agent runs in one of three workflows: Straight-Shot (one pass with all alerts and the full KG), ReAct, or Plan-and-Execute. All run on LangGraph with a recursion limit of 50.

**Output.** A ranked top-3 list of hypotheses, each a tuple of location, fault type, propagation path and justification.

**Data.**
- **Dataset A (GAIA / MicroSS):** 152 balanced samples with 5 fault types. Minority classes were augmented with time-shifted duplicates.
- **Dataset B (OpenRCA Market):** 148 samples with 15 fault types and 60 entities.

**Models.** Llama 3.2 3B, Qwen 3 4B and 32B, Llama 3.3 70B, Command R+ 104B, and DeepSeek-R1-distill 70B. DeepSeek-R1 ran Straight-Shot only.

**Scale.** 48,000 scenarios over 228 GPU-days ([arXiv HTML](https://arxiv.org/html/2601.22208)).

**How the taxonomy was built.**
- The authors open-coded 30 traces.
- They refined the codes over 7 rounds of 20 traces, with an LLM judge and a human annotating in parallel (170 traces in total).
- A GPT-5 judge then labelled a stratified 3,073 of 19,200 traces, with a decomposed prompt, evidence quotes and a 1–5 severity score.
- Cohen's κ = 0.92 was reported on 30 traces ([arXiv HTML §3.3.2](https://arxiv.org/html/2601.22208)).

The 16 reasoning failures (RFs) fall into three groups:

| Group | Failures |
|---|---|
| **Procedural** | RF-09 failure to update belief; RF-10 simulation/role confusion; RF-11 excessive speculation; RF-12 repetition/failure to resume; RF-16 arithmetic |
| **RCA-specific** | RF-02 metric interpretation; RF-03 confused provenance (blaming the observer); RF-06 unjustified instance specificity; RF-07 arbitrary evidence selection |
| **General** | RF-01 fabricated evidence; RF-04 temporal misordering; RF-05 spurious causal attribution or nonexistent KG edge; RF-08 evidential insufficiency; RF-13 anchoring; RF-14 invalid inference; RF-15 internal contradiction |

**Prevalence.** These values are read from Fig. 4, so they are approximate (≈).
- RF-08 evidential insufficiency is flagged in **≈0.65–0.94** of traces for most model–workflow pairs.
- RF-05 spurious causation runs at ≈0.6–0.92, and RF-01 fabricated evidence at ≈0.25–0.6.
- **"Stalled" failures** are near zero in Straight-Shot but explode for small models under agentic control. Examples are Qwen 3 4B RF-11 at ≈0.94 under ReAct and Llama 3.2 RF-12 at ≈0.81 under Plan-and-Execute.
- **"Biased" anchoring** (RF-13) peaks at ≈0.55 for Command R+ under ReAct ([arXiv PDF Fig. 4](https://arxiv.org/pdf/2601.22208v1)).

Accuracy on Dataset A shows the core result: agentic workflows do not help.

| Model | HA@1 Straight-Shot | HA@1 ReAct | HA@1 Plan-and-Execute |
|---|---|---|---|
| Qwen 3 32B | **0.31** | 0.29 | 0.24 |
| Qwen 3 4B | 0.27 | 0.27 | 0.03 |
| Llama 3.3 70B | 0.25 | 0.27 | 0.23 |
| DeepSeek-R1 70B | 0.26 | — | — |
| Command R+ 104B | 0.21 | 0.19 | 0.14 |
| Llama 3.2 3B | 0.05 | 0.04 | 0.01 |
| Random guess | 0.02 | | |

HA@1 counts a hypothesis as correct only if both location and type are right. Source: [arXiv HTML Table 3](https://arxiv.org/html/2601.22208).

**Dataset B is far harder.** The best HA@1 is **0.035**, against a random baseline of 0.001.

**Agentic workflows bring three effects:**
- **Small models fall below random.** For example, Llama 3.2 LA@3 falls from 0.31 to 0.05 under Plan-and-Execute.
- **Path validity improves for capable models.** Llama 3.3 PA@3 rises from 0.61 to 0.78.
- **Execution failures are common for small models.** Under Plan-and-Execute they reach **87.3% for Qwen 3 4B and 77.3% for Llama 3.2.**

**Cost.** Agentic runs take 40% (ReAct) and 354% (Plan-and-Execute) more inference time.

**Modality holdouts point in opposite directions:**
- Withholding metrics hurts localization (ΔLA down to −0.155).
- Withholding logs hurts fault type (ΔTA down to −0.128).
- Withholding *traces* helps path validity (up to +0.28) and hypothesis accuracy (up to +0.07). Voluminous trace alerts were "drowning out important yet infrequent signals".

**Failures and correctness.** The association analysis reports the risk difference (RD) and risk ratio (RR) between traces with and without each failure.
- RF-13 anchoring, RF-12 stalling, RF-07 arbitrary selection and RF-09 failure to update each give **RD < −0.15 and RR < 0.55** on correctness.
- RF-10, RF-11 and RF-12 give **RR < 0.32** on path validity.
- Agentic traces carry more failures than Straight-Shot: 5.1 per trace for ReAct, 4.8 for Plan-and-Execute and 4.6 for Straight-Shot.
- Under Plan-and-Execute, replanning is associated with *persistent* stalling (ΔRR ≈ 0.38) ([arXiv HTML §4.4](https://arxiv.org/html/2601.22208)).

**No mitigation was tested.** The authors recommend hypothesis diversification, critique or self-consistency, and "evidence sufficiency checks, temporal ordering validators, and KG-consistency filters before ranking or selecting hypotheses".

### Critical read: the judge sees the answer, and "stalling" is partly the harness

**Limitations the authors state.**
- Every scenario has a single fault.
- The alerts are not gold-labelled.
- Results are sensitive to prompts.
- Coding involves subjectivity.
- The taxonomy rests on 170 traces.
- The study covers only open models and two benchmarks ([arXiv HTML §5](https://arxiv.org/html/2601.22208)).

**The RD/RR analysis is at risk of circularity.**
- The judge prompt includes the ground truth "as context only".
- The judge is asked which failures "affected the #1 hypothesis".
- Wrong traces may therefore attract more labels. The authors never ran the judge without the ground truth to check.

**κ = 0.92 is weakly specified.**
- It rests on only n = 30 traces.
- It is unclear whether agreement is between the two authors or between authors and judge.
- "(95% CI)" is stated with no interval.
- The statistic is probably pooled across 16 sparse labels, which inflates agreement.

**"Stalled" is partly the harness.** RF-10 and RF-11 co-occur with execution errors in 68.6% and 80.6% of Plan-and-Execute samples. The recursion cap of 50 turns some stalls into crashes.

**The forced top-3 output produces filler hypotheses.** The authors themselves explain the counterintuitive positive RD for RF-03 and RF-08 as an artifact of "the forced three-hypothesis task".

**Other problems:**
- **No frontier models.** The model set is 2024–25 open models, so the conclusion that agentic workflows do not help may not hold for frontier models.
- **No healthy cases**, so over-diagnosis cannot appear.
- **Effective sample size is unclear.** Dataset A's augmented duplicates reduce its effective sample size.
- **Possible overlap.** The 170 taxonomy-building traces may overlap the measured pool.

### Correlation with VERDICT: decision authority neutralises four failures, four remain

**What VERDICT neutralises at decision time:**
- **Fabricated evidence (RF-01):** a claim counts only if an Orchestrator-executed predicate returns a result.
- **Failure to update belief (RF-09):** the Orchestrator, not the LLM, decides refutation.
- **Simulation confusion (RF-10):** every predicate is re-executed, and LLM-reported outputs are ignored.
- **Temporal misordering (RF-04):** the predicate DSL has a temporal-precedence type (survey change 5).
- **Stalling (RF-11/12):** the two-strike rule and the budget bound it.

**What it does not remove.**

| RF | Residual risk in VERDICT | Mechanism to add |
|---|---|---|
| RF-13 anchoring | Generator emits near-duplicates, or echoes the front-end's top-1 | Schema constraint of ≥2 distinct (location, fault class) alternatives; prior-off ablation (survey change 7) |
| RF-07 arbitrary selection | Now lives in the Broker summary's triage order | Ablate summary ordering; log which summary items each hypothesis cites |
| RF-03 confused provenance | DU logs "F1 Setup Failure" when the CU config is wrong | Provenance predicate: which side sent the Failure message |
| RF-08 evidential insufficiency | Reappears on the Falsifier side as void refutation | Discriminability check: the predicate must give different outcomes under the hypothesis and at least one rival |
| RF-05 spurious edges | VERDICT has no topology KG | Typed OCUDU KG plus a propagation-path field, checked deterministically |
| RF-02 metric interpretation | KPI polarity in dB, BLER %, counters vs gauges | Broker attaches unit, counter/gauge type and "higher = worse"; predicates compare numerically |
| RF-14/15 invalid inference, contradiction | Final prose | Templated explanation; optional judge on explanations only (survey change 17) |

**The repair loop is a specific risk.** Architecture C resembles Plan-and-Execute replanning, which the paper associates with *persistent* stalling.

**The Generator will be weak on its own.** The blind Generator reads alert-level input, the very input on which this paper's best model reached only HA@1 0.31. VERDICT's value must therefore come from refutation and abstention, not from generation.

### Transfer to 5G O-RAN: the taxonomy transfers and becomes more checkable

**Each failure family has a telecom counterpart:**
- **Stalling:** CTBench's ClaudeCode + Qwen3.7-Plus used 81.36 rounds for 19.84% accuracy, against 10.81 rounds for the best agent ([CTBench](https://arxiv.org/html/2608.12002)). FaulT-Bench timeouts were 9% of runs but 23% of spend ([FaulT-Bench](https://arxiv.org/html/2608.27021)).
- **Anchoring and failure to update:** the best Correct Flip Rate on inherited flawed telecom reasoning is 29.1%, and scale does not reliably help ([TeleResilienceBench](https://arxiv.org/abs/2605.09929), abstract-level). This matches the paper's Qwen 3 4B ≈ 32B finding on Straight-Shot.
- **Localization lagging fault type:** Qwen 32B Straight-Shot reaches TA@1 0.42 against LA@1 0.36. NIKA's ladder runs 89.0 → 68.7 → 55.3 ([NIKA](https://arxiv.org/html/2512.16381)).

**Telecom makes three failures much easier to check deterministically.** Decoded F1AP, NGAP and E1AP events carry the sender, cause IEs and message order. That makes RF-03 provenance, RF-04 ordering and RF-05 edge validity cheap predicate checks.

**Telecom also makes two things harder:**
- KPI polarity (RF-02) is trickier than for cloud metrics.
- OCUDU's small topology (≈6–10 entities) raises random-guess localization to ≈0.1–0.17 *(notes' inference)*, so random baselines must be reported.

**The architectural conclusion is contested.** SADE's phase-gated policy gave +37 pp root-cause F1, 22 pp of it from the policy alone, with frontier models ([SADE](https://arxiv.org/abs/2605.04530), abstract-level). See the disagreement section below.

### What it tells us: guard the Orchestrator, add a Straight-Shot baseline, set a model-size floor

**1. Add a typed OCUDU topology KG with a mandatory propagation-path field.**
- Nodes: UE, DU, CU-CP, CU-UP, AMF, UPF.
- Edges: F1-C, F1-U, E1, NG-C, N3.
- Check every path's walk validity deterministically, which is the paper's PA metric.
- Use the list representation, which beat JSON for path validity in 3 of 6 models.

**2. Run the paper's mechanical checks online, as Orchestrator guards.**
- Every cited summary item must exist in the snapshot (RF-01).
- Temporal precedence must hold (RF-04).
- Every edge in a path must exist (RF-05).
- Near-identical resubmissions are blocked (RF-12).

**3. Require hypothesis diversity, and allow variable k.** Allowing fewer hypotheses, or "no further plausible candidate", avoids forced filler.

**4. Add a Straight-Shot LLM condition.** It is one pass over the same Broker summary and topology, with no Falsifier. VERDICT must beat it to claim the loop adds value.

**5. Set a model-size floor.**
- Avoid multi-round roles below about 8B, or report them as a separate stratum.
- This is consistent with the survey's 7–32B screen (survey change 14).
- Cap Architecture C's repair iterations and report its stall rate against B.

**6. Replicate the RD/RR analysis on VERDICT's deterministic process labels.** Use strike, void refutation, invalid predicate, stall and guard trip, with Wilson CIs. This reproduces the paper's RQ4 without the circularity of a judge that knows the answer.

---

## Paper #8: correct answers rest on partial causal maps

### Citation and availability

| Field | Details |
|---|---|
| Title | "Beyond Fault Localization: A Trajectory-Level Study of LLM Agents for Microservice Root Cause Analysis" |
| Authors | Qisheng Lu, Aoyang Fang, Junjielong Xu, Jin'ao Shang, Songhan Zhang, Yifan Yang, Xiaochuan Yan, Pinjia He. He and Fang are co-corresponding authors. |
| Affiliations | CUHK-Shenzhen; Xi'an Jiaotong University (Shang) |
| arXiv | 2608.21310v1 [cs.SE], 21 Aug 2026, 13 pages ([arXiv](https://arxiv.org/abs/2608.21310)) |
| Venue | None; preprint |
| Code and data | The annotated propagation paths, the pipeline, the failure codebook and the DiagGuard prompts are promised. No repository URL exists as of 8 Oct 2026. |
| Related work by the group | The same group built RCABench and OpenRCA. |
| Concurrent work cited | Papers #6 and #7 |

### Summary: 3,500 trajectories scored against a gold propagation graph

**Problem.** Acc@k and MRR give "no indication of the evidentiary basis for a diagnosis or the propagation route". The authors therefore treat RCA "as an observable diagnostic process" ([arXiv](https://arxiv.org/abs/2608.21310)).

**Arms and data.** There are 7 framework–model arms. Six frameworks run under Qwen 3.5-plus:
- ThinkDepth.ai;
- NVIDIA AIQ;
- TaskWeaver;
- ClaudeCode;
- OpenRCA;
- mABC.

The seventh arm runs ThinkDepth.ai under Claude Sonnet 4.6. All arms run on 500 RCABench TrainTicket cases, giving 3,500 trajectories.

**Gold propagation graph G\*.**
- Built per case from injection metadata, telemetry and the static call graph.
- One author annotated all cases. A second author double-annotated 100 cases, with 93% agreement.

**Outcome metrics (deterministic).**
- Acc@1.
- **Node F1** and **Edge F1**, computed between the agent's self-reported propagation graph and G\*.
- Accuracy stratified by causal depth d\*.
- Rounds, tokens and dollars, each split by whether the run was correct or incorrect.

**Behaviour metrics.**
- **Primary service:** each round is reduced to one primary service.
- **Navigation:** consecutive rounds get one of **10 navigation transitions** in five families:
  - Advance: Step, Dive;
  - Regress: Ascend, Backtrack;
  - Lateral: Branch, Reprobe;
  - Return: Rejoin, Retrace;
  - Off-path: Stray, Wander.
- **Evidence use:** each round gets one of **4 evidence-utilization labels**: utilized, partial, ignored or no_data.
- **Intents:** an LLM classifier assigned 11 SRE intents to 92,501 SQL actions. A human check of 1,000 labels gave 99% agreement, κ = 0.83.
- **Tags:** six tag axes are derived deterministically from the SQL text.

**Failure coding.** A 12-code codebook was applied to all 154 failed ThinkDepth.ai runs. Two coders produced identical code sets on 93.5% of them ([arXiv PDF](https://arxiv.org/pdf/2608.21310)).

| Arm | Acc@1 % | Node F1 (correct runs) | Edge F1 (correct) | Edge F1 (incorrect) | Rounds correct / incorrect | Acc@1 at d\* = 2 / 5 |
|---|---|---|---|---|---|---|
| Qwen mABC | 42.6 | 0.49 | 0.15 | 0.05 | – | 53.3 / 42.9 |
| Qwen OpenRCA | 46.6 | 0.57 | 0.36 | 0.16 | 6.1 / 6.7 | 58.6 / 19.0 |
| Qwen TaskWeaver | 65.2 | 0.78 | 0.58 | 0.26 | 13.2 / 14.5 | 79.6 / 33.3 |
| Qwen AIQ | 77.6 | 0.81 | 0.61 | 0.35 | 50.0 / 55.1 | 86.8 / 42.9 |
| Qwen ClaudeCode | 79.6 | 0.81 | 0.65 | 0.28 | 51.3 / 62.7 | 89.5 / 57.1 |
| Qwen ThinkDepth.ai | 79.2 | 0.83 | 0.66 | 0.33 | 43.1 / 50.7 | 85.5 / 57.1 |
| Sonnet ThinkDepth.ai | **90.0** | 0.82 | **0.67** | 0.37 | 30.5 / 38.2 | 88.2 / 85.7 |

Source: [arXiv PDF Table II](https://arxiv.org/pdf/2608.21310).

**Four outcome findings stand out:**
- **Correct runs still miss much of the causal map.** Edge F1 on correct runs never exceeds 0.67. Swapping the model raised Acc@1 by 10.8 pp but left Node and Edge F1 "nearly untouched".
- **Failed runs find the anomalous services but cannot chain them.** From correct to incorrect runs, Node F1 drops 16–32% while Edge F1 drops 43–67%.
- **Failed runs spend more rounds**, up to 11.4 more, with no partial credit for the extra effort.
- **Depth separates the models.** Every Qwen framework degrades from d\* = 2 to d\* = 5, while Sonnet holds flat.

**Behaviour findings.**
- Correct runs stay on the fault-impact surface and lean on Reprobe. Incorrect runs Stray, Wander and Retrace.
- Sonnet acts on the previous round's result in **54.3%** of rounds, against **24.9%** for Qwen.
- Sonnet uses resource_probe in 82.8% of trajectories, against 16.6% for Qwen.
- Qwen shows a trace-following 5-gram loop 0.96 times per trajectory, against ≤0.12 for Sonnet ([arXiv PDF §V-B](https://arxiv.org/pdf/2608.21310)).

The failure codebook below shares are per failure pool (50 Sonnet failures, 104 Qwen failures). Codes overlap, so shares do not sum to 100%.

| Code | Meaning | Sonnet | Qwen |
|---|---|---|---|
| OMIT1 Baseline gap | No normal-window comparison, so chronic signal is taken as evidence | 26.0% | 51.9% |
| OMIT2 Edge untested | No caller–callee test | 54.0% | 68.3% |
| OMIT3 Resource gap | No named resource or lifecycle probe | 34.0% | 63.5% |
| OMIT4 Ranking gap | No peer ranking | 2.0% | 25.0% |
| OMIT5 Granularity gap | No pod, endpoint or metric drill-down | 18.0% | 16.3% |
| OMIT6 Timing gap | No timing check | 4.0% | 8.7% |
| MIS1 Silence-as-health | Missing data read as healthy | 30.0% | 44.2% |
| MIS2 Salience bias | Loudest signal trusted | 42.0% | 32.7% |
| MIS3 Semantics misread | Caller-side fault blamed on callee | **86.0%** | 61.5% |
| GEN1 Anchor lock | Early anchor kept despite conflict | 28.0% | 34.6% |
| GEN2 Schema-out claim | Out-of-schema cause fabricated | **82.0%** | 20.2% |
| GEN3 Friction stop | Evidence channel dropped after tool friction | 0% | 12.5% |

Source: [arXiv PDF Table III](https://arxiv.org/pdf/2608.21310).

**Qwen and Sonnet fail differently.** Qwen fails "predominantly by omission". Sonnet fails by misreading and fabrication. Its "strong associative reach sometimes errs through hallucination".

**DiagGuard, the authors' mitigation**, wraps ThinkDepth.ai in two defences derived from the failure taxonomy:
- **Grounder:** confronts the agent with the telemetry that exists.
- **Verifier:** runs a self-audit and a soundness check before commitment.

Both were frozen before the validation runs. Validation used a held-out model (Seed 2.0 Pro), dataset (AIOps 2025) and topology, with five runs each.

| Configuration | Acc@1 % | Δ | pass@5 | Rounds | ktok | $ |
|---|---|---|---|---|---|---|
| Baseline | 43.5 ± 0.6 | — | 62.3 | 14.1 | 176.8 | 0.09 |
| Verifier only | 47.6 ± 1.6 | +4.1 | 65.8 | 19.2 | 343.8 | 0.17 |
| Grounder only | 48.0 ± 0.9 | +4.5 | 67.3 | 16.3 | 212.1 | 0.10 |
| DiagGuard | **52.5 ± 1.1** | **+9.0** | 73.0 | 18.7 | 318.5 | 0.16 |

Source: [arXiv PDF Table V](https://arxiv.org/pdf/2608.21310).

**The gains are near-additive and appear on every fault type.** They range from +1.0 (DNS) to +20.8 (I/O). The largest jumps came on faults that "raise no SLO": I/O rose from 2.1 to 22.9 and Node from 4.1 to 19.5.

### Critical read: Edge F1 scores the narrative, and correct runs are never coded

**Limitations the authors state.**
- Results come from a single topology.
- Each characterisation configuration ran once, with no significance tests.
- Annotation and judge subjectivity remain.
- Implementation differences between frameworks may confound comparisons ([arXiv PDF §VII](https://arxiv.org/pdf/2608.21310)).

**Edge F1 measures the story, not the evidence.** The agent's graph G comes from a compression prompt whose edges "need not be query-verified". An agent could score well by reciting the call graph.

**"Right for wrong reasons" is never quantified.** Only the 154 failed runs are coded, not the 846 correct ones. "Correct-then-abandoned" appears only as a schematic in Fig. 1.

**Small samples and noise:**
- Every d\* = 5 accuracy is a multiple of 1/21, which suggests about 21 cases in that stratum *(notes' inference)*.
- The top three frameworks span only 2.0 pp, within single-run noise.
- The Sonnet codebook shares rest on 50 failures. OMIT4's 2.0% is a single trajectory.

**Other problems:**
- **Thin backbone evidence.** The claim that the model is the dominant lever rests on a single framework pair.
- **Unmeasured process.** DiagGuard is validated on outcomes only. No trajectory metrics are re-measured, and the held-out set has no G\*.
- **Possible compute effect.** Some of DiagGuard's gain may come from extra test-time compute rather than from what the taxonomy taught.
- **Home-field risk.** The authors' group also built RCABench and OpenRCA.

### Correlation with VERDICT: the Broker makes every label deterministic

This paper had to reconstruct three things that VERDICT produces natively:
- an immutable fault window (the Broker snapshot);
- a single query surface (the Broker API);
- typed intents (the predicate types).

The paper could compare only frameworks that used the shared SQL interface. It had to drop 2 of 6 frameworks for exposing "no comparable traces".

**What this means for logging.** A Broker log record carrying scope entities and result entities is enough to compute every navigation, utilization and intent label without an LLM classifier.

**The failure codes map onto VERDICT mechanisms:**
- **Typed hypothesis schema.** VERDICT's closed schema and an Orchestrator that rejects unverifiable causes target **GEN2 schema-out claims** (82% of Sonnet failures) directly.
- **Falsifier sees claims only.** Together with the two-strike rule, this targets **GEN1 anchor lock**.
- **Schema validation and error logging** target **GEN3 friction stop**.
- **Absence predicates** (survey change 6) target **MIS1 silence-as-health**.
- **Deterministic IE decoding** of sender, receiver and cause targets **MIS3 semantics misread**.

**Still exposed:**
- **OMIT1 baseline gap.** VERDICT has no mandatory baseline-window contrast.
- **OMIT2 untested edges.** No rule requires a predicate per claimed causal edge.
- **OMIT4 ranking gap.** There is no peer-rank predicate.
- **MIS2 salience bias.** The blind Generator sees only the KPI/alarm summary, which is exactly where the loudest signal wins.

**The paper's Finding 1 directly challenges VERDICT.** "Adaptive, minimally constrained frameworks outperform more tightly orchestrated designs". Architecture A is the configuration this paper predicts to be strong. The losing designs were a fixed-plan executor, an early committer and a non-iterating consensus, not a refutation loop.

### Transfer to 5G O-RAN: "outcome hides process" is confirmed, the architecture finding is contested

**Telecom evidence confirms "outcome hides process":**
- CTBench evidence F1 is 5.23–15.80% even for the best agent at 47.62% accuracy ([CTBench](https://arxiv.org/html/2608.12002)).
- NIKA's ladder runs detection 89.0% → localization 68.7% → RCA 55.3%, mirroring the paper's Node F1 > Edge F1 gap ([NIKA](https://arxiv.org/html/2512.16381)).
- NIKA's shallow "link unstable" failures parallel OMIT3, MIS2 and the trace5 loops.
- Inspection share predicts success (r_s = +0.78), mirroring the utilized-share result ([Safety Signals](https://arxiv.org/html/2609.14422v2)).
- In CTBench and FaulT-Bench, more rounds do not mean better answers, matching the paper's Finding 3.

**MIS1 is the telecom silence fault.** The wrong-F1-address fault leaves only an absent F1 SETUP. DiagGuard's largest gains came on "no SLO raised" faults, the cloud analogue.

**OCUDU chains are short.** Typical chains run core NF → NGAP → CU-CP → UE, so d\* will mostly be 1–3. "Interfaces crossed" is a better difficulty proxy than service hops *(notes' inference, to validate)*.

**Two codes to add for telecom:**
- **Cause-code misread**, a special case of MIS3.
- **Procedure-order misread**, a special case of OMIT6.

**The one real tension is architectural.** It is resolved in the disagreement section below.

### What it tells us: adopt the three-level protocol, then fix its weaknesses

**1. Adopt the three-level structure almost wholesale.** The levels are outcome, then behaviour and intent, then failure codes. Make it deterministic:
- Every architecture touches telemetry only through the Broker API.
- G\* is written at injection time.
- Intents are read from predicate types.

**2. Fix what the paper could not measure:**
- **Verified Edge F1:** only edges backed by a re-executed predicate count.
- **First-hit:** when the true cause first appears.
- **Correct-then-abandoned,** which in B and C is precisely fratricide.
- **Failure coding of a sample of correct runs.**
- **Exact label shares in tables, not bars.**
- **Process re-measured after every intervention,** with a count of cases the intervention broke.

**3. Replicate DiagGuard's ablation inside VERDICT.** Compare grounding only, Falsifier only, and both.

**4. Add an "A + taxonomy checklist" baseline.** This separates the value of the checklist content from the value of external, executable verification. That VERDICT beats DiagGuard-style self-audit is a hypothesis, not a finding.

**5. Prefer externalised predicates to in-loop self-audit.** DiagGuard's Verifier-only arm was the costliest at 343.8 ktok and gained least. That favours cheap re-executed predicates over the same agent auditing itself.

---

## Paper #9: "real-world" means a curated, solvability-filtered injection benchmark

### Citation and availability

| Field | Details |
|---|---|
| Title | "How Far Can Root Cause Analysis Go on Real-World Telemetry Data?" |
| Authors | Athira Gopal and Ashwanth Krishnan (QPIAI India) |
| arXiv | 2607.13548v1 [cs.AI], 15 Jul 2026 ([arXiv](https://arxiv.org/abs/2607.13548)) |
| Venue | None found |
| Code and data | No code. Uses the public OpenRCA benchmark (ICLR 2025, CC BY-NC 4.0) ([OpenRCA paper](https://proceedings.iclr.cc/paper_files/paper/2025/file/d29b8d53678015079e1d245c023e49d2-Paper-Conference.pdf)). |
| Models | GPT-5.2 for all main results |

This is the weakest paper in the set methodologically. Use it for its ideas and its warnings, not its numbers.

### Summary: 25.7–56.9% full accuracy with domain rules, and errors blamed on reasoning gaps

**Task.** Given the correct 30-minute window, output one or two (component, reason, timestamp) triples. The number of causes is supplied to the system.

**Data.** The OpenRCA data is AIOps Challenge telemetry from deployed systems with injected faults. The paper describes it as "30-minute query windows around fault injection events".

**How OpenRCA was built.** OpenRCA cut 1,753 raw records to 335. Three engineers removed any case whose root cause "could not be identified from telemetry", whose telemetry was missing, or whose inferred cause did not match the label ([OpenRCA paper](https://proceedings.iclr.cc/paper_files/paper/2025/file/d29b8d53678015079e1d245c023e49d2-Paper-Conference.pdf)).

**The OpenRCA "Telecom" domain is not a RAN.** It is "a telecom database system": VMs, pods, database and Redis services, with no logs.

**Systems compared.**
- Five classical causal-discovery methods.
- Three LLM baselines (OpenRCA agent, GALA, RCLAgent).
- The authors' "Structured Multi-Agent RCA" pipeline. An LLM assigns each KPI a detector, anomalous rows are extracted by script, and one LLM call runs Enumerate → Cluster → Analyze → Select → Reflect, followed by a vocabulary-enforcing agent. It runs with or without hand-built domain-knowledge (DK) rules ([arXiv PDF](https://arxiv.org/pdf/2607.13548)).

Results are given as Full / Partial accuracy (%) with GPT-5.2.

| System | Market CB1 | Market CB2 | Bank | Telecom |
|---|---|---|---|---|
| OpenRCA agent | 11.43 / 28.69 | 16.67 / 28.42 | 27.90 / 36.64 | 29.41 / 38.22 |
| DK ON | **25.71** / 45.60 | 24.36 / 45.63 | **36.76** / 49.79 | **56.86** / 60.54 |
| DK OFF | 17.14 / 35.59 | 14.10 / 28.21 | 27.94 / 37.62 | 35.29 / 44.12 |
| Mined DK (CB1 → held-out CB2) | – | **35.90** / 55.03 | – | – |

Source: [arXiv PDF Table III](https://arxiv.org/pdf/2607.13548).

**Baselines.**
- Every classical method (Granger, PC, FCI, LiNGAM, NTLR) scores **0 at both Acc@1 and Acc@10**.
- GALA scores 2.56 and RCLAgent 0.
- A single plain LLM call scores 12 Full on CB1.

**Domain knowledge is the dominant controllable factor.** DK ON beats DK OFF by +8.6 to +21.6 points *(notes' subtraction)*.

**Part of that gain is leakage.** On held-out windows that excluded the DK-construction cases, DK ON fell 5.3 points on Telecom (56.86 → 51.61) and 2.2 on CB1. It rose 1.4 on Bank.

**Error attribution.** A "reverse reasoning" agent is given the true answer and reconstructs the evidence path. It labels each dimension as:
- **Type 1, Reasoning Gap:** the signal was present.
- **Type 2, Data Ambiguity:** the signal was absent from all telemetry.

| Dimension (CB1 DK OFF, n = 70) | Correct | Reasoning Gap | Data Ambiguity |
|---|---|---|---|
| Component | 33 (47.1%) | 36 (51.4%) | 1 (1.4%) |
| Reason | 16 (22.9%) | 46 (65.7%) | 8 (11.4%) |
| Timestamp | 31 (44.3%) | 38 (54.3%) | 1 (1.4%) |
| Overall | 14 (20.0%) | 28 (40.0%) | 1 (1.4%) |

27 further cases (38.6%) are "Mixed". Source: [arXiv PDF Table VII](https://arxiv.org/pdf/2607.13548).

**The OpenRCA agent fails like the agents in Paper #6.** It "often fails to examine all available files and tends to prematurely select the first detected anomaly as the root cause".

### Critical read: hindsight attribution on a benchmark filtered for solvability

**Limitations the authors state.**
- Anomaly-threshold errors propagate through the pipeline.
- The pipeline is costly in money and latency.
- DK ON is "developed-on-test and may be optimistic".
- Mined rules are "not verified to discriminate a fault from its neighbors" ([arXiv PDF](https://arxiv.org/pdf/2607.13548)).

**The title overclaims.** The paper never compares injected faults with organic incidents. It cites only Pham et al. (ASE 2024), which warns that "results on synthetic benchmarks can be misleading".

**The data-ambiguity floor is low by construction.** OpenRCA removed every case whose cause could not be found from the telemetry. A low ambiguity rate measured on the survivors is therefore not evidence that real incidents are unambiguous.

**The attribution method is confirmation-biased.** The reverse agent knows the answer and searches about 2 GB of data per window for support. No human audit or discrimination check is applied.

**The paper contradicts itself in three places:**
- "Evidence present in all examined cases" conflicts with the 8 Type 2 cases on the reason dimension.
- The method is described as running on incorrect predictions, yet the n = 70 includes 14 correct ones.
- The Stage 1 correct count (20.0%) exceeds the final DK OFF Full score (17.14%).

**Several values do not match the implied denominators** *(notes' arithmetic)*:
- OpenRCA-agent Bank 27.90 is not k/136.
- GALA's 2.56 equals 2/78, not k/70.

**Oracle hints remove real-world difficulties.** The correct window, the number of causes and the full cause vocabulary are all given.

**The classical baselines are crippled.** They ran on 30 samples against 640+ columns with no healthy baselines. Methods that need baselines were excluded outright.

**Some claims have no experiment behind them.** "Bounded even when evidence extraction is perfect" has no perfect-extraction experiment. The Gemma table is all zeros yet is said to match the GPT-5.2 ordering.

**The external critique of OpenRCA comes from a vendor.** It is the same Traversal blog quoted under Paper #6 ([Traversal blog](https://traversal.com/blog/openrca-isnt-root-cause-analysis-why-that-matters)). Traversal staff are also co-authors of ORCA-bench (Paper #10).

### Correlation with VERDICT: the paper's future work is VERDICT's Falsifier

The paper's proposed next step is to pair "LLM proposal with a symbolic firing-checker that tests each candidate against all windows" ([arXiv PDF](https://arxiv.org/pdf/2607.13548)). That is essentially VERDICT's Falsifier with Orchestrator-executed predicates. The paper's own Reflect step is self-verification within the same LLM call, the weaker form.

**VERDICT's "unresolved" output has no counterpart.** The paper's pipeline guarantees "the prediction count is never reduced below one", so abstention cannot be studied.

**The paper exposes seven threats to the validity of VERDICT's own corpus:**
1. **Solvability selection.** Do not drop injections that leave no clean signature.
2. **Oracle hints.** Record which hints the harness gives: window, cause count, vocabulary.
3. **Developed-on-test knowledge.** Do not tune the predicate library or prompts while looking at test incidents.
4. **Instance-only generalisation.** CB1→CB2 holds topology and vocabulary fixed, so it tests new instances, not new fault types.
5. **Concurrency and window carry-over.**
6. **Redundancy masking and missing modalities.**
7. **Hindsight failure attribution.**

**The paper shows what a strawman Condition 0 looks like.** A fair one uses thresholds against healthy baselines, cause-code rules over F1AP/NGAP/E1AP, and the paper's earliest-onset Select rule implemented as code. This fits survey change 7.

**Under Cascade the stakes rise.** Condition 0 becomes Tier 0, so its fairness is now a design requirement as well as a baseline requirement. The paper's leakage result (DK ON −5.3 on held-out Telecom windows) is the cloud precedent for Cascade's own "Tier-0 overfitting" caveat: the team writes both the rules and the injected faults.

### Transfer to 5G O-RAN: methods transfer, numbers do not

**Nothing in this paper is RAN evidence.** OpenRCA "Telecom" is IT infrastructure.

**The patterns rhyme with telecom results:**
- **Partial credit far exceeds full credit.** DK ON CB1 scores 45.60 Partial against 25.71 Full. This mirrors localization trailing identification in CTBench and NIKA.
- **Classical methods collapse on sparse data.** The paper's 30-point windows parallel HYDRA, where RF/SVM fell from 92% / 90.2% to 71.3% / 69% at 100 MDT reports per cell ([HYDRA](https://par.nsf.gov/servlets/purl/10406952)).
- **Top-1 on realistic data stays well below clean benchmarks.** CTBench's best agent reaches 47.6% on real equipment ([CTBench](https://arxiv.org/html/2608.12002)). Real carrier alarms give 61.8% top-1 against 96.1% top-5 ([Zhang et al.](https://arxiv.org/abs/2105.03092)).

**The ceilings are not comparable.** The three studies use different units: a (component, reason, timestamp) triple, a root alarm, and a task.

**Two differences favour the telecom setting:**
- **Domain knowledge can be leakage-free.** 3GPP cause codes and procedures are public, so a DK ON condition need not be mined from test windows.
- **Protocol evidence may be more explicit.** Control-plane faults may leave more explicit evidence (cause IEs, missing messages) than cloud metric anomalies *(notes' inference)*.

**One difference cuts the other way.** Our corpus is *further* from "real" than OpenRCA: injected faults on a software stack with ZMQ-emulated radio. Claims should be restricted to protocol and control-plane families, which is the survey's own mitigation.

### What it tells us: build ambiguity in, and label recoverability deterministically

**1. Keep every injection, and label recoverability deterministically.** Run pre-registered gold-signature predicates for each fault family over the snapshot.
- If none fires, the incident is "Data Ambiguity by construction", and the correct answer is "unresolved".
- This replaces the paper's hindsight LLM attribution with a check that only a controlled corpus allows.
- It yields an **evidence-present-but-unused rate**, our deterministic version of the Reasoning Gap.

**2. Add strata that remove the oracle hints:**
- a partial-evidence condition, dropping one modality at a time;
- compound, sequential and boundary-straddling faults, with the cause count withheld in at least one stratum;
- held-out fault-family and held-out configuration splits.

Freeze libraries and prompts on the dev split, and report dev-versus-held-out deltas as the paper's Table VI does.

**3. Add two cheap baselines:**
- a single-LLM-call-over-anomaly-tables condition;
- a DK ON/OFF ablation using public 3GPP knowledge.

**4. Report per-field accuracy** for component, cause and onset.

**5. Word the claims carefully.** Present results as "controlled, lab-injected, emulated-radio", never as "real-world".

---

## Paper #10: ORCA-bench, frontier agents are not ready for on-call

### Citation and availability

| Field | Details |
|---|---|
| Title | "ORCA-bench: How Ready Are Language Model Agents for Oncall?" |
| Authors | Albert Gong and Kyuseong Choi (Cornell Tech); Abhineet Agarwal, Jason Schechner, Ryan Huang, Raj Agrawal (Traversal); Anish Agarwal (Traversal and Columbia); Raaz Dwivedi (Cornell Tech and Traversal; corresponding) |
| arXiv | 2607.28545 [cs.CL, cs.AI, cs.SE]; v1 30 Jul 2026, v2 5 Aug 2026, v3 29 Sep 2026; CC BY 4.0 ([arXiv v3](https://arxiv.org/html/2607.28545v3)) |
| Venue | None listed |
| Code | Apache-2.0 at [github.com/ORCA-bench/ORCA-bench](https://github.com/ORCA-bench/ORCA-bench) |
| Data | 755 of 1,079 tasks are public on the Harbor hub. 324 are held out privately to monitor contamination. |
| Conflict of interest | Five of eight authors work at Traversal, an AI-SRE vendor whose own product is not evaluated |

### Summary: 1,079 tasks, best 25.3% on Medium and 10.0% on Hard, false alarms on healthy periods

**Environment.**
- **System:** the OpenTelemetry Astronomy Shop, with 19 microservices in 13 languages.
- **Telemetry:** six days of recorded data (over 50 GB), exposed only through the Grafana API.
- **Source code:** readable by the agent.

**Fault injection.** 11 feature flags were toggled 42 times across 13 scenarios, with up to 6 flags active at once.

**Task design.** There are **1,079 tasks**: 884 incident tasks and **195 no-incident controls**. Four axes vary:
- **Report specificity:**
  - Easy: the specific symptom or error;
  - Medium: the affected component;
  - Hard: always "users are reporting site issues".
- **Time-to-detection:** 15 minutes to 24 hours.
- **Report-time style.**
- **Scenario type:** isolated, independent, conflicting, cascading or sequential.

**Instructions.** The agent is told "There may be multiple root causes or no root cause at all". It must write an empty report if nothing happened, and otherwise a Summary / Timeline / 5 Whys / Remediation report. Only the diagnosis is scored.

**Ground truth.** The answer is the *set* of plausible flags, labelled by GPT-5.4. The set averages 2.00, 2.84 and 4.41 causes for Easy, Medium and Hard.

**Metrics.**
- **Accuracy** = 1[ground-truth set ⊆ predicted set].
- **Depth:** a 0–3 rubric per cause, scored 0 = missed, 1 = restates the symptom, 2 = correct progress, 3 = cause, mechanism and signals.
- **Hallucination** = a non-empty prediction that contains no true cause.

**Judge validation.** The GPT-5.4 judge matches the mean of two human re-scorers at κw = 0.91 on 191 scores. The two humans agree with each other at κw = 0.83 ([arXiv v3](https://arxiv.org/html/2607.28545v3)).

Results on the 884 incident tasks (code and telemetry available):

| Model | Depth % | Accuracy % | Halluc. % | Easy / Medium / Hard accuracy % |
|---|---|---|---|---|
| Claude Opus 4.7 | 48.5 | 28.6 | 12.6 | 51.0 / 24.7 / **10.0** |
| Claude Sonnet 4.6 | 46.7 | **30.9** | 14.8 | **58.7** / **25.3** / 8.6 |
| GPT-5.5 | **48.8** | 24.3 | 25.0 | 38.9 / 25.0 / 8.6 |
| DeepSeek-V4-Pro | 19.7 | 15.0 | 7.2 | 24.7 / 14.9 / 5.4 |
| GLM-5 | 27.7 | 17.6 | 40.2 | 34.7 / 16.8 / 1.1 |

Source: [arXiv v3 Tables J.1, J.4](https://arxiv.org/html/2607.28545v3).

**Healthy-period controls.** Scores range from 84.1 (Opus) to 44.6 (GLM-5). If the score is the pass rate, false alarms run from about **16% to 55%** *(notes' arithmetic)*. One caveat: the table labels that column "RCA Depth", while the text defines control success as finding no incident.

**Vaguer reports cut accuracy by 19–50 pp.** Holding the number of causes fixed, accuracy still falls.

**Removing source code hurts badly.** Accuracy drops 9–16 pp and hallucination roughly doubles. GPT-5.5 goes from 25.0% to 56.0%, and GLM-5 from 40.2% to 73.1%.

**Wasted queries.** 26–40% of telemetry calls return nothing or error.

**Multi-fault scenarios are hardest.** Independent co-occurring faults score **6.2% depth** and 3.1% accuracy. On the six-fault peak day, three models each found exactly one cause.

**The harness barely matters.** Opus scored 25.0% under both Terminus-2 and OpenSRE.

**Proving "no fault" costs more.** Opus spends more tokens on control tasks (2.60M) than on incidents (1.67M).

**Qualitative failures.** Agents "lock onto louder symptoms". One case study shows GLM-5 chasing more than 94,000 irrelevant load-generator browser errors.

**There is no human baseline and no time or cost metric.** The verdict: "today's agents are not ready for oncall".

### Critical read: self-labelling faults, a gameable accuracy metric, and vendor framing

**Limitations the authors state.**
- It is a curated 50 GB, six-day testbed whose code is public.
- Real systems are "orders of magnitude larger".
- The axis comparisons describe variation and do not isolate causes ([arXiv v3](https://arxiv.org/html/2607.28545v3)).

**The faults announce themselves.** Feature flags are visible in flagd metrics, span attributes and span events such as "Error: Product Catalog Fail Feature Flag Enabled". That agents still score 10–25% with these markers strengthens the failure finding. But the benchmark does not test faults without markers, which is the normal case for RAN configuration faults.

**The accuracy metric can be gamed.** Accuracy rewards any superset of the true causes, and hallucination fires only when *no* named cause is correct. Listing every active flag maximises both.

**Hard-tier ground truth is enumeration.** It counts every flag with a frontend symptom that day.

**Models build and judge the benchmark.**
- The model families used to build and judge it are also evaluated: GPT-5.4 labels plausibility and judges, Opus 4.7 curates symptoms, and GPT-5.5 and Opus 4.7 are tested.
- Humans verified only 40 tasks.

**Statistical problems:**
- Each task ran once at temperature 1.
- The 1,079 tasks derive from 42 flag occurrences, so they are not independent.
- On the 32-task Verified subset, standard errors are about 7–9 pp.

**The leaderboard scores differently from the paper.** The paper scores empty reports as 0, but the README excludes no-verdict trials.

### Correlation with VERDICT: a ready evaluation design, minus the time metrics Cyshield needs

**The paper's main failures are VERDICT's design targets:**
- loud-symptom fixation;
- hallucinated causes;
- false alarms on healthy periods;
- empty or failed queries;
- single-cause lock-in.

**Four protocol pieces port directly:**
- **The specificity ladder** controls how much the Generator's alarm summary reveals:
  - Easy: a specific F1 Setup Failure cause;
  - Medium: "UEs on cell 1 cannot attach";
  - Hard: "users report no service".
- **The healthy-control share.** Controls are 18% of tasks.
- **The 0–3 depth rubric** can be scored deterministically:
  - 1 = the Generator restates the alarm;
  - 2 = an executed predicate hits a gold symptom;
  - 3 = the verified cause, mechanism and predicates all match gold.
- **The success/empty/error classification of telemetry calls** is the outcome classification VERDICT's void-refutation metric needs.

**Two findings name VERDICT trade-offs:**
- **Hallucination trades against empty output.** DeepSeek has the lowest hallucination (7.2%) because it often writes nothing. VERDICT's "unresolved" rate must sit next to its accuracy.
- **Proving "no fault" is expensive.** VERDICT's healthy and null-evidence runs should be budgeted as the costliest cases.

**VERDICT is exposed on multi-fault scenarios.** A single verified cause cannot score on independent co-occurring faults.

**ORCA's main gap is Cyshield's requirement.** It never measures time or effort. Cyshield's stated outcome, "reduced investigation effort and faster fault isolation", needs exactly these metrics:
- time-to-isolate;
- predicate count;
- tokens and dollars;
- artifacts an engineer must open to confirm the verdict.

### Transfer to 5G O-RAN: the design axes transfer, the self-labelling faults do not

**ORCA agrees with the telecom evidence on four points:**
- **Vagueness destroys performance.** ORCA loses 19–50 pp from Easy to Hard. In FaulT-Bench, over-diagnosis reaches 47% for no-detail tickets ([FaulT-Bench](https://arxiv.org/html/2608.27021)).
- **Healthy systems get false alarms.** ORCA's are about 16–55%; FaulT-Bench's are 11–24%.
- **Multi-fault scenarios are hard.**
- **Absolute accuracy is low.** CTBench's best agent reaches 47.6% ([CTBench](https://arxiv.org/html/2608.12002)) and NIKA 55.3% ([NIKA](https://arxiv.org/html/2512.16381)).

**The telemetry stack maps directly onto OCUDU:**
- metrics → KPIs and counters;
- logs → CU-CP, CU-UP, DU, srsUE and core logs;
- traces → F1AP, NGAP and E1AP procedure chains;
- source code → OCUDU and srsRAN source.

**ORCA's signal layers transfer too.** Root-cause, propagation and symptom signals map to, for example, an NG Setup Failure cause, then no F1 cell activation, then a UE attach-failure KPI.

**Three things differ in 5G:**
- **OCUDU faults leave no marker.** Its configuration and interface-state faults sit closer to CTBench's hardest class than to self-labelling flags. Injection must not leave a marker in the snapshot.
- **The testbed has its own chronic noise.** ZMQ timing warnings and repeated benign log lines should stay in snapshots, not be cleaned out.
- **The radio layer and UE-side symptoms have no ORCA analogue.**

**ORCA lacks three things the telecom benchmarks have:**
- CTBench's human baseline: 56.4% RCA at 40–60 minutes per task;
- FaulT-Bench's cost and timeout accounting;
- NetArena's action-safety scoring.

### What it tells us: add the ladder and controls, and measure the time ORCA ignored

**1. Adopt ORCA's evaluation axes:**
- the alarm-specificity ladder;
- a detection-window axis;
- about 15–20% healthy controls;
- set-valued ground truth scored with precision and recall, never accuracy alone, when compound faults exist;
- the deterministic 0–3 depth rubric;
- success/empty/error classification of predicate outcomes.

**2. Add the efficiency metrics ORCA lacks:**
- time-to-isolate and time-to-first-correct-hypothesis;
- predicate count;
- tokens and dollars;
- artifacts-to-confirm;
- timeout rate and the timeouts' share of spend.

**3. Run a small timed human comparison.** Use 3–5 engineers on 5–10 incidents, with and without VERDICT output.

**4. Ablate a source-code lookup tool for the Falsifier.** The tool maps a log string to its source location and emitting condition. Run it given to the Falsifier, never to the Generator, as an ablation.

**5. Emit an on-call-style report:**
- Summary;
- Timeline;
- verified causal chain with provenance;
- advisory remediation that is never executed;
- an "unresolved → escalate" branch.

**6. Caveat every citation of ORCA.** It covers cloud, not RAN; its faults label themselves; it has no human baseline; it is vendor co-authored; it is a preprint.

---

## The five papers side by side

| # | Paper | Dataset / environment | Agents and models | Scale | Key number | Main lesson | Transfer verdict |
|---|---|---|---|---|---|---|---|
| 6 | Kim et al., AIOps'26 workshop | OpenRCA, 335 incidents, 3 web domains | OpenRCA Controller–Executor × 5 reasoning LLMs | 1,675 runs, ~$1,394 | Hallucination in Interpretation in **71.2%** of runs; perfect accuracy ≤12.5% | Interpretation must be verified externally; prompts widen search but do not fix misreading | **Transfers with modification.** Reasoning pitfalls are confirmed in telecom; code-gen failure is contradicted under typed tools |
| 7 | Riddell et al., FORGE '26 | GAIA (152) + OpenRCA Market (148); alerts and a typed KG | Straight-Shot / ReAct / Plan-and-Execute × 6 open models (3B–104B) | 48,000 scenarios; 3,073 judged traces | Best HA@1 **0.31**; anchoring, stalling, failure to update: RR < 0.55 | Agentic structure alone adds failures, not accuracy; validators beat loops | **Taxonomy transfers and becomes more checkable**; "agentic doesn't help" is contested at frontier scale |
| 8 | Lu et al., preprint | RCABench TrainTicket (500) + AIOps 2025 (held out) | 6 frameworks × Qwen 3.5-plus, + Sonnet 4.6 | 3,500 trajectories | Correct-run Edge F1 **≤0.67**; DiagGuard **+9.0 pp** | Outcome hides process; grounding and verification are additive | **Method transfers strongly** (deterministic via the Broker); architecture finding contested by SADE |
| 9 | Gopal & Krishnan, preprint | OpenRCA (curated, injected) | Classical CD, 3 LLM baselines, structured pipeline; GPT-5.2 | 335 windows | DK ON Full 25.7–56.9%; Data Ambiguity **1.4%** (soft) | Domain knowledge dominates; "real-world" framing over-reaches | **Lessons transfer, numbers do not**; its "Telecom" is an IT database system |
| 10 | Gong et al. (ORCA-bench), preprint | OTel Astronomy Shop, 6 days, 11 flags | 5 frontier models in Terminus-2 | 1,079 tasks (195 healthy) | **25.3% Medium / 10.0% Hard**; false alarms ≈16–55% | Vague reports, multi-fault and healthy periods break agents | **Protocol transfers; numbers do not**; its faults label themselves, unlike RAN config faults |

---

## Where the papers disagree, and how VERDICT should resolve it

### Constrain commitment, never exploration

**The apparent contradiction.** Paper #7 finds that Plan-and-Execute and ReAct give open models no accuracy gain over a single pass ([arXiv HTML](https://arxiv.org/html/2601.22208)). Paper #8 finds that "minimally constrained frameworks outperform more tightly orchestrated designs" ([arXiv PDF](https://arxiv.org/pdf/2608.21310)). Yet SADE's phase-gated policy gave **+37 pp root-cause F1, 22 pp from the policy alone** ([SADE](https://arxiv.org/abs/2605.04530), abstract-level). DiagGuard's structure gave +9.0 pp in Paper #8 itself.

**The resolution is what each design constrains.** Paper #8's losers constrain *exploration*:
- TaskWeaver follows a fixed plan;
- OpenRCA "commits as soon as it can emit an answer";
- mABC never iterates over evidence.

Paper #7's Plan-and-Execute constrains through an upfront plan executed by small open models. Its stalls are partly crashes under the harness.

SADE and DiagGuard instead constrain *commitment*: when a hypothesis may be accepted, and on what evidence. Both used frontier or strong models.

**What VERDICT should do.** Give the Falsifier free, budgeted exploration (several predicates per hypothesis, no fixed plan), and gate commitment on predicate outcomes plus a coverage check (survey change 8).

**SADE's cost must be measured, not assumed away.** The same SADE agent had the highest over-diagnosis on healthy networks, 24% ([FaulT-Bench](https://arxiv.org/html/2608.27021)). VERDICT must therefore report false verification next to accuracy.

**The pre-registered claim should be modest.** B beats A on grounding, false verification and abstention quality, not necessarily on Acc@1.

**Cascade (Architecture D) is the cleanest form of this resolution.** Its override rule constrains only commitment: Tier 0's answer stands unless a re-executed two-strike refutation removes it. The Generator stays free to add candidates beyond the Tier-0 shortlist.

**It does not escape the trade-off.** A strict override rule raises the risk that the LLM tiers fail to correct a wrong Tier-0 answer. A loose one raises override fratricide. The two Cascade metrics in the protocol below measure each side.

### Model versus framework needs a factorial, not a slogan

**The papers point in different directions:**
- Paper #6 blames the framework, without varying it.
- Paper #8 calls the backbone "the dominant lever" among top frameworks, on one framework pair.
- Paper #7 attributes cross-cutting failures to model training style.
- Paper #10 finds harness choice "without a consistent advantage". The GPT-5.5 gap of 21.9% vs 31.2% sits within about one standard error on 32 tasks.

**None of them crosses framework with model.** VERDICT should: run A, B and C × at least two model families × at least 3–5 seeds, at equal budget, and report pitfall rates per cell. That is the experiment none of the five ran.

### Prompts fail as reminders but work as knowledge and grounding

**The conflicting results:**
- **Pitfall reminders failed.** In Paper #6, pitfall-aware prompting did not fix misreading: one model, 70 tasks, no numbers reported.
- **Taxonomy-derived defences worked.** DiagGuard's prompt-level Grounder and Verifier gained +9.0 pp across five runs on held-out data.
- **Domain rules worked, with leakage.** In Paper #9, DK rules added +8.6 to +21.6 points.

**The consistent reading.** Telling a model about its biases does nothing. Giving it concrete domain knowledge, or confronting it with what telemetry exists, helps.

**What VERDICT should test:**
- "A + pitfall prompts" and "A + DiagGuard-style checklist" as baselines;
- DK supplied from public 3GPP sources, frozen on the dev split.

### Data ambiguity is rare only where it was filtered out

**The conflicting evidence:**
- Paper #9 finds Data Ambiguity in 1.4% of cases overall.
- The vendor critique of OpenRCA, the benchmark used by Papers #6, #7 (Dataset B) and #9, shows labels that cannot be recovered from the telemetry ([Traversal blog](https://www.traversal.com/blog/openrca-isnt-root-cause-analysis-why-that-matters)).
- Paper #10's agents fail even when the fault announces itself.

**The resolution.** The reasoning bottleneck is real. But ambiguity rates measured on curated benchmarks say nothing about the field.

**What VERDICT should do.** Construct ambiguity deliberately, using dropped modalities and masked signatures. Then label recoverability with gold-signature predicates, never with an LLM that knows the answer.

### More modalities help only if they are summarised

**The tension.**
- Paper #6 treats single-modality reliance as a pitfall (26.9%).
- Paper #7 shows that withholding noisy trace alerts *improved* path validity by up to +0.28.

**The resolution.** Modality coverage matters, but raw volume drowns weak signals.

**What VERDICT should do.** Have the Broker deliver decoded, summarised PCAP events, not raw packets. Measure modality coverage, and run the modality holdout (survey change 16) with PCAP events on and off.

---

## A unified R2 failure taxonomy mapped to VERDICT

The table merges:
- the 12 pitfalls of Paper #6;
- RF-01 to RF-16 of Paper #7;
- the OMIT, MIS and GEN codes of Paper #8;
- the Reasoning-Gap and Data-Ambiguity split of Paper #9;
- the failure modes of Paper #10;
- the telecom-only modes from the survey.

**Status key:**
- **Covered:** the current VERDICT design handles it.
- **Partial:** handled only once a listed addition is built.
- **Not covered:** no mechanism yet.

| # | Unified mode | Source codes | OCUDU form | VERDICT mechanism | Deterministic metric | Status |
|---|---|---|---|---|---|---|
| U1 | Narrative fabrication / evidence asserted but absent | #6 Hallucination in Interpretation; #7 RF-01; #8 GEN2; #10 hallucinated cause | Invented cause strings or IEs; "verified" cause under null evidence | Blind Generator; claims count only through Orchestrator-executed predicates; closed hypothesis schema; templated explanation | Grounding coverage (explanation sentences backed by a predicate with a matching outcome); fabricated-verification rate under null evidence; hallucinated-cause count | **Covered** at decision time; prose needs templating |
| U2 | Misreading present evidence | #6 Hallucination in Interpretation; #7 RF-02; #8 MIS3; #9 Reasoning Gap | KPI polarity (dB, BLER, counter vs gauge); cause-code semantics; which side sent a Failure message | Decoded IEs; numeric predicate comparison; KPI semantics attached in the Broker summary | Predicate-vs-claim direction mismatch rate; cause-code misread rate | **Partial** (Broker semantics to add) |
| U3 | Evidence never gathered (breadth) | #6 Incomplete Exploration, Limited Telemetry Coverage; #8 OMIT3, OMIT5; #9 A\* "not surfaced"; #10 "Metrics (all)" 0–0.1% | Never querying the PCAP, E1 or core side | Coverage check (survey change 8); per-interface Broker checklist | Exploration coverage; modality coverage; **evidence-present-but-unused rate** (gold signatures that fire but are never queried) | **Partial** |
| U4 | Symptom-as-cause / salience / observer blamed | #6 Symptom-as-Cause; #7 RF-03, RF-07; #8 MIS2; #9 first-anomaly selection; #10 loud-symptom fixation | UE registration reject blamed instead of the AMF/CU cause; DU blamed for a CU config error | Depth obligation (Falsifier must test ≥1 upstream alternative from the golden-flow library); provenance predicate; peer_rank | **Symptom-as-cause rate** (verdict downstream of the root in G\*); first-manifestation match | **Not covered** |
| U5 | Chronic background read as incident | #8 OMIT1; #10 GLM-5 load-generator errors | ZMQ timing warnings, benign SCTP retries | Mandatory baseline-window `contrast` predicate; distractors kept in snapshots | Chronic-signal citation rate (cited evidence also present in the baseline window) | **Not covered** |
| U6 | Anchoring / failure to update | #6 No Cross-Validation; #7 RF-09, RF-13; #8 GEN1 | Holding "AMF down" after NG Setup succeeds | Orchestrator decides refutation; Falsifier sees the claim only (survey change 4); ≥2 distinct alternatives | Resubmission-after-refutation rate; hypothesis diversity; prior-on/off delta | **Covered** at decision time; diversity **Partial** |
| U7 | Untested causal edges / spurious paths | #7 RF-05; #8 OMIT2, low Edge F1 | Invented DU↔AMF links | Typed OCUDU KG + path field; one edge predicate per claimed edge | Path validity (PA); **verified Edge F1**; corroboration count | **Not covered** (no KG yet) |
| U8 | Temporal errors | #6 Timestamp Error; #7 RF-04; #8 OMIT6; #9 window carry-over | Clock skew across CU, DU, core and UE; four time bases | Single host clock; UTC normalisation; `precedes` predicate | Window-misalignment rate; temporal-order violations | **Covered** if the Broker normalises clocks |
| U9 | Wrong granularity | #7 RF-06; #8 OMIT5; #9 RCLAgent service vs pod | Naming "CU" instead of CU-CP and procedure | Demarcation output: NE + interface + procedure (survey change 11) | Localization accuracy per granularity level | **Partial** |
| U10 | Silence read as health | #8 MIS1 | Absent F1 SETUP after a wrong F1 address | Absence predicates from the TS 38.401 golden-flow library (survey change 6) | Silence-fault detection rate | **Covered** once change 6 is built |
| U11 | Stalling, loops, budget burn | #6 Meaningless Repetition, Max Step; #7 RF-10–12; #8 trace5 loops, extra rounds; FaulT-Bench timeouts | Repeating the same F1AP query | Two-strike rule; hard budget; canonical-form deduplication | Loop rate (intent 5-grams); duplicate-predicate rate; timeout rate and its cost share | **Covered**; Architecture C at risk |
| U12 | Execution / tool friction | #6 Code generation error, Instruction-Code Mismatch, OOM; #7 execution failures; #8 GEN3; #10 26–40% empty or error calls | Malformed or out-of-schema predicates; decode failures | Typed DSL validated against the schema (survey change 5); bounded snapshot | Predicate validity; empty/error share; modality dropped after an error | **Covered** in B and C |
| U13 | Opaque handoff | #6 Misattributed Evidence; #7 RF-10 | Repair step reads an NL summary instead of typed results | Typed results plus provenance into the repair step | Asserted-but-not-executed events (should be 0) | **Covered** |
| U14 | Single-cause lock-in on compound faults | #10 independent faults 6.2% depth; #9 cause count supplied | Concurrent F1 delay and AMF fault | Set-valued verified output (absent in B; Cascade's coverage rule) | Set recall, precision, hallucinated-cause count | **Not covered** in B; by design in D |
| U15 | Unrecoverable incident answered anyway | #9 Data Ambiguity; forced prediction | Modality dropped; masked signature | "Unresolved" output | Correct-abstention rate on unrecoverable incidents; false-abstention rate on solvable ones | **Covered** in design; scoring to define |
| U16 | Over-diagnosis of healthy networks (telecom; #10 controls) | FaulT-Bench 11–24%, 47% with vague tickets; #10 ≈16–55% | Benign warning promoted to a cause | "No fault found" status (survey change 1) | False-verification rate on healthy and false-premise snapshots | **Partial** (needs change 1) |
| U17 | Under-detection (telecom) | Base-model recall 30% ([Hatami et al.](https://arxiv.org/html/2512.19697)) | Faulty snapshot called normal | Coverage check; front-end prior | Missed-fault rate | **Partial** |
| U18 | Spec misrecall (telecom) | Spec recall <60% vs fault QA 90–98% ([Sengupta et al.](https://arxiv.org/html/2608.21021)) | Wrong TS clause or IE meaning | Decoders supply IE semantics; spec RAG with clause citation (survey change 13) | Clause-citation validity | **Partial** |
| U19 | Localization lags identification (telecom; #7 TA ≥ LA; #9 Partial ≫ Full) | NIKA 89.0 → 68.7 → 55.3; CTBench | Right fault class, wrong NE or interface | Demarcation schema | Separate detection, localization and identification scores; per-field accuracy | **Covered** in measurement |
| U20 | Fratricide: true cause proposed, then abandoned or refuted | #8 Fig. 1 anecdote; introduced by VERDICT's own Falsifier | Falsifier refutes "wrong AMF address" with a predicate on the wrong window | Two-strike rule; discriminability check | **Fratricide rate**; correct-then-abandoned rate (A) | **Exposed by design**; mitigated, not removed |
| U21 | Void refutation / non-discriminating evidence | #7 RF-08 (Falsifier-side mirror); #9 rules "not verified to discriminate"; #10 empty queries | Refuting with a predicate that is false under every hypothesis | Discriminability check against a rival; empty-result flag | Void-refutation rate | **Partial** |
| U22 | Broker-summary distortion (new, VERDICT-specific) | Moves #6 Hallucination in Interpretation and #7 RF-07 into the summary | Lossy or mis-ordered per-interface summary | Summary-ordering ablation; logging cited summary items | Gold-signature-in-summary rate (does the summary contain the gold first evidence?) | **Not covered** |

**Six modes Architecture B does not yet cover.** The next subsection shows how Cascade changes this list.
- **U4 symptom-as-cause.** Needs a depth obligation and G\*.
- **U5 chronic background.** Needs a baseline-contrast predicate.
- **U7 spurious edges.** Needs a topology KG and verified edges.
- **U14 compound faults.** Needs a set-valued output, or an explicit single-fault scope statement.
- **U20 fratricide.** This one cannot be removed, only measured and bounded.
- **U22 Broker-summary distortion.** This is the risk the blind-Generator design creates.

U16 and U2 depend on survey changes that are still unbuilt.

### How Cascade (Architecture D) changes the coverage

Cascade's own design already includes several of the additions above:
- a propagation path on the OCUDU topology graph for every hypothesis;
- a Falsifier obligation to test at least one upstream alternative;
- "cause precedes symptom" and absence predicates.

Its gate, override rule and coverage rule then touch the remaining modes, as follows. Every entry in the "Expected effect" column is a **design argument to be tested, not a result**.

| Mode | Cascade mechanism | Expected effect (design argument) | New risk Cascade introduces | Metric |
|---|---|---|---|---|
| U6 Anchoring / failure to update | **Override rule.** Tier 0's answer is replaced only after a re-executed two-strike refutation, and the Generator starts from the Tier-0 shortlist | The LLM cannot talk the system out of a correct deterministic answer | Anchoring moves onto Tier 0: the Generator may echo its top-1. The best Correct Flip Rate on inherited reasoning is only 29.1% ([TeleResilienceBench](https://arxiv.org/abs/2605.09929)) | Override fratricide; overrides of wrong Tier-0 answers; no-shortlist ablation (= B) |
| U4 Symptom-as-cause | Upstream-alternative obligation in Tier 2, plus the **coverage rule** | A downstream symptom that leaves anomalies unexplained cannot be the final answer | Tier-0 rules themselves may encode symptom-level causes | Symptom-as-cause rate per tier |
| U7 Spurious edges | Propagation path over the topology graph is required | Invented links are rejected deterministically | — | Path validity; verified Edge F1 |
| U14 Compound faults | **Coverage rule**: when one cause cannot explain every anomaly, the output is a cause set | Moves U14 from "not covered" to covered by design | Padding the set with extra causes. ORCA's superset metric shows how listing causes games accuracy ([arXiv v3](https://arxiv.org/html/2607.28545v3)) | Set recall and precision; hallucinated-cause count; no-coverage-rule ablation |
| U16 Over-diagnosis of healthy networks | **Healthy gate**: "no fault" when there is no anomaly against the healthy profile and all flows conform | Over-diagnosis is decided by deterministic checks, not LLM probing (the FaulT-Bench failure) | A gate that is too loose sends faulty snapshots to "no fault", which is U17 under-detection | False-verification rate; missed-fault rate at the gate |
| U3 Breadth / U22 Broker-summary distortion | Tier 0 passes on its list of unexplained anomalies; the coverage rule enforces them | Missed anomalies become explicit obligations rather than silent omissions | The unexplained-anomaly list inherits Tier 0's blind spots | Evidence-present-but-unused rate; gold-signature-in-summary rate |
| U20 Fratricide | Two-strike override rule | A correct Tier-0 answer is expensive to kill | Splits into **override fratricide** (correct Tier-0 answer lost) and Falsifier fratricide on LLM-added candidates | Both rates reported separately |
| U15 Unrecoverable incidents | "Unresolved" with ranked residuals and the missing evidence | Abstention becomes diagnostic, not silent | — | Correct-abstention rate; residual-list contains R\* |
| New: confident-wrong gate | The **confident gate** answers with zero LLM calls when the top candidate passes its own predicates, explains every anomaly and has a clear margin | Cheap, fast answers on clean cases | The single point of failure: a confidently wrong Tier-0 answer never reaches the LLM tiers | **Confident-wrong gate rate** |

**Two modes stay exposed under Cascade.** U5 chronic background still needs a baseline-contrast predicate. U2 KPI polarity still needs Broker semantics.

**Cascade's advantage can only appear on the hard strata.** On a clean, team-written corpus, Tier 0 will look unrealistically strong. The advantage shows only on:
- held-out fault types and configurations;
- compound faults;
- vague-alarm summaries;
- healthy episodes.

These strata are therefore mandatory for R2's evaluation, not optional.

---

## R2 evaluation protocol for the reasoning process

The protocol has three parts:
- outcome, behaviour and failure-code levels, following Paper #8;
- every label made deterministic from Broker logs and gold artifacts written at injection;
- consistent with survey changes 1–5, 8, 10, 12 and 16.

### Log every query and predicate in one schema

All conditions touch telemetry only through the Broker API: Condition 0, Straight-Shot, A, A+checklist, B and C. This is the lesson of Paper #8, which lost two frameworks to non-comparable access. Each query or predicate execution writes one record:

```json
{
  "run_id": "r-0412", "incident_id": "inc-117", "seed": 2,
  "condition": "C0|SS|A|A+chk|B|C|D|D-nogate|D-nooverride|D-nocoverage", "model": "qwen3-32b",
  "tier": "0|1|2", "role": "tier0|generator|falsifier|react|repair", "round": 4, "step": 11,
  "hypothesis_id": "H2", "claim_id": "H2.c1",
  "predicate": {"type": "msg_present|msg_absent|msg_order|ie_equals|kpi_threshold|kpi_delta|log_count|precedes|contrast|peer_rank|path_edge",
                "canonical": "msg_absent(F1AP.F1SetupRequest, DU->CU-CP, [t0,t1])",
                "hash": "9f2c...", "spec_clause": "TS38.401 8.5"},
  "scope": {"nf": ["DU","CU-CP"], "interface": ["F1-C"], "procedure": ["F1 Setup"], "ue": [], "cell": []},
  "window": {"kind": "baseline|fault|contrast", "t_start": "...", "t_end": "...", "clock": "host-utc"},
  "modality": "pcap|log|kpi|alarm", "granularity": "nf|interface|procedure|ue|cell",
  "schema_valid": true, "executed_ok": true, "error": null,
  "result": {"outcome": "true|false|empty|error", "cardinality": 0, "entities": ["DU"], "value": null},
  "uses_result_of": ["s7"], "discriminates_against": {"rival": "H3", "differs": true},
  "verdict_effect": "support|refute|void|none",
  "tokens_in": 812, "tokens_out": 94, "wall_ms": 37, "usd": 0.0004
}
```

Each run also writes an outcome record containing:
- status ∈ {verified, unresolved, no_fault};
- for Cascade, the Tier-0 top-K with its confidence and unexplained anomalies;
- the gate decision ∈ {healthy, confident, pass-through};
- whether Tier 0's answer was overridden, and by which refutation predicates;
- cause and demarcation;
- the hypothesis list, with the round each hypothesis first appeared and the predicate IDs that refuted it;
- explanation sentences, each tagged with predicate IDs.

**What the schema feeds:**
- The `scope` and `result.entities` fields are Paper #8's "action" and "result" services.
- `predicate.type` is its intent, with no LLM classifier needed.
- `uses_result_of` makes the "utilized" label a typed field, not a thought-text match.
- `discriminates_against` operationalises the void-refutation check.

### Write gold artifacts when the fault is injected

The harness writes a gold record per incident from the injection YAML, then spot-checks it. About 20% of incidents are double-annotated, against Paper #8's 93% agreement on post-hoc annotation. The record contains:

| Field | Content |
|---|---|
| R\* | Root entity and fault class |
| G\* | Nodes = affected NFs, interfaces and procedures. Edges = propagation steps realised through a 3GPP procedure dependency or a shared resource, each with its evidence predicates. Example: wrong F1 address → F1 SETUP absent → DU cell not activated → UE attach failure → KPI drop. |
| First manifestation and expected first evidence | As in survey change 2 |
| d\* and interfaces crossed | Difficulty measures |
| Gold-signature predicates | Run over the snapshot to compute a **recoverable** flag (Paper #9 lesson) |
| Flags | Healthy / false-premise; specificity tier; marker-scrub check, confirming the injection left no self-labelling trace (Paper #10 lesson) |

Templating G\* per fault family is cheaper than reconstructing it after the fact. With short OCUDU chains, it should be at least as reliable.

### Compute trajectory metrics deterministically

| Metric | Definition | Origin | What it diagnoses |
|---|---|---|---|
| Acc@1, top-K, per-field accuracy | Cause; NE + interface + procedure; onset | #8, #9, survey change 2 | Outcome; localization lag (U19) |
| Node F1 / Edge F1 | Predicted graph vs G\* | #8 | Map reconstruction |
| **Verified Edge F1** | Only edges whose `path_edge` or `precedes` predicate executed with a consistent outcome | New (fixes #8's self-report weakness) | Untested edges (U7) |
| First-hit | Round or rank at which R\* first appears: among Generator hypotheses (B/C), or as an on-path predicate scope (A, Falsifier) | New | Search efficiency |
| **Fratricide / correct-then-abandoned** | B/C: R\* proposed and then refuted by the Falsifier. A: R\* queried on-path with a supporting result, yet the final answer ≠ R\*. Split refuted from abandoned without refutation. | New (formalises #8 Fig. 1) | U20 |
| **Override fratricide** (Cascade) | Correct Tier-0 top answers that the LLM tiers overrode / all correct Tier-0 top answers that passed the gate. Report beside its dual: wrong Tier-0 answers corrected by an override. | Survey Architecture D | Cost of the override rule (U20) |
| **Confident-wrong gate rate** (Cascade) | Incidents answered at the confident or healthy gate whose answer is wrong (including "no fault" on a faulty snapshot) / all gated incidents. Report per gate branch. | Survey Architecture D | Gate as single point of failure |
| Missed refutation / false verification | Wrong cause survives / a cause is verified on a healthy snapshot | Survey changes 1, 4 | U6, U16 |
| Void-refutation rate | Refutes with outcome empty, or `differs = false` | VERDICT; #10 empty calls | U21 |
| Evidence-use labels | utilized (next step `uses_result_of` an on-path result), partial, ignored, no_data (cardinality 0) | #8 | Grounding of each step |
| Navigation moves | Paper #8's 10 transitions over G\* entities; on-path round rate; Stray/Wander share | #8 | Drift off the fault surface |
| Loop rate | Repeated intent 5-grams per trajectory; duplicate canonical hashes; resubmission after refutation | #6, #7, #8 | U11, U6 |
| Coverage | Checklist items touched; modalities touched; corroboration count per verified cause | #6 | U3 |
| Grounding coverage | Explanation sentences with a predicate whose outcome matches | #6, survey | U1 |
| Evidence-present-but-unused | Gold signature fires in the snapshot but no predicate ever scoped it | #9 (deterministic version) | U3 |
| Symptom-as-cause rate | Verdict node lies downstream of R\* in G\* | #6 | U4 |
| Depth rubric 0–3 | 1 = restates alarm; 2 = predicate hits a gold symptom; 3 = cause, mechanism and predicates match gold | #10 (deterministic version) | Partial credit |
| Efficiency | Rounds, tokens and $ split by correct vs incorrect; time-to-isolate (TTI); TTI to first correct hypothesis; artifacts-to-confirm; timeout rate and cost share | #8, #10, FaulT-Bench | Cyshield's effort outcome |
| Process → outcome | RD and RR (Wilson CIs) of each deterministic process label against correctness | #7 (without judge circularity) | Which failures matter |

### Score abstention as a first-class outcome

Every incident has one of four types: solvable fault, unrecoverable fault, healthy, or false-premise. Every output has one of three statuses: verified, unresolved, or no_fault.

**Report the full 4 × 3 confusion matrix,** and from it:
- **selective accuracy:** accuracy on answered cases;
- **coverage:** the share of cases answered;
- the **risk–coverage curve** over the Orchestrator's strike threshold;
- **correct-abstention rate** on unrecoverable incidents;
- **false-abstention rate** on solvable ones;
- **false-verification rate** on healthy and false-premise snapshots.

**Never report hallucination alone.** Paper #10 shows that the lowest hallucination rate can simply mean empty output. Never use a superset-accuracy metric without precision either.

**Base abstention on predicates only.** Abstention comes from predicate outcomes, never from verbalised confidence (survey change 4).

**For Cascade, split every cell of the matrix by where the case ended:** the healthy gate, the confident gate, or the LLM tiers. A low overall false-verification rate is meaningless if the healthy gate sends faulty snapshots to "no fault". That is what the confident-wrong gate rate and the gate's missed-fault rate expose.

**Also report median and mean cost separately.** The survey expects median cost near Condition 0, because most clean incidents should end at the gate, and mean cost above a pure rule engine. Both expectations need testing.

### Conditions that stress the reasoning process

**Healthy controls.**
- Make about **15–20% of snapshots healthy**; ORCA uses 18%.
- Add false-premise episodes whose alarm text names a fault or component that is not there (survey change 1).
- Budget these as the most expensive runs, since Opus spent 2.60M tokens on ORCA controls against 1.67M on incidents.

**Alarm-specificity ladder.** Easy (specific cause string), Medium (component), Hard ("no service"), crossed with a detection-window axis that varies how much pre-onset history the snapshot holds.

**Partial-evidence conditions.** These sit between null evidence and full evidence. Drop the PCAP, logs or KPIs one at a time, and mask the gold first evidence in a subset.
- The correct answer is "unresolved" exactly when the recoverable flag turns false.
- This doubles as the modality ablation, analysed with Wilcoxon signed-rank tests per sample (Paper #7 precedent; survey change 16).

**Perturbation.** Perturb IDs, timestamps, cause strings and alarm wording (survey change 12). Keep chronic distractors in snapshots.

**Corpus strata.**
- Compound, sequential and boundary-straddling faults, with the cause count withheld in at least one stratum.
- Confusable pairs (survey change 10).
- Emulated-radio strata reported separately.

### Baselines and ablations that isolate where VERDICT's gain comes from

| Condition | What it isolates | Source |
|---|---|---|
| Condition 0: deterministic front-end (rules + deviation × signature, healthy baselines, earliest-onset ranking, top-K) | Whether an LLM is needed at all; avoids the strawman of Paper #9 | Survey change 7; #9 |
| Straight-Shot LLM: one pass over the Broker summary + topology, no Falsifier | Whether the refutation loop adds value over a single pass | #7 |
| Single LLM call over anomaly tables | Cheapest LLM floor | #9 |
| A: ReAct agent | The minimally constrained design that Paper #8 predicts to be strong | #8 |
| A + pitfall/hypothesis prompts | Whether prompt-only fixes suffice | #6 |
| A + taxonomy checklist (DiagGuard-style) | Checklist content vs external, executable verification | #8 |
| Grounding only (Broker checklist + coverage gate + baseline contrast, no Falsifier) / Falsifier only / both (= B) | Additivity of VERDICT's two halves | #8 RQ5 |
| B vs C | Whether repair/reselect helps or stalls | #7 Obs. 14 |
| Provenance channel: typed results vs NL summary | Paper #6's communication fix, inside VERDICT | #6 |
| Front-end prior on/off | Anchoring on the prior | Survey change 7 |
| Generator blind vs raw | Whether blinding cuts misreading or just moves it to the summary (U22) | #6 gap |
| DK ON/OFF (public 3GPP knowledge) | Knowledge vs reasoning | #9 |
| Source-code lookup for the Falsifier, on/off | Value of code access | #10 |
| Model-size sweep (≈8B vs 30B+) × ≥2 families | Procedural collapse; model vs framework | #7, survey change 14 |
| D: Cascade (full) | The proposed main architecture | Survey Architecture D |
| D, Tier 0 alone (= Condition 0) | What the deterministic tier achieves unaided | Survey Architecture D |
| D, no gate (LLM always runs) | Cost and accuracy of the gate; checks the confident-wrong gate rate from the other side | Survey Architecture D |
| D, no override rule (LLM may replace Tier 0 freely) | Whether the two-strike override lowers override fratricide without blocking corrections | Survey Architecture D; #7 RF-09/13 |
| D, no coverage rule (single-cause output) | Value of cause sets on compound faults; symptom-as-cause | Survey Architecture D; #10 multi-fault |
| D, no Tier-0 shortlist to the Generator (= VERDICT B) | Whether starting from the shortlist helps, or only anchors | Survey Architecture D; survey change 7 |

**All conditions share one hard budget**, and timeouts are reported separately (survey change 8).

**Pre-register the Cascade win-claims as hypotheses.** Cascade should match or beat Condition 0 and A, B and C on every quality metric. The survey states this as a design argument, not a measurement. The test is the five Cascade ablations, run on the hard strata listed above.

### Split hygiene, repetition and statistics

**Split the corpus before building anything.** Split by fault family and by OCUDU configuration into dev and test, with:
- a held-out fault-family stratum;
- a held-out configuration stratum, the analogue of Paper #9's CB1 → CB2;
- a held-out model.

**Freeze everything on dev.** That covers the codebook, predicate library, golden-flow rules, prompts, DK, thresholds and the budget-based "unresolved" trigger. Then run test once and report dev-versus-test deltas. Paper #9's DK lost 5.3 points on Telecom when moved off-test.

**After any intervention:**
- re-measure the process metrics, not just Acc@1;
- count the cases it broke (correct → incorrect).

**Repetition and statistics.**
- Run **at least 3–5 seeds per incident** and report pass@k with mean ± sd.
- Use bootstrap CIs clustered by incident (survey change 3).
- Use paired McNemar or exact tests for same-incident comparisons.
- Do not rank conditions inside the noise band: Paper #8's top band spans 2.0 pp, and Paper #10's Verified subset has SEs of 7–9 pp.
- Report random-guess baselines for OCUDU's small topology.
- Pre-register win-claims: false verification, abstention quality, grounding, compound and held-out faults, and time-to-isolate.

### Use an LLM judge only where determinism cannot reach

Only a few labels need semantic judgement:
- Paper #6's Hallucination in Interpretation in Architecture A's free prose;
- Paper #7's RF-03, 07, 08, 13 and 14 on A traces and final explanations;
- explanation quality (survey change 17).

**Fix Paper #7's protocol weaknesses:**
- Use a judge from a different model family than every system under test.
- Give the judge **no ground truth** in the prompt.
- Report per-label κ with CIs against at least 2 humans on at least 50 traces.
- Code a sample of **correct** runs as well as failed ones.

**Repeat open coding on the OCUDU dev split** rather than only applying the cloud codes. Add cause-code misread and procedure-order misread from the start.

---

## Conclusion

Read together, the five papers move the question R2 should answer. Asking whether an agent finds the root cause is not enough. The useful question is who holds acceptance authority, and what evidence they must hold before committing. Every proposed fix converges on the same structure: Paper #6's "external verification modules", Paper #7's validators, DiagGuard's grounding and verification, and Paper #9's "symbolic firing-checker". A cheap deterministic layer decides, and the LLM only proposes.

VERDICT already has that structure. Its credible contribution is therefore not a higher Acc@1, which Condition 0 may match on a clean corpus. It is the first measurement of what this structure costs and buys on a RAN stack:
- fratricide;
- void refutation;
- false verification on healthy snapshots;
- verified Edge F1;
- evidence present but unused.

No cloud or telecom paper reports these. The papers also show where the next failure will appear. Once the LLM can no longer fabricate at decision time, the risk shifts to two places. The first is the Broker summary the blind Generator reads. The second is the Falsifier's power to kill a correct cause.

The most important design consequence is an asymmetry. Constraining *commitment* helps, as SADE and DiagGuard show. Constraining *exploration* hurts, as Paper #8's losers and Paper #7's Plan-and-Execute show. And a structured pipeline can trade specificity for sensitivity, as SADE's 24% over-diagnosis shows.

VERDICT should therefore keep the Falsifier's search open while gating verdicts hard. Cascade (Architecture D) takes this to its logical end: the deterministic answer stands unless refuted, and clear cases never reach an LLM.

Cascade also relocates the risk a second time:
- to the gate, measured by the confident-wrong gate rate;
- to the override threshold, measured by override fratricide.

Whichever variant the team adopts, it should be judged first on healthy and unrecoverable snapshots. That is where the literature predicts it will fail. Because those snapshots are cheap to generate on OCUDU, an honest negative result there would be as publishable as a positive one.
